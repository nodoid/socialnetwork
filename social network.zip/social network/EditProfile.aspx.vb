﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Partial Class EditProfile
    Inherits System.Web.UI.Page

    Dim blnPrintForm As Boolean = True
    Dim strImageName As String
    Dim strErrorMessage As String
    Dim blnChangeMade As Boolean = False
    Public strCancel_Click As String

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        'Call ProcessLogin()
        'Populate the "Height" drop-down menu.
        Dim intHeight As Byte
        For intHeight = 36 To 95
            Height.Items.Add(New ListItem(ConvertHeight(intHeight), intHeight))
        Next intHeight
        'Populate the "Neighborhoods" drop-down menu.
        Call UseHoodArray()
        Dim intIndex As Byte
        For intIndex = 1 To HoodArray.Length - 1
            NeighborhoodID.Items.Add(New ListItem(HoodArray.GetValue(intIndex), intIndex))
        Next
        'Populate the "Body Type" drop-down menu.
        Call UseBodyArray()
        intIndex = 0
        For intIndex = 1 To BodyArray.Length - 1
            BodyTypeID.Items.Add(New ListItem(BodyArray.GetValue(intIndex), intIndex))
        Next
        'Create the Gender Array.
        Call UseGenderArray()
        'Populate the "Sign" drop-down menu. Added Feb. 14,2005.
        Call UseSignArray()
        intIndex = 0
        For intIndex = 1 To SignArray.Length - 1
            SignID.Items.Add(New ListItem(SignArray.GetValue(intIndex), intIndex))
        Next
        'Populate the "Ethnicity" drop-down menu.
        Call UseEthnicArray()
        intIndex = 0
        For intIndex = 1 To EthnicArray.Length - 1
            EthnicID.Items.Add(New ListItem(EthnicArray.GetValue(intIndex), intIndex))
        Next


    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("UserName") = "" Then
            strErrorMessage = "Please login to edit your profile."
            blnPrintForm = False
        End If
        'Else
        Dim strUserName As String = Session("UserName")
        Dim strProfileID As String = Session("ProfileID")
        strCancel_Click = "window.location='seeprofile.aspx?username=" & strUserName & "&id=" & strProfileID & "';"
        'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
        Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)



        If blnPrintForm Then
            Dim strSQL As String
            'TODO: Move to Parameterized Stored Procedure
            strSQL = String.Format("SELECT Email,GenderID,Age,SexualOrientationID,SignID,EthnicID,Height,BodyTypeID,NeighborhoodID,AboutMe,WantActivityPartner,WantFriend,WantDate,WantLTR,CreationDate FROM Profiles WHERE ProfileID={0} AND UserName='{1}' AND ProfileStatusID=2;", strProfileID, strUserName)
            Dim objFirstCommand As New SqlCommand(strSQL, objConnection)
            Dim objDataReader As SqlDataReader
            objConnection.Open()
            objDataReader = objFirstCommand.ExecuteReader()
            If objDataReader.Read() Then
                UserName.Text = strUserName
                Email.Text = objDataReader("Email")
                GenderID.Text = ColorGender((objDataReader("GenderID")))
                Age.Text = objDataReader("Age")
                old_Age.Value = objDataReader("Age")
                If objDataReader("WantActivityPartner") = 1 Then
                    WantActivityPartner.Checked = True
                    old_WantActivityPartner.Value = "on"
                End If
                If objDataReader("WantFriend") = 1 Then
                    WantFriend.Checked = True
                    old_WantFriend.Value = "on"
                End If
                If objDataReader("WantDate") = 1 Then
                    WantDate.Checked = True
                    old_WantDate.Value = "on"
                End If
                If objDataReader("WantLTR") = 1 Then
                    WantLTR.Checked = True
                    old_WantLTR.Value = "on"
                End If
                Select Case objDataReader("SexualOrientationID")
                    Case 1
                        SexualOrientationID.Items(0).Selected = True
                    Case 2
                        SexualOrientationID.Items(2).Selected = True
                    Case 3
                        SexualOrientationID.Items(1).Selected = True
                    Case 0
                        SexualOrientationID.Items(3).Selected = True
                End Select
                old_SexualOrientationID.Value = objDataReader("SexualOrientationID")
                Dim i As Byte
                If objDataReader("SignID") <> 0 Then
                    For i = 0 To SignID.Items.Count - 1
                        If SignID.Items(i).Value = CStr(objDataReader("SignID")) Then
                            SignID.Items(i).Selected = True
                            Exit For
                        End If
                    Next
                End If
                old_SignID.Value = objDataReader("SignID")
                i = 0
                If objDataReader("EthnicID") <> 0 Then
                    For i = 0 To EthnicID.Items.Count - 1
                        If EthnicID.Items(i).Value = CStr(objDataReader("EthnicID")) Then
                            EthnicID.Items(i).Selected = True
                            Exit For
                        End If
                    Next
                End If
                old_EthnicID.Value = objDataReader("EthnicID")
                i = 0
                If objDataReader("Height") <> 0 Then
                    For i = 0 To Height.Items.Count - 1
                        If Height.Items(i).Value = CStr(objDataReader("Height")) Then
                            Height.Items(i).Selected = True
                            Exit For
                        End If
                    Next
                End If
                old_Height.Value = objDataReader("Height")
                'Pre-set the Body Type.
                i = 0
                If objDataReader("BodyTypeID") <> 0 Then
                    For i = 0 To BodyTypeID.Items.Count - 1
                        If BodyTypeID.Items(i).Value = CStr(objDataReader("BodyTypeID")) Then
                            BodyTypeID.Items(i).Selected = True
                            Exit For
                        End If
                    Next
                End If
                old_BodyTypeID.Value = objDataReader("BodyTypeID")
                i = 0
                If objDataReader("NeighborhoodID") <> 0 Then
                    For i = 0 To NeighborhoodID.Items.Count - 1
                        If NeighborhoodID.Items(i).Value = CStr(objDataReader("NeighborhoodID")) Then
                            NeighborhoodID.Items(i).Selected = True
                            Exit For
                        End If
                    Next
                End If
                old_NeighborhoodID.Value = objDataReader("NeighborhoodID")
                If Not (objDataReader.IsDBNull(7)) Then
                    AboutMe.Text = Server.HtmlDecode(objDataReader("AboutMe"))
                    old_AboutMe.Value = objDataReader("AboutMe")
                End If
            Else
                strErrorMessage = "The profile <strong>" & strUserName & "</strong> is not active or no longer exists."
            End If
            objDataReader.Close()
            objConnection.Close()
        End If
        phShowForm.Visible = blnPrintForm
    End Sub


    'Used on create/edit/view profile pages.
    Function ConvertHeight(ByVal intHeight As Integer) As String
        Dim intFeet = Fix(intHeight / 12)
        Dim intInches = intHeight Mod 12
        Return CStr(intFeet) & "'" & CStr(intInches) & Chr(34)
    End Function

    'Used on Search results an Favorites page to color-code genders.
    Function ColorGender(ByVal intGenderIndex As Object)
        If GenderArray(1) = "" Then
            Call UseGenderArray()
        End If
        If IsDBNull(intGenderIndex) Then
            Return ""
        Else
            intGenderIndex = CByte(intGenderIndex)
            Select Case intGenderIndex
                Case 1
                    Return "<span class=female>female</span>"
                Case 2
                    Return "<span class=male>male</span>"
                Case Else
                    Return "<span class=transgender>" & GenderArray(intGenderIndex) & "</span>"
            End Select
        End If
    End Function

    Function GetHoodName(ByVal intHoodIndex As Object)
        If IsDBNull(intHoodIndex) Then
            Return ""
        Else
            intHoodIndex = CByte(intHoodIndex)
            Return HoodArray(intHoodIndex)
        End If
    End Function

    Public GenderArray(4) As String
    Public Sub UseGenderArray()
        GenderArray(0) = ""
        GenderArray(1) = "female"
        GenderArray(2) = "male"
        GenderArray(3) = "transgender(f2m)"
        GenderArray(4) = "transgender(m2f)"
    End Sub

    Public OrientationArray(4) As String
    Public Sub UseOrientationArray()
        OrientationArray(0) = ""
        OrientationArray(1) = "straight"
        OrientationArray(2) = "gay/lesbian"
        OrientationArray(3) = "bisexual"
    End Sub

    Public BodyArray(6) As String
    Public Sub UseBodyArray()
        BodyArray(0) = ""
        BodyArray(1) = "average"
        BodyArray(2) = "slim/slender"
        BodyArray(3) = "athletic"
        BodyArray(4) = "thick"
        BodyArray(5) = "a little extra padding"
        BodyArray(6) = "more to love"
    End Sub

    Public HoodArray(37) As String
    Public Sub UseHoodArray()
        HoodArray(0) = "San Francisco"
        HoodArray(1) = "bayview / hunter's point"
        HoodArray(2) = "bernal heights"
        HoodArray(3) = "castro / eureka valley"
        HoodArray(4) = "chinatown"
        HoodArray(5) = "cole valley"
        HoodArray(6) = "excelsior / outer mission"
        HoodArray(7) = "financial district / embarcadero"
        HoodArray(8) = "glen park"
        HoodArray(9) = "haight ashbury"
        HoodArray(10) = "hayes valley"
        HoodArray(11) = "ingleside / merced / ocean view (SFSU,CCSF)"
        HoodArray(12) = "inner richmond"
        HoodArray(13) = "inner sunset / parnassus heights (UCSF)"
        HoodArray(14) = "laurel heights / presidio"
        HoodArray(15) = "lower haight / fillmore"
        HoodArray(16) = "marina / cow hollow"
        HoodArray(17) = "mission district"
        HoodArray(18) = "nob hill"
        HoodArray(19) = "noe valley"
        HoodArray(20) = "north beach / telegraph hill"
        HoodArray(21) = "pacific heights"
        HoodArray(22) = "panhandle (USF)"
        HoodArray(23) = "potrero hill / dogpatch"
        HoodArray(24) = "richmond / seacliff"
        HoodArray(25) = "russian hill"
        HoodArray(26) = "soma / south beach / mission bay"
        HoodArray(27) = "sunset / parkside"
        HoodArray(28) = "tenderloin / civic center"
        HoodArray(29) = "tendernob"
        HoodArray(30) = "twin peaks / diamond heights"
        HoodArray(31) = "visitacion valley / sunnydale / portola"
        HoodArray(32) = "west portal / st. francis wood / forest hill"
        HoodArray(33) = "western addition / japantown"
        HoodArray(34) = "East Bay"
        HoodArray(35) = "North Bay"
        HoodArray(36) = "Peninsula"
        HoodArray(37) = "South Bay"
    End Sub

    Public EthnicArray(10) As String
    Public Sub UseEthnicArray()
        EthnicArray(0) = ""
        EthnicArray(1) = "asian"
        EthnicArray(2) = "black / african"
        EthnicArray(3) = "hispanic / latino"
        EthnicArray(4) = "indian / south asian"
        EthnicArray(5) = "middle eastern / arab"
        EthnicArray(6) = "native american"
        EthnicArray(7) = "pacific islander"
        EthnicArray(8) = "white / caucasian"
        EthnicArray(9) = "mixed"
        EthnicArray(10) = "other"
    End Sub

    Public SignArray(12) As String
    Public Sub UseSignArray()
        SignArray(0) = ""
        SignArray(1) = "aquarius"
        SignArray(2) = "aries"
        SignArray(3) = "cancer"
        SignArray(4) = "capricorn"
        SignArray(5) = "gemini "
        SignArray(6) = "leo"
        SignArray(7) = "libra"
        SignArray(8) = "pisces"
        SignArray(9) = "sagittarius"
        SignArray(10) = "scorpio"
        SignArray(11) = "taurus"
        SignArray(12) = "virgo"
    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
        Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)

        Dim ProfileFields(10, 1) As String
        ProfileFields(0, 0) = "Age"
        ProfileFields(0, 1) = "number"
        ProfileFields(1, 0) = "WantActivityPartner"
        ProfileFields(1, 1) = "checkbox"
        ProfileFields(2, 0) = "WantFriend"
        ProfileFields(2, 1) = "checkbox"
        ProfileFields(3, 0) = "WantDate"
        ProfileFields(3, 1) = "checkbox"
        ProfileFields(4, 0) = "WantLTR"
        ProfileFields(4, 1) = "checkbox"
        ProfileFields(5, 0) = "SexualOrientationID"
        ProfileFields(5, 1) = "number"
        ProfileFields(6, 0) = "EthnicID"
        ProfileFields(6, 1) = "number"
        ProfileFields(7, 0) = "Height"
        ProfileFields(7, 1) = "number"
        ProfileFields(8, 0) = "BodyTypeID"
        ProfileFields(8, 1) = "number"
        ProfileFields(9, 0) = "NeighborhoodID"
        ProfileFields(9, 1) = "number"
        ProfileFields(10, 0) = "SignID"
        ProfileFields(10, 1) = "number"

        Dim strUpdate As New StringBuilder()
        strUpdate.Append("UPDATE Profiles SET ModificationDate=NOW()")
        'Check if user changed password.
        Dim strNewPassword As String = NewPassword.Text
        If (strNewPassword <> "") Then
            blnChangeMade = True
            strUpdate.Append(", PASSWORD=MD5('" & strNewPassword & "') ")
        End If
        'Handle the HTML content of the AboutMe textbox.
        Dim strNewAbout As String = Server.HtmlEncode(AboutMe.Text)
        Dim strOldAbout As String = old_AboutMe.Value
        If strNewAbout <> strOldAbout Then
            blnChangeMade = True
            strUpdate.Append(", AboutMe=""" & strNewAbout & """")
        End If
        Dim i As Byte = 0
        For i = 0 To 10
            Dim strColumnName As String = ProfileFields(i, 0)
            Dim strFieldType As String = ProfileFields(i, 1)
            Dim strOldValue As String = Request.Form("old_" & strColumnName)
            Dim strNewValue As String = Request.Form(strColumnName)
            If strNewValue <> strOldValue Then
                blnChangeMade = True
                Select Case strFieldType
                    Case "number"
                        If IsNumeric(strNewValue) Then
                            strUpdate.Append("," & strColumnName & "=" & strNewValue)
                        End If
                    Case "checkbox"
                        If strNewValue = "on" Then
                            strUpdate.Append("," & strColumnName & "=1")
                        Else
                            strUpdate.Append("," & strColumnName & "=0")
                        End If
                End Select
            End If
        Next
        If blnChangeMade Then
            strUpdate.Append(" WHERE ProfileID=" & Session("ProfileID") & _
             " and UserName='" & Session("UserName") & "';")
            Dim blnUpdateSuccessful As Boolean = False
            'UPDATE the record in the profiles table.
            Try
                objConnection.Open()
                Dim objCommand As New SqlCommand()
                objCommand.Connection = objConnection
                Try
                    objCommand.CommandText = strUpdate.ToString()
                    objCommand.ExecuteNonQuery()
                    blnUpdateSuccessful = True
                Catch excepCommand As Exception
                    blnPrintForm = False
                    databaseErrorMessage.Text = strUpdate.ToString() & "<br /><pre>" & excepCommand.ToString & "</pre>"
                    strErrorMessage = "There was an error updating your profile. Please try again later."
                    'Log the database error in the databaseerrors table.					
                    objCommand.CommandText = "INSERT INTO databaseerrors (ErrorDate,SqlStatement,Exception,PageName)" & _
                          " VALUES( NOW(),""" & Server.HtmlEncode(strUpdate.ToString()) & _
                          """,""" & Server.HtmlEncode(excepCommand.ToString()) & """,'editprofile.aspx');"
                    objCommand.ExecuteNonQuery()
                End Try
            Catch excepConnection As Exception
                blnPrintForm = False
                databaseErrorMessage.Text = strUpdate.ToString() & "<br /><pre>" & excepConnection.ToString & "</pre>"
                strErrorMessage = "There was an error connecting to the database. Please try again later."
            Finally
                If Not (IsDBNull(objConnection)) Then
                    objConnection.Close()
                End If
            End Try
            If blnUpdateSuccessful Then
                Response.Redirect("seeprofile.aspx?username=" & Session("UserName") & "&id=" & Session("ProfileID") & "&updated=yes")
            End If
        Else
            strErrorMessage = "You didn't make any changes."
        End If
    End Sub

    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click

    End Sub
End Class
