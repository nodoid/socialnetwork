'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object

'After calling Send() method, if ErrorMessage property is "" then the messsage was sent.
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Net.Mail
'Imports System.Web.Mail 'TODO: Investigate which assembly is best to use

Public Class EmailMessage : Inherits Page
    Private _SenderID As String
    Private _SenderName As String
    Private _RecipientID As String
    Private _Subject As String
    Private _Body As String
    Private _ErrorMessage As String

    Public Property SenderID As String
        Get
            Return _SenderID
        End Get
        Set(ByVal value As String)
            _SenderID = value
        End Set
    End Property

    Public Property SenderName As String
        Get
            Return _SenderName
        End Get
        Set(ByVal value As String)
            _SenderName = value
        End Set
    End Property

    Public Property RecipientID As String
        Get
            Return _RecipientID
        End Get
        Set(ByVal value As String)
            _RecipientID = value
        End Set
    End Property

    Public Property Subject As String
        Get
            Return _Subject
        End Get
        Set(ByVal value As String)
            _Subject = value
        End Set
    End Property

    Public Property Body As String
        Get
            Return _Body
        End Get
        Set(ByVal value As String)
            _Body = value
        End Set
    End Property

    Public ReadOnly Property ErrorMessage As String
        Get
            Return _ErrorMessage
        End Get
    End Property

    Public Sub Send()
        'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
        Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
        Dim objDataReader As SqlDataReader
        Dim intRecords As Integer = 0
        'Check to see if the Sender is blocked. 
        'TODO: Move to Parameterized Stored Procedure
        Dim strSQL As String = String.Format("SELECT Count(*) FROM messageblocks WHERE ProfileID='{0}' AND BlockID='{1}';", _RecipientID, _SenderID)
        Dim objCommand As New SqlCommand(strSQL, objConnection)
        objConnection.Open()
        intRecords = CInt(objCommand.ExecuteScalar())
        If intRecords <> 0 Then
            _ErrorMessage = "Your message was blocked by the recipient."
        Else
            If _Subject = String.Empty Then
                _Subject = "(no subject)"
            End If
            'Encode both the subject and body of the message.
            _Subject = Server.HtmlEncode(_Subject)
            _Body = Server.HtmlEncode(_Body)
            'Check if the the Sender clicked the refresh button.
            'TODO: Move to Parameterized Stored Procedure
            strSQL = String.Format("SELECT Count(*) FROM messages WHERE SenderID='{0}' AND RecipientID='{1}' AND Subject='{2}' AND Body='{3}' AND MessageDate > DateAdd(hour, 1, getDate());", _SenderID, _RecipientID, _Subject, _Body)
            objCommand.CommandText = strSQL
            'Try
            intRecords = CInt(objCommand.ExecuteScalar())
            'Catch ex As Exception
            '_ErrorMessage = strSQL & "<br>" & ex.Message
            'End Try


            If intRecords <> 0 Then
                _ErrorMessage = "Your message was NOT sent because the same<br />message was sent less than an hour ago."
            Else
                'Check if the Recipient's maibox is full. 
                objCommand.CommandText = String.Format("SELECT Count(*) FROM messages WHERE RecipientID='{0}' AND DeletedByRecipient='0';", _RecipientID) 'TODO: Move to Parameterized Stored Procedure
                intRecords = CInt(objCommand.ExecuteScalar())

                If intRecords >= 100 Then
                    _ErrorMessage = "The recipient's mailbox is full. Please try again later."
                Else
                    objCommand.CommandText = "INSERT INTO messages (MessageDate,SenderID,RecipientID,Subject,Body) " & "VALUES (getDate(),'" & _SenderID & "','" & _RecipientID & "','" & _Subject & "','" & _Body & "');"
                    objCommand.ExecuteNonQuery()
                    'Check if recipient has chosen to receive email notifications of messages.
                    objCommand.CommandText = String.Format("SELECT UserName, Email, ForwardMessages FROM Profiles WHERE ProfileID='{0}';", _RecipientID) 'TODO: Move to Parameterized Stored Procedure
                    Dim strRecipientName As String = String.Empty
                    Dim strEmail As String = String.Empty
                    Dim blnSendEmail As Boolean = False
                    objDataReader = objCommand.ExecuteReader()
                    If objDataReader.Read() Then
                        strRecipientName = objDataReader("UserName")
                        strEmail = objDataReader("Email")
                        blnSendEmail = CBool(objDataReader("ForwardMessages"))
                    End If
                    objDataReader.Close()
                    'Forward a copy of the message to the user.
                    If blnSendEmail Then
                        If _Subject = String.Empty Then
                            _Subject = "(no subject)"
                        End If

                        '''''''
                        'TODO: Add email Template 
                        Dim mail As MailMessage = New MailMessage()
                        mail.To.Add(strEmail)
                        mail.From = New MailAddress(ConfigurationManager.AppSettings("MESSAGE_EMAIL"))

                        mail.Subject = "Social Conveyors: new message from " & _SenderName & "."
                        'TODO: Move Email to EmailTemplate Object
                        'TODO: convert to stringbuilder for speed
                        'Email Template --------------------------------------------------------------------------------------------------------
                        Dim strBody = String.Empty
                        strBody = strBody & "<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">"
                        strBody = strBody & "<html><head><title>[EMAIL TITLE]</title><meta http-equiv=""Content-Type"" content=""text/html; charset=iso-8859-1""></head>"
                        strBody = strBody & "<body marginheight=""0"" marginwidth=""0"" topmargin=""0"" leftmargin=""0"" bgcolor=""#f2f2f2"">"
                        strBody = strBody & "<table width=""100%"" height=""100%"" border=""0"" cellspacing=""0"" cellpadding=""0"" bgcolor=""#f2f2f2""><tr><td valign=""top"" align=""center"">"
                        strBody = strBody & "<table width=""551"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td align=""left"" style=""padding:10px 0 10px 10px; font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#888888;"">Images not displaying properly? Add <a href=""mailto:info@yourcompany.com"" style=""color:#545454;"">info@yourcompany.com</a> to your address book now<br>or <a href=""[SHOWEMAIL]"" style=""color:#545454;"">view the online version here</a>.</td></tr><tr><td align=""left"" bgcolor=""#ffffff"" style=""border:1px solid #9c9c9c; padding:5px;""><div style=""border:7px solid #424242;""><table width=""525"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td style=""padding:25px 20px 20px 20px;"">" 'TODO: Move link href to PageURL object then Reference object
                        strBody = strBody & "<table width=""485"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td><img src=""[LOGO]"" alt=""[COMPANY NAME]"" width=""155"" height=""29""></td>"
                        strBody = strBody & "<td align=""right"" valign=""middle"" style=""font-family:Arial, Helvetica, sans-serif; font-size:18px; color:#acabab;"">"
                        strBody = strBody & Now()
                        strBody = strBody & "</td></tr></table></td></tr><tr><td><div style=""border-bottom:1px solid #d6d6d6; border-top:1px solid #d6d6d6; padding-bottom:3px; padding-top:3px;""><div style=""background-color:#424242;""><table height=""39"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr>"
                        strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[SUBSCRIBE]"" style=""color:#e4e4e4;"">Subscribe</a></td>"
                        strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[UNSUBSCRIBE]"" style=""color:#e4e4e4;"">Unsubscribe</a></td>" 'TODO: Move link href to PageURL object then Reference object
                        strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[FORWARD]"" style=""color:#e4e4e4;"">Forward to a friend</a></td>" 'TODO: Move link href to PageURL object then Reference object
                        strBody = strBody & "<td>&nbsp;</td></tr></table></div></div></td></tr><tr><td style=""padding:30px 20px 0px 20px; font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#333333; line-height:20px;"">"

                        strBody = strBody & "<p style=""margin:0 0 25px 0;"">"

                        strBody = strBody & "From: " & _SenderName & "<br>"
                        strBody = strBody & "To: " & strRecipientName & "<br>"
                        strBody = strBody & "Subject: " & Server.HtmlDecode(_Subject) & "<br><br>"
                        strBody = strBody & Server.HtmlDecode(_Body) & "<br><br>"
                        strBody = strBody & "DO NOT REPLY TO THIS MESSAGE<br>"
                        strBody = strBody & "To reply, please login to Social Conveyors at "
                        strBody = strBody & "<a href=""http://www.SocialConveyors.com"" style=""color:#0165ab;"">http://www.SocialConveyors.com</a></p>" 'TODO: Move link href to PageURL object then Reference object

                        strBody = strBody & "</td></tr><tr><td style=""border-top:1px solid #d6d6d6; background-color:#f6f6f6; font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#666666; line-height:17px;  padding:15px 0 15px 20px;"">"
                        strBody = strBody & "<b>[COMPANY NAME]</b><br>"
                        strBody = strBody & "[COMPANY ADDRESS], [COMPANY CITY], [COMPANY STATE], [COMPANY ZIP]<br>"
                        strBody = strBody & "<a href=""mailto:[INFO EMAIL]"" style=""color:#4089bb;"">[INFO EMAIL]</a><br>" 'TODO: Move link href to PageURL object then Reference object
                        strBody = strBody & "<a href=""http://www.SocialConveyors.com"" style=""color:#4089bb;"">www.SocialConveyors.com</a>" 'TODO: Move link href to PageURL object then Reference object
                        strBody = strBody & "</td></tr></table></div></td></tr><tr><td align=""left"" style=""padding:20px 0 10px 10px; font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#888888;"">"
                        strBody = strBody & "To ensure our newsletter always reaches your inbox, please add <a href=""mailto:info@yourcompany.com"" style=""color:#545454;"">info@yourcompany.com</a> to your<br>" 'TODO: Move link href to PageURL object then Reference object
                        strBody = strBody & "address book. If you prefer not to receive news from Your Company Name in the future, you can<br>"
                        strBody = strBody & "<a href=""[UNSUBSCRIBE]"" style=""color:#545454;"">unsubscribe here</a>." 'TODO: Move link href to PageURL object then Reference object
                        strBody = strBody & "</td></tr></table></td></tr></table></body></html>"
                        '--------------------------------------------------------------------------------------------------------/Email Template

                        mail.Body = strBody
                        mail.IsBodyHtml = True
                        Dim smtp As SmtpClient = New SmtpClient()
                        smtp.Host = ConfigurationManager.AppSettings("SMTP_SERVER")
                        smtp.Credentials = New System.Net.NetworkCredential("test@gmail.com", "!gmail@test#")   'TODO: Setup TEST ACCOUNT
                        smtp.EnableSsl = True

                        Try
                            smtp.Send(mail) 'Send an e-mail to the user with the activation code.
                        Catch ex As Exception
                            objCommand.CommandText = "INSERT INTO emailerrors (FromEmail,ToEmail,Subject,Body,ExceptionError) VALUES ('" & ConfigurationManager.AppSettings("MESSAGE_EMAIL") & "','" & mail.To.ToString() & "','" & Server.HtmlEncode(mail.Subject) & "','" & Server.HtmlEncode(mail.Body) & "','" & Server.HtmlEncode(ex.ToString) & "');"
                            objCommand.ExecuteNonQuery()
                        Finally
                            'TODO: These lines used to be part of screen output.  They need to be made to work in this context.
                            'litErrorMessage.Text = ""
                            'litStatusMessage.Text = "Email sent to " & Email.Text & "." 'TODO: Move to StatusMessage object
                            'TODO: Set Email Sent Status Message litStatusMessage & phStatusMessage
                        End Try
                        '''''''
                    End If
                End If
            End If
        End If
        objConnection.Close()
    End Sub

    Sub New()
        _ErrorMessage = String.Empty
    End Sub
End Class