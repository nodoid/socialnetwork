'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object

'Used on create/edit/view profile pages.
'Function ConvertHeight(intHeight As Integer) As String
'Dim intFeet = Fix(intHeight / 12)
'Dim intInches = intHeight Mod 12
'	return CStr(intFeet) & "'" & CStr(intInches) & Chr(34)
'End Function

'Used on Search results an Favorites page to color-code genders.
'Function ColorGender(ByVal intGenderIndex As Object)
'    If GenderArray(1) = "" Then
'        Call UseGenderArray()
'    End If
'    If IsDBNull(intGenderIndex) Then
'        Return ""
'    Else
'        intGenderIndex = CByte(intGenderIndex)
'        Select Case intGenderIndex
'            Case 1
'                Return "<span class=female>female</span>"
'            Case 2
'                Return "<span class=male>male</span>"
'            Case Else
'                Return "<span class=transgender>" & GenderArray(intGenderIndex) & "</span>"
'        End Select
'    End If
'End Function

'Used on Search results an Favorites page to color-code genders.
'Function GetHoodName(ByVal intHoodIndex As Object)
'    If IsDBNull(intHoodIndex) Then
'        Return ""
'    Else
'        intHoodIndex = CByte(intHoodIndex)
'        Return HoodArray(intHoodIndex)
'    End If
'End Function

'Public GenderArray(4) As String
'Public Sub UseGenderArray()
'    GenderArray(0) = ""
'    GenderArray(1) = "female"
'    GenderArray(2) = "male"
'    GenderArray(3) = "transgender(f2m)"
'    GenderArray(4) = "transgender(m2f)"
'End Sub

'Public OrientationArray(4) As String
'Public Sub UseOrientationArray()
'    OrientationArray(0) = ""
'    OrientationArray(1) = "straight"
'    OrientationArray(2) = "gay/lesbian"
'    OrientationArray(3) = "bisexual"
'End Sub

'Public BodyArray(6) As String
'Public Sub UseBodyArray()
'    BodyArray(0) = ""
'    BodyArray(1) = "average"
'    BodyArray(2) = "slim/slender"
'    BodyArray(3) = "athletic"
'    BodyArray(4) = "thick"
'    BodyArray(5) = "a little extra padding"
'    BodyArray(6) = "more to love"
'End Sub

'Public HoodArray(37) As String
'Public Sub UseHoodArray()
'    HoodArray(0) = "San Francisco"
'    HoodArray(1) = "bayview / hunter's point"
'    HoodArray(2) = "bernal heights"
'    HoodArray(3) = "castro / eureka valley"
'    HoodArray(4) = "chinatown"
'    HoodArray(5) = "cole valley"
'    HoodArray(6) = "excelsior / outer mission"
'    HoodArray(7) = "financial district / embarcadero"
'    HoodArray(8) = "glen park"
'    HoodArray(9) = "haight ashbury"
'    HoodArray(10) = "hayes valley"
'    HoodArray(11) = "ingleside / merced / ocean view (SFSU,CCSF)"
'    HoodArray(12) = "inner richmond"
'    HoodArray(13) = "inner sunset / parnassus heights (UCSF)"
'    HoodArray(14) = "laurel heights / presidio"
'    HoodArray(15) = "lower haight / fillmore"
'    HoodArray(16) = "marina / cow hollow"
'    HoodArray(17) = "mission district"
'    HoodArray(18) = "nob hill"
'    HoodArray(19) = "noe valley"
'    HoodArray(20) = "north beach / telegraph hill"
'    HoodArray(21) = "pacific heights"
'    HoodArray(22) = "panhandle (USF)"
'    HoodArray(23) = "potrero hill / dogpatch"
'    HoodArray(24) = "richmond / seacliff"
'    HoodArray(25) = "russian hill"
'    HoodArray(26) = "soma / south beach / mission bay"
'    HoodArray(27) = "sunset / parkside"
'    HoodArray(28) = "tenderloin / civic center"
'    HoodArray(29) = "tendernob"
'    HoodArray(30) = "twin peaks / diamond heights"
'    HoodArray(31) = "visitacion valley / sunnydale / portola"
'    HoodArray(32) = "west portal / st. francis wood / forest hill"
'    HoodArray(33) = "western addition / japantown"
'    HoodArray(34) = "East Bay"
'    HoodArray(35) = "North Bay"
'    HoodArray(36) = "Peninsula"
'    HoodArray(37) = "South Bay"
'End Sub

'Public EthnicArray(10) As String
'Public Sub UseEthnicArray()
'    EthnicArray(0) = ""
'    EthnicArray(1) = "asian"
'    EthnicArray(2) = "black / african"
'    EthnicArray(3) = "hispanic / latino"
'    EthnicArray(4) = "indian / south asian"
'    EthnicArray(5) = "middle eastern / arab"
'    EthnicArray(6) = "native american"
'    EthnicArray(7) = "pacific islander"
'    EthnicArray(8) = "white / caucasian"
'    EthnicArray(9) = "mixed"
'    EthnicArray(10) = "other"
'End Sub

'Public SignArray(12) As String
'Public Sub UseSignArray()
'    SignArray(0) = ""
'    SignArray(1) = "aquarius"
'    SignArray(2) = "aries"
'    SignArray(3) = "cancer"
'    SignArray(4) = "capricorn"
'    SignArray(5) = "gemini "
'    SignArray(6) = "leo"
'    SignArray(7) = "libra"
'    SignArray(8) = "pisces"
'    SignArray(9) = "sagittarius"
'    SignArray(10) = "scorpio"
'    SignArray(11) = "taurus"
'    SignArray(12) = "virgo"
'End Sub
