'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object

'Returns either ErrorMessage or GoodNews, never both.
Imports System.Configuration
Imports System.Data
Imports System.Data.Odbc

Imports Globals

Public Class Favorite : Inherits Page

    Private _ProfileID As String
    Private _FavoriteID As String
    Private _FavoriteName As String
    Private _ErrorMessage As String
    Private _GoodNews As String

    Public Property ProfileID() As String
        Get
            Return _ProfileID
        End Get
        Set(ByVal value As String)
            _ProfileID = value
        End Set
    End Property

    Public Property FavoriteID() As String
        Get
            Return _FavoriteID
        End Get
        Set(ByVal value As String)
            _FavoriteID = value
        End Set
    End Property

    Public Property FavoriteName() As String
        Get
            Return _FavoriteName
        End Get
        Set(ByVal value As String)
            _FavoriteName = value
        End Set
    End Property

    Public ReadOnly Property ErrorMessage() As String
        Get
            Return _ErrorMessage
        End Get
    End Property

    Public ReadOnly Property GoodNews() As String
        Get
            Return _GoodNews
        End Get
    End Property

    Public Sub Add()
        If (IsNumeric(_ProfileID) = False Or IsNumeric(_FavoriteID) = False) Then
            _ErrorMessage = "There was an error while trying to add someone to your favorites."
        Else
            'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
            Dim objConnection As New OdbcConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
            Dim objDataReader As OdbcDataReader
            Dim objCommand As New OdbcCommand
            objCommand.Connection = objConnection
            objConnection.Open()
            '0. Check to see if the favorite to be added is active.
            'TODO: Move to Parameterized Stored Procedure
            objCommand.CommandText = String.Format("SELECT ProfileStatusID FROM Profiles WHERE ProfileID={0};", _FavoriteID)
            objDataReader = objCommand.ExecuteReader()
            If Not (objDataReader.Read()) Then
                _ErrorMessage = "The profile you tried to add was deleted or does not exist."
                objDataReader.Close()
            Else
                Dim intProfileStatusID As Byte = objDataReader("ProfileStatusID")
                objDataReader.Close()
                If intProfileStatusID = 3 Then
                    _ErrorMessage = "The profile you tried to add is suspended."
                ElseIf intProfileStatusID = 4 Then
                    _ErrorMessage = "The profile you tried to add was deleted or does not exist."
                ElseIf intProfileStatusID = 2 Then
                    '1. Check to see if the record already exists.
                    'TODO: Move to Parameterized Stored Procedure
                    objCommand.CommandText = String.Format("SELECT RecordID FROM favorites WHERE ProfileID={0} AND FavoriteID={1};", _ProfileID, _FavoriteID)
                    objDataReader = objCommand.ExecuteReader()
                    If objDataReader.Read() Then
                        _ErrorMessage = String.Format("<strong>{0}</strong> is already one of your <a href=""favorites.aspx"" class=""stayBlue"">favorites</a>.", _FavoriteName) 'TODO: Move errormessage or status message object
                        'TODO: String.format above prior to extracting
                        'TODO: Move link href to PageURL object then Reference object
                        objDataReader.Close()
                    Else
                        Dim intRecords As Byte
                        objDataReader.Close()
                        '2. Check to see if user has reached maximum number of favorites.
                        'TODO: Move to Parameterized Stored Procedure
                        objCommand.CommandText = String.Format("SELECT Count(*) FROM favorites WHERE ProfileID={0};", _ProfileID)
                        intRecords = CByte(objCommand.ExecuteScalar())
                        If intRecords >= MAX_FAVORITES Then
                            _ErrorMessage = String.Format("Sorry. You've already reached your maximum of {0} favorites.", MAX_FAVORITES)
                        Else
                            'Check to see if the 2 users are soon to be mutual favorites.
                            Dim intMutualFavorite As Byte = 0
                            'TODO: Move to Parameterized Stored Procedure
                            objCommand.CommandText = String.Format("SELECT RecordID FROM favorites WHERE ProfileID={0} AND FavoriteID={1};", _FavoriteID, _ProfileID)
                            objDataReader = objCommand.ExecuteReader()
                            If objDataReader.Read() Then
                                intMutualFavorite = 1
                            End If
                            objDataReader.Close()
                            'INSERT the record into the Favorites table.
                            objCommand.CommandText = String.Format("INSERT INTO favorites (ProfileID,FavoriteID,MutualFavorite) VALUES ({0},{1},{2});", _ProfileID, _FavoriteID, intMutualFavorite)
                            objCommand.ExecuteNonQuery()
                            If intMutualFavorite = 1 Then
                                'UPDATE the record into the Favorites table.
                                objCommand.CommandText = String.Format("UPDATE favorites SET MutualFavorite=1 WHERE ProfileID={0} AND FavoriteID={1};", _FavoriteID, _ProfileID)
                                objCommand.ExecuteNonQuery()
                            End If
                            _GoodNews = String.Format("<strong>{0}</strong> was added to your list of <a href=""favorites.aspx"" class=""stayBlue"">favorites</a>.", _FavoriteName) 'TODO: Move link href to PageURL object then Reference object
                            'TODO: Try to add a server object HL to the page... 
                            'TODO: Move to errormessage or status message object
                        End If
                    End If
                End If
            End If
            objConnection.Close()
            objConnection.Dispose()
        End If
    End Sub

    Sub New()
        _ErrorMessage = String.Empty
        _GoodNews = String.Empty
    End Sub
End Class