﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object

Imports Microsoft.VisualBasic

Namespace Configuration.ServerInfo
    Public Class ServerInfo
#Region "SMTP (Email)"
        ''' <summary>
        ''' SMTP Servers
        ''' </summary>
        ''' <remarks>
        ''' Set values inside "web.config"
        ''' TODO: Define server roles
        ''' </remarks>
        Public ReadOnly SMTP_SERVER_1 As String = ConfigurationSettings.AppSettings("SMTP_SERVER_1")
        Public ReadOnly SMTP_SERVER_2 As String = ConfigurationSettings.AppSettings("SMTP_SERVER_2")
#End Region

#Region "HTTP (Web)"
        ''' <summary>
        ''' HTTP Servers 
        ''' </summary>
        ''' <remarks>
        ''' Set values inside "web.config"
        ''' Serving Front-End and Code-Behind
        ''' </remarks>
        Public ReadOnly HTTP_SERVER_WWW_1 As String = ConfigurationSettings.AppSettings("HTTP_SERVER_WWW_1")
        Public ReadOnly HTTP_SERVER_WWW_2 As String = ConfigurationSettings.AppSettings("HTTP_SERVER_WWW_2")

        ''' <summary>
        ''' Cookie-Less Domain Servers
        ''' </summary>
        ''' <remarks>
        ''' Set values inside "web.config"
        ''' Serving *.css, *.js and site template images (*.png, *.gif and *.jpg)
        ''' </remarks>
        Public ReadOnly HTTP_SERVER_CLD_1 As String = ConfigurationSettings.AppSettings("HTTP_SERVER_CLD_1")
        Public ReadOnly HTTP_SERVER_CLD_2 As String = ConfigurationSettings.AppSettings("HTTP_SERVER_CLD_2")

        ''' <summary>
        ''' REST Web Service Servers
        ''' </summary>
        ''' <remarks>
        ''' Set values inside "web.config"
        ''' Servicing Webservice traffic for internal AJAX requests / API calls
        ''' </remarks>
        Public ReadOnly HTTP_SERVER_REST_1 As String = ConfigurationSettings.AppSettings("HTTP_SERVER_REST_1")
        Public ReadOnly HTTP_SERVER_REST_2 As String = ConfigurationSettings.AppSettings("HTTP_SERVER_REST_2")
#End Region
    End Class
End Namespace
