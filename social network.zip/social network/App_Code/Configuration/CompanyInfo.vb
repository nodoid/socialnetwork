﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
'TODO: Move all strings to RegEx to localize if necessary
Imports Microsoft.VisualBasic

Namespace Configuration.CompanyInfo
    Public Class CompanyInfo
        ''' <summary>
        ''' Company Info
        ''' </summary>
        ''' <remarks>
        ''' TODO: Move info to *.resx (if localization is needed) || web.config 
        ''' </remarks>
        Shared Property COMPANY_NAME As String = "Social Conveyors, LLC."
        Shared Property COMPANY_ADDRESS As String = "[COMPANY ADDRESS]"
        Shared Property COMPANY_CITY As String = "[COMPANY CITY]"
        Shared Property COMPANY_STATE As String = "California"
        Shared Property COMPANY_ZIP As String = "[COMPANY ZIP]"
        Shared Property COMPANY_DOMAIN As String = "SocialConveyors.com"
    End Class
End Namespace
