﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object

Imports Microsoft.VisualBasic

Namespace Configuration.ErrorMessages
    Public Class ErrorMessages
#Region "NOT Currently in Use"
        Shared Property ERROR_MESSAGE_GENERAL_ERROR As String = "An unexpected error has happened! Sorry!<br><br>" + "A message regarding this error has been forwarded to the SocialConveyors technical group.<br><br>" + "Help us further by <a href='contact_2bmates.aspx?subject=Error' target='_blank' class='clear'>clicking here</a> to send your feedback."
        Shared Property ERROR_MESSAGE_MISSING_PARAMETERS As String = "An unexpected error has happened! Sorry!<br><br>" + "A message regarding this error has been forwarded to the SocialConveyors technical group.<br><br>" + "Help us further by <a href='contact_2bmates.aspx?subject=Error' target='_blank' class='clear'>clicking here</a> to send your feedback."
        Shared Property ERROR_MESSAGE_NO_ACCESS As String = Resources.ErrorMessages.ERROR_MESSAGE_NO_ACCESS
        Shared Property ERROR_MESSAGE_UNEXPECTED_ERROR As String = Resources.ErrorMessages.ERROR_MESSAGE_UNEXPECTED_ERROR
        Shared Property ERROR_MESSAGE_NO_HTML_ALLOWED As String = Resources.ErrorMessages.ERROR_MESSAGE_NO_HTML_ALLOWED

        Shared Property ERROR_MESSAGE_GROUP_DOESNT_EXIST_ERROR As String = "This group doesn't exist."
        Shared Property ERROR_MESSAGE_GROUP_EVENT_DOESNT_EXIST_ERROR As String = "This group event doesn't exist."
        Shared Property ERROR_MESSAGE_CATEGORY_DOESNT_EXIST_ERROR As String = "This category doesn't exist."

        Shared Property ERROR_MESSAGE_ACCESS_ONLY_MODERATOR As String = "You are not authorised to view this page. Only moderators have rights to change the group properties."
        Shared Property ERROR_MESSAGE_ACCESS_ONLY_MODERATOR_CAN_POST_BLOG As String = "Only the moderator of the group can post new blog or edit an existing one."
        Shared Property ERROR_MESSAGE_ACCESS_ONLY_MODERATOR_CAN_DELETE_BLOG As String = "Only the moderator of the group can delete group blogs."
        Shared Property ERROR_MESSAGE_ACCESS_MODERATOR_CANNOT_UNSUBSCRIBE As String = "You are the moderator of this group and cannot unsubscribe from it."

        Shared Property ERROR_MESSAGE_ACCESS_ONLY_MEMBERS_CAN_POST_COMMENTS As String = "Only members can post comments."
        Shared Property ERROR_MESSAGE_ACCESS_ONLY_MEMBERS_CAN_UNSUBSCRIBE As String = "Only the members of the group can unsubscribe."
        Shared Property ERROR_MESSAGE_ACCESS_ONLY_MEMBERS_CAN_VIEW_MESSAGES As String = "Only the members of the group can view this page."

        Shared Property ERROR_MESSAGE_BLOG_ONLY_MEMBERS_ACCESS As String = "Only members can post blog comments."
        Shared Property ERROR_MESSAGE_NOT_FRIEND As String = "The user you are trying to send a message is not your friend."
        Shared Property ERROR_MESSAGE_NOT_FRIEND_BLOG_COMMENT As String = "Only friends can post comments in blogs."
#End Region
#Region "Currently in Use"
        Shared Property ERROR_MESSAGE_LOGIN_INVALID_1 As String = Resources.ErrorMessages.ERROR_MESSAGE_LOGIN_INVALID_1
        Shared Property ERROR_MESSAGE_LOGIN_INVALID_2 As String = Resources.ErrorMessages.ERROR_MESSAGE_LOGIN_INVALID_2
        Shared Property ERROR_MESSAGE_LOGIN_SUSPENDED As String = Resources.ErrorMessages.ERROR_MESSAGE_LOGIN_SUSPENDED
        Shared Property ERROR_MESSAGE_LOGIN_INACTIVE As String = Resources.ErrorMessages.ERROR_MESSAGE_LOGIN_INACTIVE

        Shared Property ERROR_MESSAGE_ACCOUNT_DELETED As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_DELETED
        Shared Property ERROR_MESSAGE_ACCOUNT_SUSPENDED As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_SUSPENDED

        Shared Property ERROR_MESSAGE_ACCOUNT_ACTIVATION_INVALID_CODE As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_ACTIVATION_INVALID_CODE
        Shared Property ERROR_MESSAGE_ACCOUNT_ACTIVATION_ALREADY_ACTIVE As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_ACTIVATION_ALREADY_ACTIVE

        Shared Property ERROR_MESSAGE_ACCOUNT_EXISTS_NAME As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_EXISTS_NAME
        Shared Property ERROR_MESSAGE_ACCOUNT_EXISTS_EMAIL As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_EXISTS_EMAIL
        Shared Property ERROR_MESSAGE_ACCOUNT_EXISTS_ABUSER As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_EXISTS_ABUSER
        Shared Property ERROR_MESSAGE_ACCOUNT_EMAIL_SEND_ERROR As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_EMAIL_SEND_ERROR

        Shared Property ERROR_MESSAGE_ACCOUNT_CREATE_ERROR As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_CREATE_ERROR
        Shared Property ERROR_MESSAGE_ACCOUNT_CREATE_ERROR2 As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_CREATE_ERROR2

        Shared Property ERROR_MESSAGE_VIEW_PROFILE_INACTIVE As String = Resources.ErrorMessages.ERROR_MESSAGE_VIEW_PROFILE_INACTIVE
        Shared Property ERROR_MESSAGE_VIEW_PROFILE_DELETED As String = Resources.ErrorMessages.ERROR_MESSAGE_VIEW_PROFILE_DELETED
        Shared Property ERROR_MESSAGE_VIEW_PROFILE_SUSPENDED As String = Resources.ErrorMessages.ERROR_MESSAGE_VIEW_PROFILE_SUSPENDED



        'You entered the wrong e-mail address. Please try again. (002)
        '
        Shared Property ERROR_MESSAGE_ACCOUNT_USERNAME_DOESNT_EXIST As String = Resources.ErrorMessages.ERROR_MESSAGE_ACCOUNT_USERNAME_DOESNT_EXIST 'The user name <strong>{0}</strong> does not exist.

        'Thanks for taking the time to report abuse of the site.
        'Please login before adding favorites.
        'Please login to report abuse of the site.
        'The subject or message was blank.
        'Your message has been sent.
        'This page requires a Profile ID number.
#End Region

        Shared Property ERROR_MESSAGE_DB As String = Resources.ErrorMessages.ERROR_MESSAGE_DB
    End Class
End Namespace