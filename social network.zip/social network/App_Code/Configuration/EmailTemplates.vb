﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object

Imports Microsoft.VisualBasic

Namespace Configuration.EmailTemplates
    Public Class EmailTemplate
        ''' <summary>
        ''' EMAIL_ Templates 
        ''' </summary>
        ''' <remarks>
        ''' TODO: Move text to *.resx and localize
        ''' </remarks>
        Public Const NOTIFY_NEW_FRIEND_SUBJECT As String = "NOTIFY_NEW_FRIEND_SUBJECT"
        Public Const NOTIFY_NEW_FRIEND_BODY As String = "NOTIFY_NEW_FRIEND_BODY"

        Public Const NOTIFY_FRIEND_RequestSUBJECT As String = "NOTIFY_FRIEND_RequestSUBJECT"
        Public Const NOTIFY_FRIEND_RequestBODY As String = "NOTIFY_FRIEND_RequestBODY"

        Public Const NOTIFY_NEW_MAIL_SUBJECT As String = "NOTIFY_NEW_MAIL_SUBJECT"
        Public Const NOTIFY_NEW_MAIL_BODY As String = "NOTIFY_NEW_MAIL_BODY"

        Public Const NOTIFY_NEW_BLOG_SUBJECT As String = "NOTIFY_NEW_BLOG_SUBJECT"
        Public Const NOTIFY_NEW_BLOG_BODY As String = "NOTIFY_NEW_BLOG_BODY"

        Public Const INVITE_MAIL_SUBJECT As String = "INVITE_MAIL_SUBJECT"
        Public Const INVITE_MAIL_BODY As String = "INVITE_MAIL_BODY"
        Public Const INVITE_BODY_NONE As String = "INVITE_BODY_NONE"

        Public Const PASS_MAIL_SUBJECT As String = "PASS_MAIL_SUBJECT"
        Public Const PASS_MAIL_BODY As String = "PASS_MAIL_BODY"

        Public Const REGISTRATION_MAIL_SUBJECT As String = "REGISTRATION_MAIL_SUBJECT"
        Public Const REGISTRATION_MAIL_BODY As String = "REGISTRATION_MAIL_BODY"

        Public Const FEEDBACK_MAIL_SUBJECT As String = "FEEDBACK_MAIL_SUBJECT"
        Public Const FEEDBACK_MAIL_BODY As String = "FEEDBACK_MAIL_BODY"
        Public Const FEEDBACK_NONE As String = "FEEDBACK_NONE"

        Public Const NO_SPAM_DISCLAIMER As String = "NoSpamDisclaimer"


        'TODO: Make EXTERNAL *.resx Template
        Shared Property ACTIVATE_ACCOUNT_SUBJECT As String = "www.SocialConveyors.com:  Your new profile needs to be activated"
        Shared Property ACTIVATE_ACCOUNT_BODY As String = "<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">" & _
        "<html><head><title>[EMAIL TITLE]</title><meta http-equiv=""Content-Type"" content=""text/html; charset=iso-8859-1"">" & _
        "<style>" & _
        "/* move/add styles here from markup below */" & _
        "</style>" & _
        "</head>" & _
        "<body marginheight=""0"" marginwidth=""0"" topmargin=""0"" leftmargin=""0"" bgcolor=""#f2f2f2"">" & _
        "<table width=""100%"" height=""100%"" border=""0"" cellspacing=""0"" cellpadding=""0"" bgcolor=""#f2f2f2""><tr><td valign=""top"" align=""center"">" & _
        "<table width=""551"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td align=""left"" style=""padding:10px 0 10px 10px; font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#888888;"">Images not displaying properly? Add <a href=""mailto:info@yourcompany.com"" style=""color:#545454;"">info@yourcompany.com</a> to your address book now<br>or <a href=""[SHOWEMAIL]"" style=""color:#545454;"">view the online version here</a>.</td></tr><tr><td align=""left"" bgcolor=""#ffffff"" style=""border:1px solid #9c9c9c; padding:5px;""><div style=""border:7px solid #424242;""><table width=""525"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td style=""padding:25px 20px 20px 20px;"">" & _
        "<table width=""485"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td><img src=""[LOGO]"" alt=""{4}"" width=""155"" height=""29""></td>" & _
        "<td align=""right"" valign=""middle"" style=""font-family:Arial, Helvetica, sans-serif; font-size:18px; color:#acabab;"">{3}" & _
        "</td></tr></table></td></tr><tr><td><div style=""border-bottom:1px solid #d6d6d6; border-top:1px solid #d6d6d6; padding-bottom:3px; padding-top:3px;""><div style=""background-color:#424242;""><table height=""39"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr>" & _
        "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""http://www.{0}/subscribe.aspx"" style=""color:#e4e4e4;"">Subscribe</a></td>" & _
        "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""http://www.{0}/unscribe.aspx"" style=""color:#e4e4e4;"">Unsubscribe</a></td>" & _
        "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""http://www.{0}/invite.aspx"" style=""color:#e4e4e4;"">Invite your Friends</a></td>" & _
        "<td>&nbsp;</td></tr></table></div></div></td></tr><tr><td style=""padding:30px 20px 0px 20px; font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#333333; line-height:20px;"">" & _
        "<p style=""margin:0 0 25px 0;"">Dear {1},<br><br>" & _
        "Thank you for creating a profile on Social Conveyors.<br><br>" & _
        "Please click on the link below to activate your profile:<br>" & _
        "http://www.{0}/activateprofile.aspx?username={1}&activationcode={2}<br><br>" & _
        "User Name: {1}<br>" & _
        "Activation Code: {2}<br><br>" & _
        "- <a href=""http://www.{0}"" style=""color:#0165ab;"">Social Conveyors</a></p>" & _
        "</td></tr><tr><td style=""border-top:1px solid #d6d6d6; background-color:#f6f6f6; font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#666666; line-height:17px;  padding:15px 0 15px 20px;"">" & _
        "<b>{4}</b><br>" & _
        "{5}, {6}, {7}, {8}<br>" & _
        "<a href=""mailto:[INFO EMAIL]{0}"" style=""color:#4089bb;"">[INFO EMAIL]</a><br>" & _
        "<a href=""http://www.{0}"" style=""color:#4089bb;"">www.SocialConveyors.com</a>" & _
        "</td></tr></table></div></td></tr><tr><td align=""left"" style=""padding:20px 0 10px 10px; font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#888888;"">" & _
        "To ensure our newsletter always reaches your inbox, please add <a href=""mailto:info@{0}"" style=""color:#545454;"">info@{0}</a> to your<br>" & _
        "address book. If you prefer not to receive news from Your Company Name in the future, you can<br>" & _
        "<a href=""http://www.{0}/unsubscribe.aspx"" style=""color:#545454;"">unsubscribe here</a>." & _
        "</td></tr></table></td></tr></table></body></html>" 'TODO: Move link href to PageURL object then Reference object

        '                    
        'Forgot Email Email Template --------------------------------------------------------------------------------------------------------
        'Dim strBody = ""
        'strBody = strBody & "<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">"
        'strBody = strBody & "<html><head><title>[EMAIL TITLE]</title><meta http-equiv=""Content-Type"" content=""text/html; charset=iso-8859-1""></head>"
        'strBody = strBody & "<body marginheight=""0"" marginwidth=""0"" topmargin=""0"" leftmargin=""0"" bgcolor=""#f2f2f2"">"
        'strBody = strBody & "<table width=""100%"" height=""100%"" border=""0"" cellspacing=""0"" cellpadding=""0"" bgcolor=""#f2f2f2""><tr><td valign=""top"" align=""center"">"
        'strBody = strBody & "<table width=""551"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td align=""left"" style=""padding:10px 0 10px 10px; font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#888888;"">Images not displaying properly? Add <a href=""mailto:info@yourcompany.com"" style=""color:#545454;"">info@yourcompany.com</a> to your address book now<br>or <a href=""[SHOWEMAIL]"" style=""color:#545454;"">view the online version here</a>.</td></tr><tr><td align=""left"" bgcolor=""#ffffff"" style=""border:1px solid #9c9c9c; padding:5px;""><div style=""border:7px solid #424242;""><table width=""525"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td style=""padding:25px 20px 20px 20px;"">"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "<table width=""485"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td><img src=""[LOGO]"" alt=""[COMPANY NAME]"" width=""155"" height=""29""></td>"
        'strBody = strBody & "<td align=""right"" valign=""middle"" style=""font-family:Arial, Helvetica, sans-serif; font-size:18px; color:#acabab;"">"
        'strBody = strBody & Now()
        'strBody = strBody & "</td></tr></table></td></tr><tr><td><div style=""border-bottom:1px solid #d6d6d6; border-top:1px solid #d6d6d6; padding-bottom:3px; padding-top:3px;""><div style=""background-color:#424242;""><table height=""39"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr>"
        'strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[SUBSCRIBE]"" style=""color:#e4e4e4;"">Subscribe</a></td>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[UNSUBSCRIBE]"" style=""color:#e4e4e4;"">Unsubscribe</a></td>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[FORWARD]"" style=""color:#e4e4e4;"">Forward to a friend</a></td>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "<td>&nbsp;</td></tr></table></div></div></td></tr><tr><td style=""padding:30px 20px 0px 20px; font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#333333; line-height:20px;"">"
        'strBody = strBody & "<p style=""margin:0 0 25px 0;"">Dear " & strUserName & ",<br><br>"
        'strBody = strBody & "Your password has been reset. Please login and change your password.<br><br>"
        'strBody = strBody & "User Name: " & strUserName & "<br>"
        'strBody = strBody & "password: " & strNewPassword & "<br><br>"
        'strBody = strBody & "<a href=""http://www.SocialConveyors.com"" style=""color:#0165ab;"">http://www.SocialConveyors.com</a></p>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "</td></tr><tr><td style=""border-top:1px solid #d6d6d6; background-color:#f6f6f6; font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#666666; line-height:17px;  padding:15px 0 15px 20px;"">"
        'strBody = strBody & "<b>[COMPANY NAME]</b><br>"
        'strBody = strBody & "[COMPANY ADDRESS], [COMPANY CITY], [COMPANY STATE], [COMPANY ZIP]<br>"
        'strBody = strBody & "<a href=""mailto:[INFO EMAIL]"" style=""color:#4089bb;"">[INFO EMAIL]</a><br>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "<a href=""http://www.SocialConveyors.com"" style=""color:#4089bb;"">www.SocialConveyors.com</a>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "</td></tr></table></div></td></tr><tr><td align=""left"" style=""padding:20px 0 10px 10px; font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#888888;"">"
        'strBody = strBody & "To ensure our newsletter always reaches your inbox, please add <a href=""mailto:info@yourcompany.com"" style=""color:#545454;"">info@yourcompany.com</a> to your<br>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "address book. If you prefer not to receive news from Your Company Name in the future, you can<br>"
        'strBody = strBody & "<a href=""[UNSUBSCRIBE]"" style=""color:#545454;"">unsubscribe here</a>."'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "</td></tr></table></td></tr></table></body></html>"
        '--------------------------------------------------------------------------------------------------------/Email Template

        'Friend Request Email Template "Hookup" --------------------------------------------------------------------------------------------------------
        'Dim strBody = ""
        'strBody = strBody & "<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">"
        'strBody = strBody & "<html><head><title>[EMAIL TITLE]</title><meta http-equiv=""Content-Type"" content=""text/html; charset=iso-8859-1""></head>"
        'strBody = strBody & "<body marginheight=""0"" marginwidth=""0"" topmargin=""0"" leftmargin=""0"" bgcolor=""#f2f2f2"">"
        'strBody = strBody & "<table width=""100%"" height=""100%"" border=""0"" cellspacing=""0"" cellpadding=""0"" bgcolor=""#f2f2f2""><tr><td valign=""top"" align=""center"">"
        'strBody = strBody & "<table width=""551"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td align=""left"" style=""padding:10px 0 10px 10px; font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#888888;"">Images not displaying properly? Add <a href=""mailto:info@yourcompany.com"" style=""color:#545454;"">info@yourcompany.com</a> to your address book now<br>or <a href=""[SHOWEMAIL]"" style=""color:#545454;"">view the online version here</a>.</td></tr><tr><td align=""left"" bgcolor=""#ffffff"" style=""border:1px solid #9c9c9c; padding:5px;""><div style=""border:7px solid #424242;""><table width=""525"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td style=""padding:25px 20px 20px 20px;"">"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "<table width=""485"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td><img src=""[LOGO]"" alt=""[COMPANY NAME]"" width=""155"" height=""29""></td>"
        'strBody = strBody & "<td align=""right"" valign=""middle"" style=""font-family:Arial, Helvetica, sans-serif; font-size:18px; color:#acabab;"">"
        'strBody = strBody & Now()
        'strBody = strBody & "</td></tr></table></td></tr><tr><td><div style=""border-bottom:1px solid #d6d6d6; border-top:1px solid #d6d6d6; padding-bottom:3px; padding-top:3px;""><div style=""background-color:#424242;""><table height=""39"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr>"
        'strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[SUBSCRIBE]"" style=""color:#e4e4e4;"">Subscribe</a></td>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[UNSUBSCRIBE]"" style=""color:#e4e4e4;"">Unsubscribe</a></td>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[FORWARD]"" style=""color:#e4e4e4;"">Forward to a friend</a></td>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "<td>&nbsp;</td></tr></table></div></div></td></tr><tr><td style=""padding:30px 20px 0px 20px; font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#333333; line-height:20px;"">"
        'strBody = strBody & "<p style=""margin:0 0 25px 0;"">"
        'strBody = strBody & "From: " & _SenderName & "<br>"
        'strBody = strBody & "To: " & strRecipientName & "<br>"
        'strBody = strBody & "Subject: " & Server.HtmlDecode(_Subject) & "<br><br>"
        'strBody = strBody & Server.HtmlDecode(_Body) & "<br><br>"
        'strBody = strBody & "DO NOT REPLY TO THIS MESSAGE<br>"
        'strBody = strBody & "To reply, please login to Social Conveyors at "
        'strBody = strBody & "<a href=""http://www.SocialConveyors.com"" style=""color:#0165ab;"">http://www.SocialConveyors.com</a></p>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "</td></tr><tr><td style=""border-top:1px solid #d6d6d6; background-color:#f6f6f6; font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#666666; line-height:17px;  padding:15px 0 15px 20px;"">"
        'strBody = strBody & "<b>[COMPANY NAME]</b><br>"
        'strBody = strBody & "[COMPANY ADDRESS], [COMPANY CITY], [COMPANY STATE], [COMPANY ZIP]<br>"
        'strBody = strBody & "<a href=""mailto:[INFO EMAIL]"" style=""color:#4089bb;"">[INFO EMAIL]</a><br>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "<a href=""http://www.SocialConveyors.com"" style=""color:#4089bb;"">www.SocialConveyors.com</a>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "</td></tr></table></div></td></tr><tr><td align=""left"" style=""padding:20px 0 10px 10px; font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#888888;"">"
        'strBody = strBody & "To ensure our newsletter always reaches your inbox, please add <a href=""mailto:info@yourcompany.com"" style=""color:#545454;"">info@yourcompany.com</a> to your<br>"'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "address book. If you prefer not to receive news from Your Company Name in the future, you can<br>"
        'strBody = strBody & "<a href=""[UNSUBSCRIBE]"" style=""color:#545454;"">unsubscribe here</a>."'TODO: Move link href to PageURL object then Reference object
        'strBody = strBody & "</td></tr></table></td></tr></table></body></html>"
        '--------------------------------------------------------------------------------------------------------/Email Template

    End Class
End Namespace