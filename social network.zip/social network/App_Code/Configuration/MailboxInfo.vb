﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object

Imports Microsoft.VisualBasic

Public Class MailboxInfo
    ''' <summary>
    ''' Mailboxes
    ''' </summary>
    ''' <remarks>
    ''' Do NOT include domain it will be appended later
    ''' TODO: Move value to "web.config"
    ''' </remarks>
    Public Const EMAIL_ADMIN As String = "admin"
    Public Const EMAIL_SUPPORT As String = "support"
    Public Const EMAIL_SALES As String = "sales"
    Public Const EMAIL_PROMOTION As String = "promo"
    Public Const EMAIL_NEWS As String = "news"
    Public Const EMAIL_INFO As String = "info"
    Public Const EMAIL_CONTACT As String = "contact"
    Public Const EMAIL_INVITE As String = "invites"
End Class
