﻿'***********************************************************************
'NOT FOR USE -  HARVESTING CODE FROM THIS FILE TO MAKE SMALLER AND
'               MORE CONCISE OBJECTS
'***********************************************************************

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections

Namespace Configuration.Generic
    Public Class Configuration
        ' 

#Region "Application Configuration"
        ''' <summary>
        ''' Values stored in "app.config"
        ''' </summary>
        ''' <remarks></remarks>
#Region "Used"

#End Region
#Region "Unused"

        Public Const appConnectionString As String = "ConnectionString" 'TODO: Move into Data Object || config

        Public Const appApplicationURL As String = "ApplicationURL"
        Public Shared appAdmin As Integer = 3

#End Region
#End Region

#Region "Website Configuration"
#Region "Used"

#End Region
#Region "Unused"


        ''' <summary>
        ''' Forum Config
        ''' </summary>
        ''' <remarks></remarks>
        Public Const HAS_FORUM As String = "HAS_FORUM"
        Public Const FORUM_BOARD_ID As String = "BOARDID"
        Public Const appForumConnString As String = "forumConnStr"
        Public Const appChatConnString As String = "chatConnStr"

        ''' <summary>
        ''' General config
        ''' </summary>
        ''' <remarks></remarks>
        Public Const appInitialPassLength As String = "InitialPassLength"
        Public Const appFriendshipMaxRequests As String = "FriendshipMaxEequests"

        Public Const appPictureThumbWidth As String = "PictureThumbWidth"
        Public Const appPictureThumbHeight As String = "PictureThumbHeight"
        Public Const appPictureMaxWidth As String = "PictureMaxWidth"
        Public Const appPictureMaxHeight As String = "PictureMaxHeight"
        Public Const appPictureMaxSize As String = "PictureMaxSize"

        


#End Region
#End Region







        '
        ' Session variables
        '

        Public Shared ssnUserID As String = "SESSION-USER-ID"
        Public Shared ssnSearchFilter As String = "SESSION-SEARCH-FILTER"
        Public Shared ssnSearchFilterTemp As String = "SESSION-SEARCH-FILTER-TEMP"
        Public Shared ssnViewDetails As String = "SESSION-VIEW-DETAILS"
        Public Shared ssnSearchCriteria As String = "SESSION-SEARCH-CRITERIA"
        Public Shared ssnLastError As String = "SESSION-LAST-ERROR"
        Public Shared ssnBrowseFilter As String = "SESSION-ICNETWORKING-BROWSE-FILTER"
        Public Shared ssnBrowse_Criteria As String = "SESSION-ICNETWORKING-BROWSE-CRITERIA"
        Public Shared ssnBrowse_ViewDetails As String = "SESSION-ICNETWORKING-BROWSE-VIEW-DETAILS"
        Public Shared ssnIsMeetPeopleAllChecked As String = "SESSION-ICNETWORKING-BROWSE-MEET-ALL-CHECKED"
        Public Shared ssnIsStatusAnyChecked As String = "SESSION-ICNETWORKING-BROWSE-STATUS-ANY-CHECKED"
        Public Shared ssnSearch_ViewDetailsNotLogged As String = "SESSION-ICNETWORKING-SEARCH-VIEW-DETAILS-NOT-LOGGED"
        Public Shared ssnAdvGroupSearchFilter As String = "SESSION-ICNETWORKING-ADV-GRPUP-SEARCH-FILTER"
        Public Shared ssnAdvGroupSearch_Criteria As String = "SESSION-ICNETWORKING-ADV-GRPUP-SEARCH-CRITERIA"

        Public Shared ssnContentItemComment As String = "SESSION-LEFT-ITEM-COMMENT"
        Public Shared ssnComment As String = "SESSION-COMMENT"

        Public Shared ssnLastUserRequestTime As String = "SESSION-LAST-USER-REQUEST-TIME"
        Public Shared ssnUserOnlineInterval As Integer = 10
        'set the time in munites when the user is considered online if he hasn't requested any page
        '
        ' Cookies
        '

        Public Shared cookiePassword As String = "COOKIE-"
        Public Shared cookieEmail As String = "COOKIE-EMAIL"

        Public Shared cookieBrowse_Filter As String = "COOKIE-BROWSE-FILTER"
        Public Shared cookieBrowse_HasPhoto As String = "COOKIE-BROWSE-HAS-PHOTO"
        Public Shared cookieBrowse_Gender As String = "COOKIE-BROWSE-GENDER"
        Public Shared cookieBrowse_APDating As String = "COOKIE-BROWSE-AP-DATING"
        Public Shared cookieBrowse_APRelationship As String = "COOKIE-BROWSE-AP-RELATIONSHIP"
        Public Shared cookieBrowse_APFriends As String = "COOKIE-BROWSE-AP-FRIENDS"
        Public Shared cookieBrowse_APPartners As String = "COOKIE-BROWSE-AP-PARTNERS"
        Public Shared cookieBrowse_APPenpals As String = "COOKIE-BROWSE-AP-PENPALS"
        Public Shared cookieBrowse_APHangout As String = "COOKIE-BROWSE-AP-HANGOUT"
        Public Shared cookieBrowse_AgeFrom As String = "COOKIE-BROWSE-AGE-FROM"
        Public Shared cookieBrowse_AgeTo As String = "COOKIE-BROWSE-AGE-TO"
        Public Shared cookieBrowse_StatusSingle As String = "COOKIE-BROWSE-STATUS-SINGLE"
        Public Shared cookieBrowse_StatusInRelationship As String = "COOKIE-BROWSE-STATUS-IN-RELATIONSHIP"
        Public Shared cookieBrowse_StatusOpenRelationship As String = "COOKIE-BROWSE-STATUS-OPEN-RELATIONSHIP"
        Public Shared cookieBrowse_StatusMarried As String = "COOKIE-BROWSE-STATUS-OPEN-MARRIED"
        Public Shared cookieBrowse_StatusOpenMarriage As String = "COOKIE-BROWSE-STATUS-OPEN-MARRIAGE"
        Public Shared cookieBrowse_StatusUnknown As String = "COOKIE-BROWSE-STATUS-UNKNOWN"
        Public Shared cookieBrowse_Country As String = "COOKIE-BROWSE-COUNTRY"
        Public Shared cookieBrowse_City As String = "COOKIE-BROWSE-CITY"
        Public Shared cookieBrowse_OrderBy As String = "COOKIE-BROWSE-ORDERBY"

        Public Shared cookieBrowse_Criteria As String = "COOKIE-BROWSE-CRITERIA"
        Public Shared cookieBrowse_ViewDetails As String = "COOKIE-BROWSE-VIEW-DETAILS"

        Public Shared cookieBrowse_isMeetPeopleAllChecked As String = "COOKIE-BROWSE-MEET-PEOPLE-ALL-CHECKED"
        Public Shared cookieBrowse_isStatusAnyChecked As String = "COOKIE-BROWSE-STATUS-ANY-CHECKED"

        Public Shared cookieSearch_ViewDetails As String = "COOKIE-SEARCH-VIEW-DETAILS"

        '
        ' Configuration data, loaded on application start
        '

        Public Shared CONN_STRING As String = ""
        Public Shared BUILD_MAJOR As String = ""
        Public Shared BUILD_MINOR As String = ""

        Public Shared APPLICATION_URL As String = ""
        Public Shared IMAGE_FOLDER As String = "images"

        Public Shared SMTP_SERVER As String = ""
        Public Shared ADMIN_EMAIL As String = ""
        Public Shared CONTACT_US_EMAIL As String = ""
        Public Shared MESSAGES_EMAIL As String = ""
        Public Shared INVITATION_EMAIL As String = ""
        Public Shared INITIAL_PASS_LENGTH As Integer = 0

        Public Shared SHOW_MUSIC As String = ""
        Public Shared SHOW_GAMES As String = ""
        Public Shared SHOW_GROUPS As String = ""
        Public Shared SHOW_HELP As String = ""
        Public Const SHOW_ON As String = "on"

        'Public Shared HAS_FORUM As String = ""
        Public Shared FORUM_DB_CONN_STRING As String = ""
        'Public Shared FORUM_BOARD_ID As String = ""
        Public Shared CHAT_DB_CONN_STRING As String = ""

        Public Shared NOTIFY_NEW_FRIEND_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_FRIEND_BODY As String = ""

        Public Shared NOTIFY_FRIEND_REQUEST_SUBJECT As String = ""
        Public Shared NOTIFY_FRIEND_REQUEST_BODY As String = ""

        Public Shared NOTIFY_NEW_GROUP_MAIL_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_GROUP_MAIL_BODY As String = ""

        Public Shared NOTIFY_NEW_MAIL_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_MAIL_BODY As String = ""

        Public Shared NOTIFY_NEW_BLOG_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_BLOG_BODY As String = ""

        Public Shared NOTIFY_NEW_GROUP_BLOG_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_GROUP_BLOG_BODY As String = ""

        Public Shared NOTIFY_UPDATED_BLOG_SUBJECT As String = ""
        Public Shared NOTIFY_UPDATED_BLOG_BODY As String = ""

        Public Shared NOTIFY_UPDATED_GROUP_BLOG_SUBJECT As String = ""
        Public Shared NOTIFY_UPDATED_GROUP_BLOG_BODY As String = ""

        Public Shared NOTIFY_NEW_BULLETIN_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_BULLETIN_BODY As String = ""

        Public Shared NOTIFY_NEW_USER_COMMENT_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_USER_COMMENT_BODY As String = ""

        Public Shared NOTIFY_NEW_PRIVATE_GROUP_MEMBER_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_PRIVATE_GROUP_MEMBER_BODY As String = ""

        Public Shared NOTIFY_NEW_PUBLIC_GROUP_MEMBER_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_PUBLIC_GROUP_MEMBER_BODY As String = ""

        Public Shared NOTIFY_MEMBERSHIP_ACCEPTED_SUBJECT As String = ""
        Public Shared NOTIFY_MEMBERSHIP_ACCEPTED_BODY As String = ""

        Public Shared NOTIFY_MEMBERSHIP_CANCELED_SUBJECT As String = ""
        Public Shared NOTIFY_MEMBERSHIP_CANCELED_BODY As String = ""

        Public Shared NOTIFY_GROUP_CANCELED_SUBJECT As String = ""
        Public Shared NOTIFY_GROUP_CANCELED_BODY As String = ""

        Public Shared NOTIFY_GROUP_CANCELED_MODERATOR_SUBJECT As String = ""
        Public Shared NOTIFY_GROUP_CANCELED_MODERATOR_BODY As String = ""

        Public Shared NOTIFY_NEW_GROUP_COMMENT_MODERATOR_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_GROUP_COMMENT_MODERATOR_BODY As String = ""

        Public Shared NOTIFY_NEW_GROUP_BULLETIN_MODERATOR_SUBJECT As String = ""
        Public Shared NOTIFY_NEW_GROUP_BULLETIN_MODERATOR_BODY As String = ""

        Public Shared BULLETIN_SEND_GAME_SUBJECT As String = ""

        Public Shared SKYSCR_ADV_CODE As String = ""

        Public Shared NO_SPAM_DISCLAIMER As String = ""

        Public Shared INVITE_MAIL_SUBJECT As String = ""
        Public Shared INVITE_MAIL_BODY As String = ""
        Public Shared INVITE_BODY_NONE As String = ""

        Public Shared INVITE_TO_GROUP_MAIL_SUBJECT As String = ""
        Public Shared INVITE_TO_GROUP_MAIL_BODY As String = ""
        Public Shared INVITE_TO_GROUP_BODY_NONE As String = ""

        Public Shared PASS_MAIL_SUBJECT As String = ""
        Public Shared PASS_MAIL_BODY As String = ""

        Public Shared REG_MAIL_SUBJECT As String = ""
        Public Shared REG_MAIL_BODY As String = ""

        Public Shared FEEDBACK_MAIL_SUBJECT As String = ""
        Public Shared FEEDBACK_MAIL_BODY As String = ""

        Public Shared FEEDBACK_NONE As String = ""
        Public Shared FEEDBACK_ERROR_SUBJECT As String = "Error"

        Public Shared MESSAGE_FORWARD_A_FRIEND_SUBJECT As String = ""
        Public Shared MESSAGE_FORWARD_A_FRIEND_BODY As String = ""

        Public Shared MESSAGE_RECOMMEND_A_MATCH_SUBJECT As String = ""
        Public Shared MESSAGE_RECOMMEND_A_MATCH_BODY As String = ""

        Public Shared MESSAGE_FORWARD_A_GROUP_SUBJECT As String = ""
        Public Shared MESSAGE_FORWARD_A_GROUP_BODY As String = ""

        Public Shared PICTURE_LARGE_THUMB_WIDTH As Integer = 0
        Public Shared PICTURE_LARGE_THUMB_HEIGHT As Integer = 0

        Public Shared PICTURE_THUMB_WIDTH As Integer = 0
        Public Shared PICTURE_THUMB_HEIGHT As Integer = 0

        Public Shared PICTURE_MAX_WIDTH As Integer = 0
        Public Shared PICTURE_MAX_HEIGHT As Integer = 0
        Public Shared PICTURE_MAX_SIZE As Integer = 0

        Public Const PLAYER_AUDIO_HEIGHT As Integer = 42
        Public Const PLAYER_VIDEO_HEIGHT As Integer = 285

        Public Shared NAME_MAX_VISIBLE_CHARS As Integer = 20

        Public Shared FRIENDSHIP_MAX_REQUESTS As Integer = 0
        Public Shared MEMBERSHIP_MAX_REQUESTS As Integer = 0

        Public Shared NETWORK_MAX_DEPTH As Integer = 4

        Public Shared CSS_DEAFULT_FILE_NAME As String = "style.css"

        Public Shared TEXT_AREA_DEFAULT_MAX_CHARS As Integer = 200
        Public Shared TEXT_AREA_INTERESTS_MAX_CHARS As Integer = 300
        Public Shared TEXT_AREA_ABOUT_ME_MAX_CHARS As Integer = 50000
        Public Shared TEXT_AREA_LOOKING_FOR_MAX_CHARS As Integer = 50000
        Public Shared TEXT_AREA_OCCUPATION_MAX_CHARS As Integer = 50000
        Public Shared TEXT_AREA_COMPANIES_MAX_CHARS As Integer = 50000
        Public Shared TEXT_AREA_SCHOOLS_MAX_CHARS As Integer = 50000
        Public Shared TEXT_AREA_AFFILIATIONS_MAX_CHARS As Integer = 50000
        Public Shared TEXT_AREA_LONG_MAX_CHARS As Integer = 50000
        Public Shared TEXT_AREA_PICTURE_COMMENTS_MAX_CHARS As Integer = 1000
        Public Shared TEXT_AREA_USER_COMMENTS_MAX_CHARS As Integer = 2000
        Public Shared TEXT_AREA_MESSAGES_MAX_CHARS As Integer = 2000
        Public Shared TEXT_AREA_LONG_MESSAGES_MAX_CHARS As Integer = 50000
        Public Shared TEXT_AREA_BLOG_MAX_CHARS As Integer = 50000
        Public Shared TEXT_AREA_LEFT_ITEM_CONTENT_MAX_CHARS As Integer = 1000
        Public Shared TEXT_NEWS_CONTENT_MAX_CHARS As Integer = 50000
        Public Shared TEXT_AREA_GROUP_MAX_CHARS As Integer = 10000
        Public Shared TEXT_AREA_SHORT_GROUP_MAX_CHARS As Integer = 300


        Public Shared TEXT_FIELD_DEFAULT_MAX_CHARS As Integer = 50
        Public Shared TEXT_FIELD_MESSAGES_SUBJECT_MAX_CHARS As Integer = 150
        Public Shared TEXT_FIELD_ZIPCODE_CHARS As Integer = 10
        Public Shared TEXT_FIELD_PASSWORD_MAX_CHARS As Integer = 10
        Public Shared TEXT_FIELD_URL_CHARS As Integer = 250
        Public Shared TEXT_FIELD_LEFT_ITEM_LINK_NAME_MAX_CHARS As Integer = 100
        Public Shared TEXT_FIELD_LEFT_ITEM_LINK_URL_MAX_CHARS As Integer = 300
        Public Shared TEXT_FIELD_NEWS_MAX_CHARS As Integer = 400
        Public Shared TEXT_FIELD_GE_DETAILS_MAX_CHARS As Integer = 10000
        Public Shared TEXT_FIELD_ADDRESS_MAX_CHARS As Integer = 100
        Public Shared TEXT_FIELD_BANDSITEURL_MAX_CHARS As Integer = 250
        Public Shared TEXT_FIELD_BANDRECORDLABEL_MAX_CHARS As Integer = 250

        Public Const BLOG_IMAGES_MAX_WIDTH As Integer = 378
        Public Const NEWS_IMAGES_MAX_WIDTH As Integer = 432
        Public Const NEWS_IMAGES_NAME As String = "newsImage"

        Public Shared ARR_MONTHS As String() = New String() {"Jan", "Feb", "Mar", "Apr", "May", "Jun", _
         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}
        Public Shared ARR_GENDER As String() = {"", "Male", "Female"}
        Public Shared ARR_STATUS As String() = {"", "Single/Divorced/Separated", "In a relationship", "Open Relationship", "Married", "Open marriage"}

        'Public Shared ON_KEY_DOWN_SCRIPT As String = "textCounter(this," + Constants.TEXT_AREA_MAX_CHARS_TAG + ");"
        'Public Shared ON_KEY_UP_SCRIPT As String = "textCounter(this," + Constants.TEXT_AREA_MAX_CHARS_TAG + ");"
        Public Shared RESIZE_BLOG_IMAGE_SCRIPT As String = "<script>function resizeImages(){" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "var imgs = document.getElementsByTagName(""img"");" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "var imgWidth, imgHeight, rW, rH" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "var maxWidth = " + BLOG_IMAGES_MAX_WIDTH + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "for(var i = 0; i < imgs.length; i++){" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "if (imgs[i].name == 'blogImage'){" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "with(imgs[i]){" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "imgWidth = imgs[i].width;" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "imgHeight = imgs[i].height;" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "rW = 1;" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "if ( imgWidth > maxWidth ){" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "rW = parseFloat(imgWidth / maxWidth);" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "imgs[i].width = parseInt(imgWidth / rW)" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "imgs[i].height = parseInt(imgHeight / rW)" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "}" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "}" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "}" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "}" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "}</script>"

        Public Shared RESIZE_NEWS_IMAGE_SCRIPT As String = "<script>function resizeImages(){" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "var imgs = document.getElementsByTagName(""img"");" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "var imgWidth, imgHeight, rW, rH" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "var maxWidth = " + NEWS_IMAGES_MAX_WIDTH + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "for(var i = 0; i < imgs.length; i++){" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "if (imgs[i].name == 'newsImage'){" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "with(imgs[i]){" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "imgWidth = imgs[i].width;" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "imgHeight = imgs[i].height;" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "rW = 1;" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "if ( imgWidth > maxWidth ){" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "rW = parseFloat(imgWidth / maxWidth);" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "imgs[i].width = parseInt(imgWidth / rW)" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "imgs[i].height = parseInt(imgHeight / rW)" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "}" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "}" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "}" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "" & Chr(9) & "}" + Environment.NewLine + "" & Chr(9) & "" & Chr(9) & "}</script>"

        ' paging constants
        Public Shared MAX_PICTURES_ON_AWAITING_PAGE As Integer = 10
        Public Shared MAX_PICTURES_ON_PAGE As Integer = 32
        Public Shared MAX_PICTURES_ON_ROW As Integer = 8
        Public Shared MAX_PAGES_NUMS_ON_PAGE As Integer = 5
        Public Shared MAX_PICTURES_ON_WELCOME_PAGE As Integer = 8
        Public Shared MAX_PICTURES_ON_ROW_ON_WELCOME_PAGE As Integer = 4
        Public Shared MAX_MESSAGES_ON_PAGE As Integer = 10
        Public Shared MAX_MESSAGES_ON_WELCOME_PAGE As Integer = 5
        Public Shared MAX_MESSAGES_ON_MEMBERS_PAGE As Integer = 5
        Public Shared COMMENTS_ON_PROFILE_PAGE As Integer = 50
        '15;
        Public Shared MAX_GRID_RESULTS_ON_PAGE As Integer = 10
        Public Shared MAX_GRID_EVENTS_ON_EDIT_PAGE As Integer = 20
        Public Shared MAX_GRID_EVENTS_ON_VIEW_PAGE As Integer = 40
        Public Shared MAX_GRID_EVENTS_ON_GROUP_PAGE As Integer = 10
        Public Shared MAX_LIST_RESULTS_ON_PAGE As Integer = 50
        Public Shared MAX_LIST_RESULTS_ON_SEARCH_PAGE As Integer = 56
        Public Shared MAX_LIST_RESULTS_ON_ROW As Integer = 5
        Public Shared MAX_LIST_RESULTS_ON_ROW_FOR_SEARCH As Integer = 8
        Public Shared MAX_TEMPLATES_ON_ROW As Integer = 3
        Public Shared MAX_NAME_LENGTH_ABOVE_IMAGE As Integer = 11
        Public Shared MAX_NAME_LENGTH_ABOVE_MUSIC_TRACKS As Integer = 25
        Public Shared MAX_LINK_LENGTH As Integer = 25
        Public Shared MAX_GROUP_ABOUT_LENGTH As Integer = 300
        Public Shared MAX_GROUP_HOME_ABOUT_LENGTH As Integer = 100
        Public Shared MAX_GROUP_POPULAR_LENGTH As Integer = 170
        Public Shared MAX_CONTENT_ITEM_DESC_LENGTH As Integer = 100
        Public Shared MAX_MEMBER_GROUPS_ON_PAGE As Integer = 10
        Public Shared MAX_USER_COMMENTS_ON_COMMENTS_PAGE As Integer = 50
        Public Shared MAX_PICTURE_COMMENTS_ON_PAGE As Integer = 50

        Public Const GENDER_ANY As Integer = -1
        Public Const GENDER_UNSPECIFIED As Integer = 0
        Public Const GENDER_MALE As Integer = 1
        Public Const GENDER_FEMALE As Integer = 2

        Public Const GENDER_PREFERENCE_MALE As Integer = 1
        Public Const GENDER_PREFERENCE_FEMALE As Integer = 2
        Public Const GENDER_PREFERENCE_BOTH As Integer = 3

        Public Const MSTATUS_UNKNOWN As Integer = 0
        Public Const MSTATUS_SINGLE As Integer = 1
        Public Const MSTATUS_IN_RELATIONSHIP As Integer = 2
        Public Const MSTATUS_OPEN_RELATIONSHIP As Integer = 3
        Public Const MSTATUS_MARRIED As Integer = 4
        Public Const MSTATUS_OPEN_MARRIAGE As Integer = 5

        Public Const ORDERBY_DEFAULT As Integer = -1
        Public Const ORDERBY_RECENTLY_UPDATED As Integer = 1
        Public Const ORDERBY_LAST_LOGIN As Integer = 2
        Public Const ORDERBY_NEW_USERS As Integer = 3

        Public Shared MEET_PEOPLE_FOR_OPTIONS As Integer = 6
        Public Shared MERITAL_STATUS_OPTIONS As Integer = 6

        Public Const ONLINE_STAUS_ON As Integer = 1
        Public Const ONLINE_STAUS_OFF As Integer = -1

        Public Shared MIN_YEAR As Integer = 1920
        Public Shared MAX_YEAR As Integer = 2005
        '1987;
        Public Shared MIN_YEAR_EVENT As Integer = 2005
        Public Shared MAX_YEAR_EVENT As Integer = 2006

        Public Const MAX_QUARTER As Integer = 4

        Public Shared MIN_AGE As Integer = 0
        Public Shared MAX_AGE As Integer = 85

        Public Shared GENDER_PREFERENCE_BOTH_ID As Integer = 3

        Public Shared RANDOM_USERS_COUNT_ON_WELCOME_PAGE As Integer = 4
        Public Shared RANDOM_USERS_COUNT_ON_DEFAULT_PAGE As Integer = 4

        Public Shared MAX_NEWS_CHARS_ON_SPECIAL_PAGE As Integer = 100

        Public Shared MONTHS As String() = New String() {"Jan", "Feb", "Mar", "Apr", "May", "Jun", _
         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}
        Public Const ENTER_URL_INIT_VALUE As String = "http://"
        Public Const ENTER_URL_NAME_INIT_VALUE As String = "Enter Clip/Song name here"
        Public Const ENTER_URL_IMAGE_INIT_VALUE As String = "http://"
        Public Const ENTER_URL_IMAGE_NAME_INIT_VALUE As String = "Enter Image name here"
        '        Public Const STANDARD_TOP_MENU As String = "<a href='invite_friends.aspx'><b>Invite</b></a> | <a href='search.aspx'><b>Search</b></a> | <a href='browse.aspx'><b>Browse</b></a> | <a href='messages_inbox.aspx'><b>Messages</b></a>  | <a href='groups_main.aspx'><b>Groups</b></a> | <a href='" + Constants.SPECIAL + "?typeID=" + "[music_id]" + "'><b>Music</b></a> | <a href='news_events.aspx'><b>News & Events</b></a> <!--| <a href='#'><b>Classified</b></a>--> | "
        Public Const DEFAULT_PAGE_TITLE As String = "www.SocialConveyor.com, social networking, meeting friends, networking, new friends, find friends, social networks, music, blogs"

        Public Const NEW_USER_REGISTERED As Integer = 0
        Public Const PROFILE_CHANGES_SUBMITTED As Integer = 1
        Public Const [ERROR] As Integer = 2
        Public Const ERROR_NO_DIRECT_FRIEND As Integer = 3
        Public Const ERROR_MISSING_PARAMETERS As Integer = 4



        Public Const GONFIRM_MESSAGE_ADD_USER_PHOTO_ALBUM_COMMENTS As String = "This comment will be posted live\non the user\'s profile. Proceed?"
        Public Const GONFIRM_MESSAGE_ADD_GROUP_PHOTO_ALBUM_COMMENTS As String = "This comment will be posted live\non the group\'s profile. Proceed?"
        Public Const GONFIRM_MESSAGE_ADD_USER_COMMENTS As String = "This comment will be posted live\non the user\'s profile. Proceed?"
        Public Const GONFIRM_MESSAGE_ADD_GROUP_COMMENTS As String = "This comment will be posted live\non the group\'s profile. Proceed?"

        Public Const READ_MESSAGE_STYLE As String = "data_grid"
        Public Const UNREAD_MESSAGE_STYLE As String = "data_grid_unread"

        Public Const SEE_ALL_FRIENDS_EDIT_ACTION As String = "1"

        Public Const FRIENDS_COMMENTS_EDIT_ACTION As String = "1"

        Public Const MESSAGE_REPLY_ACTION As Integer = 0
        Public Const MESSAGE_FORWARD_ACTION As Integer = 1
        Public Const MESSAGE_FORWARD_A_FRIEND_ACTION As Integer = 2
        Public Const MESSAGE_RECOMMEND_ACTION As Integer = 3
        Public Const MESSAGE_FORWARD_A_GROUP_ACTION As Integer = 4
        Public Const MESSAGE_TO_GROUP_ACTION As Integer = 5

        Public Const BULLETIN_SEND_GAME_ACTION As Integer = 0

        Public Const DESC_UPDATE_ACTION As Integer = 0
        Public Const DESC_DELETE_ACTION As Integer = 1

        Public Const JUST_PHOTOS As Integer = 1
        Public Const PHOTOS_AND_INFO As Integer = 2

        Public Const NEW_FRIENDSHIP As Integer = 0
        Public Const ACCEPT_FRIENDSHIP As Integer = 1
        Public Const REJECT_FRIENDSHIP As Integer = 2

        Public Const UNCONFIRMED_STATUS As Integer = 0
        Public Const REGISTRATION_PERIOD As Integer = 30

        Public Const NOTIFICATIONS_DISABLED As Integer = 0
        Public Const NOTIFICATIONS_ENABLED As Integer = 1

        Public Const NEWSLETTER_DISABLED As Integer = 0
        Public Const NEWSLETTER_ENABLED As Integer = 1

        Public Const REGISTRATION_VALUE As Integer = 1

        Public Const BROWSE_MAX_AGE_SELECTED As Integer = 35

        Public Const GROUP_HELP_PAGE_PUBLIC_VALUE As Integer = 1
        Public Const GROUP_HELP_PAGE_APP_MEM_COMM_VALUE As Integer = 2
        Public Const GROUP_HELP_PAGE_APP_MEM_BLOG_COMM_VALUE As Integer = 3
        Public Const GROUP_HELP_PAGE_PRIVACY_SETTINGS_VALUE As Integer = 4
        Public Const GROUP_HELP_PAGE_GROUP_TYPE As Integer = 5

        Public Const GROUP_EVENT_ACTION_ADD_NEW As Integer = 1
        Public Const GROUP_EVENT_ACTION_EDIT As Integer = 2
        Public Const GROUP_EVENT_ACTION_DELETE As Integer = 3

        Public Const DEFAULT_THUMBNAIL_IMAGE_URL As String = "../images/default_thumbnail.gif"
        Public Const BULLETIN_IMAGE_URL As String = "../images/bulletin_image.gif"
        Public Const GROUP_BULLETIN_IMAGE_URL As String = "../images/group_bulletin_image_orange.gif"
        Public Const MESSAGE_IMAGE_URL As String = "../images/sent_image_orange.gif"

        'bigger images
        Public Const BULLETIN_IMAGE_URL_BIG As String = "../images/bulletin_image_big.gif"
        Public Const GROUP_BULLETIN_IMAGE_URL_BIG As String = "../images/group_bulletin_image_orange_big.gif"
        Public Const MESSAGE_IMAGE_URL_BIG As String = "../images/sent_image_orange_big.gif"

        Public Const BG_IMAGE_DEFAULT_TEXT As String = "Enter background image URL here"
        Public Const BG_WAV_DEFAULT_TEXT As String = "Enter .wav file URL here"

        Public Const LINK_TYPE_SONG As String = "Song"
        Public Const LINK_TYPE_CLIP As String = "Clip"
        Public Const LINK_TYPE_IMAGE As String = "Image"
        Public Const LINK_TYPE_PAGE As String = "Page"

        Public Const MSG_TYPE_NAME_MESSAGE As String = "Message"
        Public Const MSG_TYPE_NAME_BULLETIN As String = "Bulletin"
        Public Const MSG_TYPE_NAME_GRP_BULLETIN As String = "Group Bulletin"

        Public Const MUSIC_PAGE As String = "Music"

        Public Const DEFAULT_CATEGORY_NAME As String = "Other"
        Public Const MISC_CATEGORY_NAME As String = "Misc"

        Public Const MUSIC_ARCHIVE_PERIOD As Integer = 12
        ' 12 Month
        Public Const MUSIC_START_MONTH As Integer = 2
        Public Const MUSIC_START_YEAR As Integer = 2005
        Public Const MUSIC_CONTENTCOLUMN_MAX As Integer = 5
        Public Const MUSIC_ARTICLECOLUMN_MAX As Integer = 5
        Public Const MUSIC_INTERVIEWSCOLUMN_MAX As Integer = 5
        Public Const MUSIC_ITEM_LC_MAX As Integer = 10

        Public Const MAX_MEDIA_UPLOADS As Integer = 3
        Public Const MAX_GROUP_MEDIA_UPLOADS As Integer = 4

        Public Shared WELCOME_MESSAGE_SENDER As String = ""
        Public Shared WELCOME_MESSAGE_SUBJECT As String = ""
        Public Shared WELCOME_MESSAGE_BODY As String = ""

        Public Const GROUPS_POPULAR_MAX As Integer = 10

        'tips

        Public Shared TIPS_ARRAY As String() = New String() {"Read the Help section <a href='help.aspx' class='main_text'>Go to Help</a>.", "Add  Descriptions to your Photos. <a href='upload_photo.aspx' class='main_text'>Add Now</a>.", "Add music or graphics to your profile. <a href='change_background.aspx' class='main_text'>Edit Now</a>.", "Search the site for fun people. <a href='search.aspx' class='main_text'>Search Now</a>.", "Add fun people to your Favorites. <a href='view_favorite_users.aspx' class='main_text'>View Favorites</a>.", "Add more information to your profile. <a href='user_profile.aspx' class='main_text'>Edit Now</a>.", _
         "Read the SocialConveyor.com News to stay updated. <a href='news_events.aspx' class='main_text'>Read News</a>.", "Delete someone from your friend list. <a href='see_all_friends.aspx?action=1' class='main_text'>Delete Now</a>.", "Read the Bulletins your friends post. <a href='messages_inbox.aspx' class='main_text'>View Bulletins</a>.", "Send an Invitation to a Friend. <a href='invite_friends.aspx' class='main_text'>Invite Now</a>."}

        ' Admin Links Text

        Public Const AL_CHANGE_SPECIAL_SETTINGS As String = "Change {member}'s special settings"
        Public Const AL_MARK_AS_FEATURED As String = "Mark {member} as featured group."

        ' Music page arrays

        'public static int[] arrMusiciansIDs	 = new int[]{1, 2}; // local
        Public Shared arrMusiciansIDs As Integer() = New Integer() {98, 87}
        ' server
        Public Shared arrMusiciansBoxHeight As String() = New String() {"239", "218", "296"}

        ' script tags to be deleted from content 
        Public Shared arrScriptToBeDeleted As String() = New String() {"onAbort", "onBlur", "onChange", "onClick", "onDblClick", "onDragDrop", _
         "onError", "onFocus", "onKeyDown", "onKeyPress", "onKeyUp", "onload", _
         "onMouseDown", "onMouseMove", "onMouseOut", "onMouseOver", "onMouseUp", "onMove", _
         "onReset", "onResize", "onSelect", "onSubmit", "onUnload", "<script>", _
         "</script>"}

        ' temp gifs directory
        Public Const TEMP_GIF_DIR As String = "\uploads\tmpgif\"
        ' XMLs
        Public Const XML_FILE_LTEXT_PATH As String = "content_long_text.xml"
        ' Pages
        Public Const DEMO As String = "demo.aspx"
        Public Const HELP As String = "help.aspx"
        Public Const TESTIMONIALS As String = "testimonials.aspx"
        Public Const INTERVIEW_CHALK As String = "chalk_interview.aspx"
        Public Const INTERVIEW_FREEBOOTER As String = "freebooter_interview.aspx"
        Public Const SEE_IMAGE As String = "see_image.aspx"
        Public Const PLAY_MUSIC As String = "play_music.aspx"
        Public Const TELL_ME_MORE As String = "tell_me_more.aspx"
        Public Const CHANGE_BACKGROUND As String = "change_background.aspx"
        Public Const CHANGE_PASSWORD As String = "change_password.aspx"
        Public Const FRIENDS_LIST As String = "friends_list.aspx"
        Public Const MY_PROFILE As String = "my_profile.aspx"
        Public Const DELETE_PHOTO As String = "delete_photo.aspx"
        Public Const VIEW_AWAITING_CONFIRMATION As String = "view_awaiting_confirm.aspx"
        Public Const JOIN As String = "join.aspx"
        Public Const LOGOUT As String = "logout.aspx"
        Public Const ERROR_PAGE As String = "error.aspx"
        Public Const BROWSE As String = "browse.aspx"
        Public Const SEARCH As String = "search.aspx"
        Public Const INVITE_FRIENDS As String = "invite_friends.aspx"
        Public Const VIEW_FAVORITE_USERS As String = "view_favorite_users.aspx"
        Public Const VIEW_BLOCKED_USERS As String = "view_blocked_users.aspx"
        Public Const VIEW_MEMBER_BLOG_COMMENTS As String = "view_member_blog_comments.aspx"
        Public Const POST_MEMBER_BLOG_COMMENT As String = "post_member_blog_comment.aspx"
        Public Const VIEW_MEMBER_BLOG As String = "view_member_blog.aspx"
        Public Const SPECIAL As String = "special_page.aspx"
        Public Const COMMENTS_CONFIRMATION As String = "comments_confirmation.aspx"
        Public Const FRIENDS_ADD_COMMENT As String = "friends_add_comments.aspx"
        Public Const ADD_PHOTO_ALBUM_COMMENTS As String = "add_photo_album_comments.aspx"
        Public Const CONFIRM_PHOTO_DESCRIPTION As String = "confirm_photo_description.aspx"
        Public Const ADD_PHOTO_DESCRIPTION As String = "add_photo_description.aspx"
        Public Const UPLOAD_PHOTO As String = "upload_photo.aspx"
        Public Const UPLOAD_SONG As String = "upload_song.aspx"
        Public Const UPLOAD_GROUP_SONG As String = "upload_group_song.aspx"
        Public Const SEND_BLOG As String = "send_blog.aspx"
        Public Const POST_BLOG_COMMENT As String = "post_blog_comment.aspx"
        Public Const VIEW_BLOG_COMMENTS As String = "view_blog_comments.aspx"
        Public Const BLOG As String = "blog.aspx"
        Public Const TRASH As String = "messages_trash.aspx"
        Public Const BULLETIN As String = "messages_bulletin.aspx"
        Public Const INBOX As String = "messages_inbox.aspx"
        Public Const DELETE_ACCOUNT As String = "delete_account.aspx"
        Public Const LOOK_AND_FEEL As String = "look_and_feel.aspx"
        Public Const VIEW_MESSAGE As String = "view_message.aspx"
        Public Const PHOTO_POLICY As String = "photo_policy.aspx"
        Public Const SENT_MESSAGE As String = "messages_sent.aspx"
        Public Const SEND_MESSAGE As String = "send_message.aspx"
        Public Const BLOCK_USER As String = "block_user.aspx"
        Public Const ADD_TO_FAVORITES As String = "add_to_favorites.aspx"
        Public Const WELCOME_MSG As String = "welcome_msg.aspx"
        Public Const WELCOME As String = "welcome.aspx"
        Public Const VIEW_MY_PROFILE As String = "view_my_profile.aspx"
        Public Const MEMBERS As String = "members.aspx"
        Public Const USER_PROFILE As String = "user_profile.aspx"
        Public Const LOGIN_PAGE As String = "login.aspx"
        Public Const [DEFAULT] As String = "default.aspx"
        Public Const REGISTRATION_CONFIRM_PAGE As String = "login.aspx"
        Public Const ACCOUNT_SETTINGS_PAGE As String = "account_settings.aspx"
        Public Const SEE_ALL_NETWORK_FRIENDS As String = "see_all_network_friends.aspx"
        Public Const SEE_ALL_FRIENDS As String = "see_all_friends.aspx"
        Public Const FRIENDS_COMMENTS_PAGE As String = "friends_comments.aspx"
        Public Const GROUP_COMMENTS_PAGE As String = "group_comments.aspx"
        Public Const VIEW_PHOTO_ALBUM_COMMENTS_PAGE As String = "view_photo_album_comments.aspx"
        Public Const PHOTO_ALBUM_COMMENTS_CONFIRMATION_PAGE As String = "photo_album_comments_confirmation.aspx"
        Public Const VIEW_MEMBER_PHOTOS_PAGE As String = "view_member_photos.aspx"
        Public Const ADD_FRIEND_CONFIRMATION_PAGE As String = "confirm_add_friend.aspx"
        Public Const INVITE_FRIENDS_PAGE As String = "invite_friends.aspx"
        Public Const CONTACT_us As String = "contact_us.aspx"
        Public Const PERSONALISE As String = "personalise.aspx"
        Public Const HELP_FAV_SONG As String = "help_fav_song.aspx"
        Public Const HELP_FAV_IMAGE As String = "help_fav_image.aspx"
        Public Const CHANGE_EMAIL As String = "change_email.aspx"
        Public Const VIEW_NEWS As String = "view_news.aspx"
        Public Const ADD_NEWS As String = "add_news.aspx"
        Public Const ADD_SPECIAL_PAGE As String = "add_special_page.aspx"
        Public Const ADD_CONTENT_ITEM As String = "add_content_item.aspx"
        Public Const VIEW_CONTENT_ITEM As String = "view_content_item.aspx"
        Public Const CONFIRM_SP_DELETION As String = "confirm_sp_deletion.aspx"
        Public Const SPECIAL_SETTINGS As String = "special_settings.aspx"
        Public Const CREATE_GROUP As String = "create_group.aspx"
        Public Const UPLOAD_GROUP_PHOTO As String = "upload_group_photo.aspx"
        Public Const HELP_GROUPS As String = "help_groups.aspx"
        Public Const GROUPS_MAIN As String = "groups_main.aspx"
        Public Const GROUP_WELCOME As String = "group_welcome.aspx"
        Public Const EDIT_GROUP_BASIC As String = "edit_group_basic.aspx"
        Public Const VIEW_GROUP_PROFILE As String = "view_group_profile.aspx"
        Public Const GROUP As String = "group.aspx"
        Public Const GROUP_CATEGORIES As String = "group_categories.aspx"
        Public Const VIEW_GROUP_PHOTOS As String = "view_group_photos.aspx"
        Public Const MY_GROUPS As String = "my_groups.aspx"
        Public Const CATEGORY_GROUPS As String = "category_groups.aspx"
        Public Const ADV_GROUP_SEARCH As String = "adv_grp_search.aspx"
        Public Const GROUP_SEARCH_RESULTS As String = "grp_search_results.aspx"
        Public Const CONFIRM_JOIN_GROUP As String = "confirm_join_group.aspx"
        Public Const SEE_ALL_MEMBERS As String = "see_all_members.aspx"
        Public Const CONFIRMATION_CANCEL_ACCOUNT As String = "confirmation_cancel_account.aspx"
        Public Const CANCEL_ACCOUNT As String = "cancel_account.aspx"
        Public Const EDIT_GROUP_BANDS As String = "edit_group_bands.aspx"
        Public Const EDIT_GROUP_EVENTS As String = "edit_group_events.aspx"
        Public Const VIEW_GROUP_EVENTS As String = "view_group_events.aspx"
        Public Const CONFIRM_UNSUBSCRIBE As String = "confirm_unsubscribe.aspx"
        Public Const POST_BULLETIN As String = "post_bulletin.aspx"
        Public Const VIEW_FAVORITE_GROUPS As String = "view_favourite_groups.aspx"
        Public Const MESSAGES_GROUP_BULLETIN As String = "messages_group_bulletin.aspx"
        Public Const GROUP_PRIVACY_SETTINGS As String = "group_privacy_settings.aspx"
        Public Const PRIVACY_SETTINGS As String = "privacy_settings.aspx"
        Public Const RESET_COUNT As String = "reset_count.aspx"
        Public Const ABOUT_US_PAGE As String = "about_us.aspx"
        Public Const DEMO1_PAGE As String = "demo1.aspx"
        Public Const DEMO2_PAGE As String = "demo2.aspx"
        Public Const DEMO3_PAGE As String = "demo3.aspx"
        Public Const DEMO4_PAGE As String = "demo4.aspx"
        Public Const NEWS_EVENTS_PAGE As String = "news_events.aspx"
        Public Const PRIVACY_POLICY_PAGE As String = "privacy_policy.aspx"
        Public Const PHOTO_POLICY_PAGE As String = "photo_policy.aspx"
        Public Const THANK_PAGE As String = "thank.aspx"
        Public Const TIPS_PAGE As String = "tips.aspx"
        Public Const TERMS_PAGE As String = "terms.aspx"
        Public Const PROMOTE_PAGE As String = "promote.aspx"
        Public Const PASSWORD_REMINDER As String = "password_reminder.aspx"
        Public Const ADD_LINK As String = "add_link.aspx"
        Public Const MESSAGES_BULLETIN_PAGE As String = "messages_bulletin.aspx"
        Public Const MESSAGES_GROUP_BULLETIN_PAGE As String = "messages_group_bulletin.aspx"
        Public Const MESSAGES_INBOX_PAGE As String = "messages_inbox.aspx"
        Public Const MESSAGES_SENT_PAGE As String = "messages_sent.aspx"
        Public Const MESSAGES_TRASH_PAGE As String = "messages_trash.aspx"
        Public Const VIEW_ALL_NEWS_PAGE As String = "view_all_news.aspx"
        Public Const VIEW_ALL_CONTENT_ITEMS_PAGE As String = "view_all_content_items.aspx"
        Public Const FORUM_PAGE As String = "forum.aspx"

        Public Const LINK_MEMBER_ACTIVE As String = "../{0}?id={1}"
        Public Const LINK_MEMBER_CANCELED As String = "../{0}?id={1}"
        ' show message - "../#"; , redirect - "../{0}?id={1}"
        Public Const SCRIPT_LINK_MEMBER_ACTIVE As String = "return;"
        Public Const SCRIPT_LINK_MEMBER_CANCELED As String = "return;"
        ' show message - document.getElementById('{0}').className='visible'; , redirect - return;
        Public Const VIEW_NEWS_PAGE_TITLE As String = "News & Reviews"
        Public Const VIEW_INTERVIEW_PAGE_TITLE As String = "Interviews"

        Public Const FRIENDS_SORT_BY_PARAM As String = "sortby"
        Public Const FRIENDS_SORT_BY_MOST_RECENT As String = "mr"
        Public Const FRIENDS_SORT_BY_GENDER As String = "g"
        Public Const FRIENDS_SORT_BY_ONLINE As String = "o"
        Public Const FRIENDS_SORT_BY_AGE As String = "a"
        Public Const FRIENDS_SORT_BY_NAME As String = "n"

        Public Const GROUP_SORT_BY_PARAM As String = "sortby"
        Public Const GROUP_SORT_BY_MOST_RECENT As String = "mr"
        Public Const GROUP_SORT_BY_POPULARITY As String = "p"
        Public Const GROUP_SORT_BY_NAME As String = "n"

        Public Const REGISTRATION_CONFIRM_PARAM_ACTION As String = "confirm"
        Public Const REGISTRATION_CONFIRM_PARAM_ACTION_VALUE As String = "true"

        Public Const LOGIN_PARAM_USER As String = "email"
        Public Const LOGIN_PARAM_KEY As String = "key"

        Public Const REGISTRATION_PARAM_REFERER As String = "ref"

        Public Const INTEREST_PARAM As String = "intrst"
        Public Const GENDER_PARAM As String = "gndr"
        Public Const MSTATUS_PARAM As String = "stat"
        Public Const COUNTRY_PARAM As String = "cntry"
        Public Const CITY_PARAM As String = "city"
        Public Const AFFILIATIONS_PARAM As String = "aff"
        Public Const COMPANIES_PARAM As String = "comp"
        Public Const SCHOOLS_PARAM As String = "sch"
        Public Const MUSIC_PARAM As String = "msc"
        Public Const BOOKS_PARAM As String = "bks"
        Public Const TV_PARAM As String = "tv"
        Public Const MOVIES_PARAM As String = "mv"
        Public Const OCCUPATION_PARAM As String = "occ"

        Public Const SUBJECT_PARAM As String = "subject"

        Public Const REGISTRATION_PARAM As String = "reg"

        Public Const ACTION_PARAM As String = "action"

        Public Const FORWARD_A_FRIEND_PARAM As String = "fuid"

        Public Const RECOMMENDED_USER_PARAM As String = "rid"
        Public Const RECOMMENDED_TO_USER_PARAM As String = "uid"

        Public Const FORWARD_A_GROUP_PARAM As String = "fgid"

        Public Const GROUP_MODERATOR_PARAM As String = "modid"

        Public Const CONFIRM_PARAM As String = "conf"

        Public Const SPECIAL_PAGE_TYPE_ID_PARAM As String = "typeID"

        Public Const SPECIAL_SETTINGS_USER_PARAM As String = "userID"

        Public Const GROUP_PARAM As String = "grpID"
        Public Const GROUP_IMG_PARAM As String = "grpPhotoID"
        Public Const GROUP_HELP_PAGE_PARAM As String = "helpID"
        Public Const CATEGORY_PARAM As String = "catID"
        Public Const KEYWORD_PARAM As String = "kwd"
        Public Const PAGE_FROM As String = "pageFrom"
        Public Const USER_MODE_PARAM As String = "userMode"
        Public Const MSG_TYPE_PARAM As String = "msgType"

        Public Const GROUP_EVENT_ACTION_PARAM As String = "act"
        Public Const GAME_LINK_PARAM As String = "game"

        Public Const IMAGE_PAGE As String = "ImageContent.aspx"
        Public Const IMAGE_OBJID As String = "objid"
        Public Const IMAGE_ID As String = "id"
        Public Const IMAGE_IS_THUMB As String = "isThumbnail"
        Public Const IMAGE_IS_LARGE_THUMB As String = "isLargeThumbnail"
        Public Const IMAGE_IS_USER As String = "isUser"
        Public Const IMAGE_IS_GROUP As String = "isGroup"
        Public Const IMAGE_IS_NEWS As String = "isNews"

        Public Const LABEL_DEFAULT_VALUE As String = "Not signed yet!"

        ' Message boxes
        Public Const MSGBOX_PARAM As String = "type"
        Public Const MSGBOX_INBOX As String = "inbox"
        Public Const MSGBOX_SENT As String = "sent"
        Public Const MSGBOX_BULLETIN As String = "bulletin"
        Public Const MSGBOX_GROUP_BULLETIN As String = "grp_bulletin"
        Public Const MSGBOX_TRASH As String = "trash"

        Public Const PRIVACY_EMAIL As String = "privacy@socialconveyor.com"
        Public Const TXT_PRIVACY_MAIL_LINK As String = "%privacy_email%"

        ' Text tag constants
        Public Const TXT_GRP_PROFILE_LINK_TAG As String = "%grp_profile_link%"
        Public Const TXT_FRIENDSHIP_REQUEST_LINK_TAG As String = "%friend_req_link%"
        Public Const TXT_MEMBERSHIP_REQUEST_LINK_TAG As String = "%member_req_link%"
        Public Const TXT_SEE_ALL_FRIENDS_LINK_TAG As String = "%see_all_fiends%"
        Public Const TXT_MAIL_LINK_TAG As String = "%mail_link%"
        Public Const TXT_COMMENT_LINK_TAG As String = "%comment_link%"
        Public Const TXT_BLOG_LINK_TAG As String = "%blog_link%"
        Public Const TXT_ACC_LINK_TAG As String = "%acc_link%"
        Public Const TXT_REG_LINK_TAG As String = "%reg_link%"
        Public Const TXT_USER_NAME_TAG As String = "%usr_name%"
        Public Const TXT_USER_EMAIL_TAG As String = "%usr_email%"
        Public Const TXT_USER_TEXT_TAG As String = "%usr_text%"
        Public Const TXT_GROUP_NAME_TAG As String = "%group_name%"
        Public Const TXT_DISCLAIMER_TEXT_TAG As String = "%disclaimer_text%"
        Public Const TXT_GROUPS_MAIN_LINK_TAG As String = "%groups_main_link%"
        Public Const TXT_GROUP_COMMENTS_LINK_TAG As String = "%group_comments_link%"
        Public Const TXT_GROUP_BULLETIN_LINK_TAG As String = "%group_bulletin_link%"
        Public Const TXT_GROUP_LINK_TAG As String = "%group_link%"
        Public Const TXT_SEE_MY_GROUPS_LINK_TAG As String = "%my_groups_link%"

        Public Const TXT_RECOMMENDED_FROM_TAG As String = "%recommended_from%"
        Public Const TXT_RECOMMEND_A_MATCH_LINK1_TAG As String = "%recommend_link1%"
        Public Const TXT_RECOMMEND_A_MATCH_LINK2_TAG As String = "%recommend_link2%"

        Public Const TXT_INVITE_OPTIONAL_TEXT_TAG As String = "%optional_text%"

        Public Const TEXT_AREA_MAX_CHARS_TAG As String = "%text_area_max_chars%"

        Public Const BLOG_ADD_IMAGE_TAG As String = "[IMAGE=]"
        Public Const BLOG_ADD_LINK_TAG As String = "[LINK=]"

        'Public Shared SESSIONS As New Hashtable()
        'Public Shared LOGGED_USERS_IDS As New Hashtable()
        'Public Shared COUNTRIES As BO.Countries = Nothing
        'Public Shared SPECIALPAGES As BO.SpecialPages = Nothing
        'Public Shared LINKTYPES As BO.LinkTypes = Nothing
        'Public Shared CATEGORIES As BO.Categories = Nothing
        'Public Shared GENRE As BO.GroupGenres = Nothing
        'Public Shared LABELTYPES As BO.LabelTypes = Nothing

        'Public Const GROUP_BACK_LINK As String = "Back to "

        Public Sub New()
        End Sub
    End Class
End Namespace