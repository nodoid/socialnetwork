﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports Microsoft.VisualBasic
Imports System
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.Adapters
Public Class RadioButtonListAdapter
    Inherits WebControlAdapter
    Private WRAPPER_CSS_CLASS As String = "rbList"
    Private ITEM_CSS_CLASS As String = "rbListItem"
    Private SELECTED_CSS_CLASS As String = "rbListSelected"
    Private DISABLED_CSS_CLASS As String = "rbListDisabled"
    Private REPEATDIRECTION_CSS_CLASS As String = "rbListRepeatDirection"


    Protected Overrides Sub RenderBeginTag(ByVal writer As HtmlTextWriter)
        ' Div
        writer.AddAttribute(HtmlTextWriterAttribute.Class, WRAPPER_CSS_CLASS)
        writer.AddAttribute(HtmlTextWriterAttribute.Id, Me.Control.ClientID)
        writer.RenderBeginTag(HtmlTextWriterTag.Div)
        writer.Indent += 1

        ' Ul
        Dim cssClass As String = [String].Empty
        If Not String.IsNullOrEmpty(Me.Control.CssClass) Then
            cssClass = Me.Control.CssClass
        End If

        Dim radioList As RadioButtonList = Me.Control

        If Not (radioList Is Nothing) Then
            cssClass += " " + REPEATDIRECTION_CSS_CLASS + radioList.RepeatDirection.ToString()
        End If

        writer.AddAttribute(HtmlTextWriterAttribute.Class, cssClass.Trim())
        writer.RenderBeginTag(HtmlTextWriterTag.Ul)
    End Sub 'RenderBeginTag


    Protected Overrides Sub RenderEndTag(ByVal writer As HtmlTextWriter)
        writer.RenderEndTag() ' Ul
        writer.Indent -= 1
        writer.RenderEndTag() ' Div
    End Sub 'RenderEndTag


    Protected Overrides Sub RenderContents(ByVal writer As HtmlTextWriter)
        Dim buttonList As RadioButtonList = Me.Control '

        If Not (buttonList Is Nothing) Then
            Dim li As ListItem
            For Each li In buttonList.Items
                Dim itemClientID As String = Helpers.GetListItemClientID(buttonList, li)

                ' Li
                Dim cssClass As String = ITEM_CSS_CLASS

                If li.Selected Then
                    cssClass += " " + SELECTED_CSS_CLASS
                End If
                If li.Enabled = False Or buttonList.Enabled = False Then
                    cssClass += " " + DISABLED_CSS_CLASS
                End If
                writer.AddAttribute(HtmlTextWriterAttribute.Class, cssClass)
                writer.RenderBeginTag(HtmlTextWriterTag.Li)

                If buttonList.TextAlign = TextAlign.Right Then
                    RenderRadioButtonListInput(writer, buttonList, li)
                    RenderRadioButtonListLabel(writer, buttonList, li)
                    ' TextAlign.Left
                Else
                    RenderRadioButtonListLabel(writer, buttonList, li)
                    RenderRadioButtonListInput(writer, buttonList, li)
                End If

                writer.RenderEndTag() ' </li>
                If Not (Me.Page Is Nothing) Then
                    Page.ClientScript.RegisterForEventValidation(buttonList.UniqueID, li.Value)
                End If
            Next li
            If Not (Me.Page Is Nothing) Then
                Page.ClientScript.RegisterForEventValidation(buttonList.UniqueID)
            End If
        End If
    End Sub 'RenderContents

    Private Sub RenderRadioButtonListInput(ByVal writer As HtmlTextWriter, ByVal buttonList As RadioButtonList, ByVal li As ListItem)
        ' Input
        writer.AddAttribute(HtmlTextWriterAttribute.Id, Helpers.GetListItemClientID(buttonList, li))
        writer.AddAttribute(HtmlTextWriterAttribute.Type, "radio")
        writer.AddAttribute(HtmlTextWriterAttribute.Name, buttonList.UniqueID)
        writer.AddAttribute(HtmlTextWriterAttribute.Value, li.Value)
        If li.Selected Then
            writer.AddAttribute(HtmlTextWriterAttribute.Checked, "checked")
        End If
        If li.Enabled = False Or buttonList.Enabled = False Then
            writer.AddAttribute(HtmlTextWriterAttribute.Disabled, "disabled")
        End If
        If li.Enabled = True And buttonList.Enabled = True And buttonList.AutoPostBack Then
            writer.AddAttribute(HtmlTextWriterAttribute.Onclick, [String].Format(""))
           
            Helpers.GetListItemUniqueID(buttonList, li)
        End If
        writer.RenderBeginTag(HtmlTextWriterTag.Input)
        writer.RenderEndTag() ' </input>
    End Sub 'RenderRadioButtonListInput


    Private Sub RenderRadioButtonListLabel(ByVal writer As HtmlTextWriter, ByVal buttonList As RadioButtonList, ByVal li As ListItem)
        ' Label
        writer.AddAttribute("for", Helpers.GetListItemClientID(buttonList, li))
        writer.RenderBeginTag(HtmlTextWriterTag.Label)

        writer.Write(li.Text)
        writer.RenderEndTag() ' </label>
    End Sub 'RenderRadioButtonListLabelEnd Class
End Class