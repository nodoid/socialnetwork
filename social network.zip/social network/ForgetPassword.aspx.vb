﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
'Imports System.Web.Mail
Imports System.Net.Mail

Imports Configuration.ErrorMessages

Partial Class forgetpassword
    Inherits System.Web.UI.Page

    Public blnUserLoggedIn As Boolean = False
    Public blnPasswordEmailed As Boolean = False
    Public strErrorMessage As String = ""

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        'Call ProcessLogin()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Set ForgotPassword control parameters here
        If blnUserLoggedIn Then
            mvForgotPassword.SetActiveView(vwPasswordMailed)
        ElseIf Not (blnUserLoggedIn) Then
            mvForgotPassword.SetActiveView(vwUserLoggedOut)
        End If
    End Sub

    Public LOGIN_strErrorMessage As String

    Public Sub ProcessLogin()
        If Request.Form("login") = "yes" Then
            Dim strUserName As String = Request.Form("username")
            Dim strPassword As String = Request.Form("password")
            Dim strRegex As String = "^[a-z0-9A-Z_]{4,16}$"
            'Check if username or password is invalid.
            If Not (Regex.IsMatch(strUserName, strRegex)) Or Not (Regex.IsMatch(strPassword, strRegex)) Then
                LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_INVALID_1
            Else
                Dim intProfileID As Integer
                Dim intProfileStatusID As Byte
                'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
                Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
                Dim objDataReader As SqlDataReader
                'TODO: Move to Parameterized Stored Procedure
                Dim strSQL As String = String.Format("SELECT ProfileID,UserName,ProfileStatusID FROM Profiles WHERE UserName='{0}' AND Password=MD5('{1}');", strUserName, strPassword)
                Dim objCommand As New SqlCommand(strSQL, objConnection) '
                Try
                    objConnection.Open()
                    objDataReader = objCommand.ExecuteReader()
                    If objDataReader.Read() Then
                        intProfileID = objDataReader("ProfileID")
                        strUserName = objDataReader("UserName")
                        intProfileStatusID = CByte(objDataReader("ProfileStatusID"))
                    Else
                        LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_INVALID_2
                    End If
                    objDataReader.Close()
                    Select Case intProfileStatusID
                        Case 1
                            LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_INACTIVE
                        Case 2
                            Session("ProfileID") = intProfileID
                            Session("UserName") = strUserName
                            Session("MessageFolder") = ""
                            objCommand.CommandText = "spUpdateLoginDatebyProfileID"
                            objCommand.Parameters.AddWithValue("@ProfileID", intProfileID)
                            objCommand.ExecuteNonQuery()
                        Case 3
                            LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_SUSPENDED
                    End Select
                    objConnection.Close()
                Catch excep As Exception
                    LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_DB
                End Try
            End If
        End If
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        Dim strUserName As String
        Dim strEmail As String
        If Page.IsPostBack Then
            strUserName = UserName.Text
            strEmail = Email.Text
            'Create ADO objects.
            'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
            Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
            Dim objDataReader As SqlDataReader
            Dim strTrueEmail As String
            Dim strTrueID As String
            Dim intProfileStatusID As Integer

            '1. Make sure the User Name exists.
            'TODO: Move to Parameterized Stored Procedure
            Dim strSQL = String.Format("SELECT ProfileID,Email,ProfileStatusID FROM Profiles WHERE UserName = '{0}';", strUserName)
            Dim objCommand As New SqlCommand(strSQL, objConnection)
            objConnection.Open()
            objDataReader = objCommand.ExecuteReader()
            If Not (objDataReader.Read()) Then
                litErrorMessage.Text = String.Format(ErrorMessages.ERROR_MESSAGE_ACCOUNT_USERNAME_DOESNT_EXIST, strUserName)
                objDataReader.Close()
            Else
                '2. Grab the correct information.
                strTrueEmail = objDataReader.Item("Email")
                strTrueID = objDataReader.Item("ProfileID")
                intProfileStatusID = objDataReader.Item("ProfileStatusID")
                objDataReader.Close()
                If strEmail <> strTrueEmail Then
                    litErrorMessage.Text = "You entered the wrong e-mail address. Please try again. (001)" 'TODO: Move to StatusMessage/ErrorMessage object
                    '3. Make sure the profile is active.
                ElseIf intProfileStatusID = 1 Then
                    litErrorMessage.Text = ErrorMessages.ERROR_MESSAGE_LOGIN_INACTIVE
                ElseIf intProfileStatusID = 3 Then
                    litErrorMessage.Text = ErrorMessages.ERROR_MESSAGE_LOGIN_SUSPENDED
                Else
                    'Create the temporary password by combining a part of the Session ID and a random number.
                    Dim objRandom As New Random()
                    Dim intStart As Integer = objRandom.Next(1, 9)
                    Dim intLastTwo As Integer = objRandom.Next(10, 99)
                    Dim strNewPassword As String
                    strNewPassword = Mid(Session.SessionID, intStart, 10) & CStr(intLastTwo)
                    'UPDATE the profile with the new password.
                    'TODO: Move to Parameterized Stored Procedure
                    objCommand.CommandText = String.Format("UPDATE Profiles SET Password='{0}' WHERE ProfileID={1};", strNewPassword, strTrueID) ' TODO: Add MD5 hash to password
                    objCommand.ExecuteNonQuery()

                    'TODO: Add email Template 
                    Dim mail As MailMessage = New MailMessage()
                    mail.To.Add(Email.Text)
                    mail.From = New MailAddress(ConfigurationManager.AppSettings("PROFILE_EMAIL"))
                    mail.Subject = "Social Conveyors: your requested login information"

                    'Email Template --------------------------------------------------------------------------------------------------------
                    Dim strBody = ""
                    strBody = strBody & "<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">"
                    strBody = strBody & "<html><head><title>[EMAIL TITLE]</title><meta http-equiv=""Content-Type"" content=""text/html; charset=iso-8859-1""></head>"
                    strBody = strBody & "<body marginheight=""0"" marginwidth=""0"" topmargin=""0"" leftmargin=""0"" bgcolor=""#f2f2f2"">"
                    strBody = strBody & "<table width=""100%"" height=""100%"" border=""0"" cellspacing=""0"" cellpadding=""0"" bgcolor=""#f2f2f2""><tr><td valign=""top"" align=""center"">"
                    strBody = strBody & "<table width=""551"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td align=""left"" style=""padding:10px 0 10px 10px; font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#888888;"">Images not displaying properly? Add <a href=""mailto:info@yourcompany.com"" style=""color:#545454;"">info@yourcompany.com</a> to your address book now<br>or <a href=""[SHOWEMAIL]"" style=""color:#545454;"">view the online version here</a>.</td></tr><tr><td align=""left"" bgcolor=""#ffffff"" style=""border:1px solid #9c9c9c; padding:5px;""><div style=""border:7px solid #424242;""><table width=""525"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td style=""padding:25px 20px 20px 20px;"">" 'TODO: Move link href to PageURL object then Reference object
                    strBody = strBody & "<table width=""485"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr><td><img src=""[LOGO]"" alt=""[COMPANY NAME]"" width=""155"" height=""29""></td>"
                    strBody = strBody & "<td align=""right"" valign=""middle"" style=""font-family:Arial, Helvetica, sans-serif; font-size:18px; color:#acabab;"">"
                    strBody = strBody & Now()
                    strBody = strBody & "</td></tr></table></td></tr><tr><td><div style=""border-bottom:1px solid #d6d6d6; border-top:1px solid #d6d6d6; padding-bottom:3px; padding-top:3px;""><div style=""background-color:#424242;""><table height=""39"" border=""0"" cellspacing=""0"" cellpadding=""0""><tr>"
                    strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[SUBSCRIBE]"" style=""color:#e4e4e4;"">Subscribe</a></td>" 'TODO: Move link href to PageURL object then Reference object
                    strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[UNSUBSCRIBE]"" style=""color:#e4e4e4;"">Unsubscribe</a></td>" 'TODO: Move link href to PageURL object then Reference object
                    strBody = strBody & "<td style=""border-right:1px solid #797979; padding:0 20px 0 20px; font-family:Arial, Helvetica, sans-serif; font-size:11px;""><a href=""[FORWARD]"" style=""color:#e4e4e4;"">Forward to a friend</a></td>" 'TODO: Move link href to PageURL object then Reference object
                    strBody = strBody & "<td>&nbsp;</td></tr></table></div></div></td></tr><tr><td style=""padding:30px 20px 0px 20px; font-family:Arial, Helvetica, sans-serif; font-size:14px; color:#333333; line-height:20px;"">"
                    strBody = strBody & "<p style=""margin:0 0 25px 0;"">Dear " & strUserName & ",<br><br>"
                    strBody = strBody & "Your password has been reset. Please login and change your password.<br><br>"
                    strBody = strBody & "User Name: " & strUserName & "<br>"
                    strBody = strBody & "password: " & strNewPassword & "<br><br>"
                    strBody = strBody & "<a href=""http://www.SocialConveyors.com"" style=""color:#0165ab;"">http://www.SocialConveyors.com</a></p>" 'TODO: Move link href to PageURL object then Reference object
                    strBody = strBody & "</td></tr><tr><td style=""border-top:1px solid #d6d6d6; background-color:#f6f6f6; font-family:Arial, Helvetica, sans-serif; font-size:12px; color:#666666; line-height:17px;  padding:15px 0 15px 20px;"">"
                    strBody = strBody & "<b>[COMPANY NAME]</b><br>"
                    strBody = strBody & "[COMPANY ADDRESS], [COMPANY CITY], [COMPANY STATE], [COMPANY ZIP]<br>"
                    strBody = strBody & "<a href=""mailto:[INFO EMAIL]"" style=""color:#4089bb;"">[INFO EMAIL]</a><br>" 'TODO: Move link href to PageURL object then Reference object
                    strBody = strBody & "<a href=""http://www.SocialConveyors.com"" style=""color:#4089bb;"">www.SocialConveyors.com</a>" 'TODO: Move link href to PageURL object then Reference object
                    strBody = strBody & "</td></tr></table></div></td></tr><tr><td align=""left"" style=""padding:20px 0 10px 10px; font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#888888;"">"
                    strBody = strBody & "To ensure our newsletter always reaches your inbox, please add <a href=""mailto:info@yourcompany.com"" style=""color:#545454;"">info@yourcompany.com</a> to your<br>" 'TODO: Move link href to PageURL object then Reference object
                    strBody = strBody & "address book. If you prefer not to receive news from Your Company Name in the future, you can<br>"
                    strBody = strBody & "<a href=""[UNSUBSCRIBE]"" style=""color:#545454;"">unsubscribe here</a>." 'TODO: Move link href to PageURL object then Reference object
                    strBody = strBody & "</td></tr></table></td></tr></table></body></html>"
                    '--------------------------------------------------------------------------------------------------------/Email Template

                    mail.Body = strBody
                    mail.IsBodyHtml = True
                    Dim smtp As SmtpClient = New SmtpClient()
                    smtp.Host = ConfigurationManager.AppSettings("SMTP_SERVER")
                    smtp.Credentials = New System.Net.NetworkCredential("test@gmail.com", "!gmail@test#")   'TODO: Setup TEST ACCOUNT
                    smtp.EnableSsl = True

                    Try
                        smtp.Send(mail) 'Send an e-mail to the user with the activation code.
                    Catch ex As Exception
                        objCommand.CommandText = "INSERT INTO emailerrors (FromEmail,ToEmail,Subject,Body,ExceptionError) " & _
                         "VALUES ('" & ConfigurationManager.AppSettings("PROFILE_EMAIL") & "','" & mail.To.ToString() & "',""" & _
                         Server.HtmlEncode(mail.Subject) & """,""" & _
                         Server.HtmlEncode(mail.Body) & """,""" & Server.HtmlEncode(ex.ToString) & """);"
                        objCommand.ExecuteNonQuery()
                    Finally
                        litErrorMessage.Text = ""
                        litStatusMessage.Text = "Email sent to " & Email.Text & "." 'TODO: Move to StatusMessage/ErrorMessage object
                        'TODO: Set Email Sent Status Message litStatusMessage & phStatusMessage
                        'TODO: String.Format above prior to extracting 
                    End Try
                    blnPasswordEmailed = True
                End If
            End If
            objConnection.Close()
        ElseIf Session("UserName") <> "" Then
            blnUserLoggedIn = True
            litErrorMessage.Text = ""
            litStatusMessage.Text = "You're already logged in.<br /><br />Click <a href=http://www.SocialConveyors.com/editprofile.aspx>here</a> to change your password. (004)"
        End If

        If litErrorMessage.Text <> "" Then
            phErrorMessage.Visible = True
        Else
            phErrorMessage.Visible = False
        End If

        If litStatusMessage.Text <> "" Then
            phStatusMessage.Visible = True
        Else
            phStatusMessage.Visible = False
        End If
    End Sub
End Class
