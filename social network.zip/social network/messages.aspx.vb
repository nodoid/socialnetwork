﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
'Imports EmailMessage 'TODO: Make Emailer Object

Imports Globals

Partial Class messages
    Inherits System.Web.UI.Page

    Dim blnHasData As Boolean = False
    Dim arySortLinks(5) As String
    Public intRecords As Integer = 0
    Dim intNewRecords As Integer = 0
    Dim strFolder As String
    Dim strTitle As String
    Public strFirstColumnName As String
    Public strMessageLink As String

    Public LOGIN_strErrorMessage As String

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        litMaxMessages1.Text = MAX_MESSAGES
        litMaxMessages2.Text = MAX_MESSAGES
        initdatasource()
    End Sub

    Sub initdatasource()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("UserName") <> "" Then
            'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
            Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
            Dim objCommand As New SqlCommand()
            objCommand.Connection = objConnection
            objConnection.Open()
            'Postback is only for deleting messages.
            'If Page.IsPostBack The

            'End If 'Page.IsPostBack
            'Handle the sorting.
            Dim strSortColumn As String = Request.QueryString("sortby")
            If strSortColumn <> "" Then
                'Make sure QueryString has not been tampered with by adding additional SQL.
                If InStr(strSortColumn, " ") = 0 Then
                    strSortColumn = " ORDER BY " & strSortColumn & ";"
                Else
                    strSortColumn = " ORDER BY MessageDate;"
                End If
            Else
                strSortColumn = " ORDER BY MessageDate;"
            End If
            'Determine which folder to view.
            strFolder = Request.QueryString("folder")
            If strFolder = "" Then
                If Session("MessageFolder") <> "" Then
                    strFolder = Session("MessageFolder")
                Else
                    strFolder = "inbox"
                End If
            ElseIf Not (strFolder <> "inbox" Or strFolder <> "sent") Then
                strFolder = "inbox"
            End If
            Session("MessageFolder") = strFolder
            'Get the number of unread messages.
            'TODO: Move to Parameterized Stored Procedure
            objCommand.CommandText = String.Format("SELECT Count(*) FROM messages WHERE RecipientID={0} AND DeletedByRecipient=0 AND MessageRead=0;", Session("ProfileID"))
            intNewRecords = CInt(objCommand.ExecuteScalar())

            litNewRecords.Text = intNewRecords

            'Determine which SELECT statement to use for getting the number of messages,
            'and the message data.
            Dim strGetTotalCount As String
            Dim strGetData As String
            If strFolder = "sent" Then
                'TODO: Move to Parameterized Stored Procedure
                strGetTotalCount = String.Format("SELECT Count(*) FROM messages WHERE SenderID={0} AND DeletedBySender=0;", Session("ProfileID"))
                'TODO: Move to Parameterized Stored Procedure
                strGetData = String.Format("SELECT m.MessageID,m.MessageDate,m.MessageRead,m.Subject,p.UserName FROM messages m INNER JOIN profiles p on m.RecipientID = p.ProfileID WHERE SenderID='{0}' AND DeletedBySender='0'" & strSortColumn & ";", Session("ProfileID"))
                strFirstColumnName = "To"
                strTitle = "Sent Messages"
            Else
                'TODO: Move to Parameterized Stored Procedure
                strGetTotalCount = String.Format("SELECT Count(*) FROM messages WHERE RecipientID='{0}' AND DeletedByRecipient='0';", Session("ProfileID"))
                'TODO: Move to Parameterized Stored Procedure
                strGetData = String.Format("SELECT m.MessageID,m.MessageDate,m.Subject,m.MessageRead,p.UserName FROM messages m INNER JOIN profiles p on m.SenderID = p.ProfileID WHERE RecipientID='{0}' AND DeletedByRecipient='0'" & strSortColumn & ";", Session("ProfileID"))
                strFirstColumnName = "From"
                strTitle = "Inbox"
            End If
            litTitle.Text = strTitle
            objCommand.CommandText = strGetTotalCount
            intRecords = CInt(objCommand.ExecuteScalar())
            'Bind the messages to the data list.
            If intRecords > 0 Then
                objCommand.CommandText = strGetData
                msgDataList.DataSource = objCommand.ExecuteReader(CommandBehavior.CloseConnection)
                msgDataList.DataBind()
                blnHasData = True
                strMessageLink = "seemsg.aspx?folder=" & strFolder & "&amp;sortby=" & Request.QueryString("sortby")
            End If
            objConnection.Close()
            'Only make columns sortable if there's more than 1 message.
            If intRecords > 1 Then
                'TODO: Add Sorting back. Sorting breaks because the URLs are within a repeater.
                'hlMsgSorterFirstColumn.NavigateUrl = "messages.aspx?folder=" & strFolder & "&amp;sortby=p.UserName"
                'hlMsgSorterSubject.NavigateUrl = "messages.aspx?folder=" & strFolder & "&amp;sortby=m.Subject"
                'hlMsgSorterDate.NavigateUrl = "messages.aspx?folder=" & strFolder & "&amp;sortby=m.MessageDate"
            End If
        End If

        If Session("UserName") <> "" Then
            mvLogInStatus.SetActiveView(vwLoggedIn)
        Else
            mvLogInStatus.SetActiveView(vwLoggedOut)
        End If

        If blnHasData Then
            mvMessages.SetActiveView(vwHasMessages)
        Else
            mvMessages.SetActiveView(vwHasNoMessages)
        End If
    End Sub

    'Bold the selected folder.
    Function BoldSelected(ByVal strSelected As String) As String
        If strFolder = "" And strSelected = "Inbox" Then
            Return "<strong>Inbox</strong>"
        Else
            If LCase(strFolder) = LCase(strSelected) Then
                Return "<strong>" & strSelected & "</strong>"
            Else
                Return strSelected
            End If
        End If
    End Function
    'Bold new messages.
    Function BoldNew(ByVal strWord As String, ByVal blnMessageSent As Boolean) As String
        If (LCase(strFolder) = "inbox" And blnMessageSent = False) Then
            Return "<strong>" & strWord & "</strong>"
        Else
            Return strWord
        End If
    End Function
    'Format the date to Jan. 23 .
    Function ShortDate(ByVal dt As DateTime) As String
        dt = dt.AddHours(OFFSET_HOURS)
        Return MonthName(Month(dt), True) & ". " & Day(dt)
    End Function

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
        Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
        Dim objCommand As New SqlCommand()
        objCommand.Connection = objConnection
        objConnection.Open()
        Dim strFormID As String = Request.Form("ID")
        strFolder = formfolder.Value 'Request.Form("formfolder")
        If strFormID <> "" Then
            Dim strDelete As New StringBuilder()
            'Build the UPDATE statement for "deleting" the messages.
            Select Case strFolder
                Case "inbox"
                    strDelete.Append("UPDATE messages SET DeletedByRecipient=1 WHERE RecipientID=" & Session("ProfileID") & " AND MessageID=")
                Case "sent"
                    strDelete.Append("UPDATE messages SET DeletedBySender=1 WHERE SenderID=" & Session("ProfileID") & " AND MessageID=")
            End Select
            'A single message.
            If strFormID.IndexOf(",") = -1 Then
                strDelete.Append(strFormID & ";")
            Else 'Multiple messages.
                Dim arrayIDs() As String = strFormID.Split(",")
                strDelete.Append(arrayIDs(0))
                Dim intIndex As Integer
                For intIndex = 1 To arrayIDs.Length - 1
                    strDelete.Append(" OR MessageID=" & arrayIDs(intIndex))
                Next
                strDelete.Append(";")
            End If
            objCommand.CommandText = strDelete.ToString()
            objCommand.ExecuteNonQuery()
            'TODO: Never DELETE messages set a delete flag.  Write a service to move them to an archive in a seperate database.
            'DELETE the message permanently if both sender and recipient deleted the message.
            'NOTE: this saves space, but "deleted" messages might need to be saved for legal reasons.
            objCommand.CommandText = "DELETE FROM messages WHERE DeletedBySender=1 AND DeletedByRecipient=1;"
            objCommand.ExecuteNonQuery()
            objConnection.Close()
        End If
    End Sub
End Class