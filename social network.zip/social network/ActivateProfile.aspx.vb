﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Imports Configuration.ErrorMessages

Partial Class activateprofile
    Inherits System.Web.UI.Page

    Public blnProfileActivated As Boolean = False
    'Dim strUserName As String
    'Dim strActivationCode As String

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        'Call ProcessLogin()
        Page.Header.Title = Resources.ActivateProfile.Title
        UserName.Text = Request.QueryString("username")
        ActivationCode.Text = Request.QueryString("activationcode")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Public LOGIN_strErrorMessage As String

    Protected Sub BtnActivateProfile_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnActivateProfile.Click
        'If Page.IsPostBack Or (strUserName <> "" And strActivationCode <> "") Then
        '   If Page.IsPostBack Then
        '       strUserName = UserName.Text
        '       strActivationCode = ActivationCode.Text
        '   End If

        Dim objConnection As New SqlConnection(ConfigurationManager.AppSettings("DB_CONNECTION_STRING"))
        Dim objDataReader As SqlDataReader

        Dim intProfileID As Integer
        Dim strTrueActivationCode As String
        Dim intProfileStatusID As Byte

        Dim strSQL = String.Format("SELECT ProfileID,ActivationCode,ProfileStatusID FROM Profiles WHERE UserName = '{0}';", UserName.Text)
        'TODO: Move to Parameterized Stored Procedure
        Dim objCommand As New SqlCommand(strSQL, objConnection)

        '-----------------------------------------------------
        'TODO: Move to Parameterized Stored Procedure
        'objCommand.Parameters.AddWithValue("@UserName", UserName.Text.Trim().ToLower())
        'objCommand.CommandText = "spGetProfileIDbyEmail"
        'objDataReader = objCommand.ExecuteReader()
        '-----------------------------------------------------

        objConnection.Open()
        objDataReader = objCommand.ExecuteReader()
        If Not (objDataReader.Read()) Then
            objDataReader.Close()
            litStatusMessage.Text = String.Empty 'TODO: Think about refactoring the Message Dialog and Expanding function
            litErrorMessage.Text = String.Format(ErrorMessages.ERROR_MESSAGE_ACCOUNT_USERNAME_DOESNT_EXIST, UserName.Text)
        Else
            intProfileID = objDataReader.Item("ProfileID")
            strTrueActivationCode = objDataReader.Item("ActivationCode")
            intProfileStatusID = objDataReader.Item("ProfileStatusID")
            objDataReader.Close()

            If intProfileStatusID > 1 Then
                litErrorMessage.Text = String.Empty
                litStatusMessage.Text = String.Format(ErrorMessages.ERROR_MESSAGE_ACCOUNT_USERNAME_DOESNT_EXIST, UserName.Text)
                blnProfileActivated = True
            Else
                If ActivationCode.Text <> strTrueActivationCode Then '4. Verify the Activation Code.
                    litStatusMessage.Text = String.Empty
                    litErrorMessage.Text = ErrorMessages.ERROR_MESSAGE_ACCOUNT_ACTIVATION_INVALID_CODE
                Else
                    objCommand.CommandText = "spUpdateProfileStatus" '5. UPDATE the database to activate the profile.
                    objCommand.Parameters.AddWithValue("@UserName", UserName.Text)
                    objCommand.Parameters.AddWithValue("@ActivationCode", ActivationCode.Text)
                    objCommand.Parameters.AddWithValue("@ProfileStatusID", "2") 'TODO: Make ProfileStatus Object
                    objCommand.ExecuteNonQuery()
                    objCommand.Dispose()

                    blnProfileActivated = True
                    litErrorMessage.Text = String.Empty
                    litStatusMessage.Text = ErrorMessages.ERROR_MESSAGE_ACCOUNT_ACTIVATION_INVALID_CODE

                    Session("ProfileID") = intProfileID
                    Session("UserName") = UserName.Text
                End If
            End If
        End If

        objConnection.Close()
        objConnection.Dispose()

        If litErrorMessage.Text <> "" Then
            phErrorMessage.Visible = True
        Else
            phErrorMessage.Visible = False
        End If

        If litStatusMessage.Text <> "" Then
            phStatusMessage.Visible = True
        Else
            phStatusMessage.Visible = False
        End If
    End Sub
End Class
String.Empty 