﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Mail
'Imports EmailMessage 'TODO: Make EmailMessage Object

Partial Class sendmsg
    Inherits System.Web.UI.Page

    Dim blnIsReply As Boolean = False
    Dim blnShowForm As Boolean = True

    Dim strReplyID As String
    Dim strRecipientID As String

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        litComposeLink.Text = "<strong>Compose</strong>"
        litTitle.Text = "Compose a New Message"     'TODO: Move to PageTitles object
        If Session("UserName") <> "" And blnShowForm Then
            phShowForm.Visible = True
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        strReplyID = Request.QueryString("replyid")
        If Session("UserName") = "" Then
            'MessageCell.CssClass = "msgSent"
            'TODO: This is more of a WARNING than an Error Add a WARNING message to code
            litErrorMessage.Text = "Please login to view your messages." 'TODO: Move to StatusMessage/ErrorMessage object
            'TODO: Please comment the above as a possible general use string.format
        ElseIf (strReplyID <> "" And IsNumeric(strReplyID) = False) Then
            litErrorMessage.Text = "Please don't mess with the URL." 'TODO: Move to StatusMessage/ErrorMessage object
        Else
            'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
            Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
            Dim objDataReader As SqlDataReader
            Dim objCommand As New SqlCommand()
            objCommand.Connection = objConnection
            objConnection.Open()
            If Page.IsPostBack Then
                Dim strRecipientID As String = hdnRecipientID.Value 'Request.Form("RecipientID")
                Dim strRecipientName As String = litRecipientName.Text 'Request.Form("RecipientName")
                Dim strSubject As String = Subject.Text 'Request.Form("Subject")
                Dim strBody As String = Body.Text 'Request.Form("Body")
                If (Trim(strSubject) <> "" And Trim(strBody) <> "") Then
                    Dim objMessage As New EmailMessage
                    objMessage.SenderID = Session("ProfileID")
                    objMessage.SenderName = Session("UserName")
                    objMessage.RecipientID = strRecipientID
                    objMessage.Subject = strSubject
                    objMessage.Body = strBody
                    objMessage.Send()
                    If objMessage.ErrorMessage = "" Then
                        'MessageCell.CssClass = "msgSent"
                        litStatusMessage.Text = Resources.SendMsg.litStatusMessage1
                    Else
                        litErrorMessage.Text = objMessage.ErrorMessage
                    End If
                    'Clear the Message fields.
                    Subject.Text = "" '???
                    Body.Text = ""    '???
                Else
                    litErrorMessage.Text = Resources.SendMsg.litErrorMessage1 'TODO: Reference ErrorMessages Object - 
                End If
                litComposeLink.Text = "Compose" '???
                blnShowForm = False
            Else
                'Grab the information for the original message to be displayed.
                If IsNumeric(strReplyID) Then
                    Dim intSenderProfileStatusID As Integer
                    'TODO: Move to Parameterized Stored Procedure
                    objCommand.CommandText = String.Format("SELECT m.SenderID,m.Subject,m.Body,p.UserName,p.ProfileStatusID FROM messages m INNER JOIN profiles p ON m.SenderID = p.ProfileID WHERE m.MessageID={0} AND m.RecipientID={1} AND m.DeletedByRecipient=0;", strReplyID, Session("ProfileID"))
                    objDataReader = objCommand.ExecuteReader()
                    If objDataReader.Read() Then
                        litRecipientName.Text = objDataReader("UserName")
                        hdnRecipientID.Value = CStr(objDataReader("SenderID"))
                        intSenderProfileStatusID = objDataReader("ProfileStatusID")
                        Subject.Text = "Re: " & Server.HtmlDecode(objDataReader("Subject")) 'TODO: Move to StatusMessage/ErrorMessage object
                        Body.Text = vbCrLf & vbCrLf & vbCrLf & "------- " & _
                         litRecipientName.Text & " wrote:" & vbCrLf & vbCrLf & Server.HtmlDecode(objDataReader("Body")) 'TODO: Move to StatusMessage/ErrorMessage object
                        'TODO: Please string.format the above prior to extracting to an object
                    Else
                        litErrorMessage.Text = Resources.SendMsg.litErrorMessage4 'TODO: Reference ErrorMessages Object - 
                        blnShowForm = False
                    End If
                    objDataReader.Close()

                    If intSenderProfileStatusID = 3 Then
                        litErrorMessage.Text = Resources.SendMsg.litErrorMessage2 'TODO: Reference ErrorMessages Object - 
                    ElseIf intSenderProfileStatusID = 4 Then
                        litErrorMessage.Text = Resources.SendMsg.litErrorMessage3 'TODO: Reference ErrorMessages Object - 
                        blnShowForm = False
                    End If
                    blnIsReply = True
                    litComposeLink.Text = "Compose" '???
                    litTitle.Text = "Reply to a Message" 'TODO: Move to StatusMessage/ErrorMessage object
                Else
                    'Populate the RecipientID drop-down menu.
                    'TODO: Move to Parameterized Stored Procedure
                    objCommand.CommandText = String.Format("SELECT p.UserName,f.FavoriteID FROM favorites f INNER JOIN profiles p ON p.ProfileID = f.FavoriteID WHERE f.ProfileID={0} ORDER BY p.UserName;", Session("ProfileID"))
                    objDataReader = objCommand.ExecuteReader()
                    While objDataReader.Read()
                        ddlRecipientID.Items.Add(New ListItem(objDataReader("UserName"), objDataReader("FavoriteID")))
                    End While
                    objDataReader.Close()
                End If

                'If the user has no favorites and is not replying to a message, then show a message.
                If (litErrorMessage.Text = "" And Not (blnIsReply) And ddlRecipientID.Items.Count = 0) Then
                    ddlRecipientID.Items.Add(New ListItem("Your list of favorites is empty", "")) 'TODO: Move to StatusMessage/ErrorMessage object
                    litErrorMessage.Text = Resources.SendMsg.litErrorMessage5 'TODO: Reference ErrorMessages Object - 
                    btnSend.Enabled = False
                End If

                'Get the number of new messages in the Inbox.
                'TODO: Move to Parameterized Stored Procedure
                objCommand.CommandText = String.Format("SELECT Count(*) FROM messages WHERE RecipientID={0} AND DeletedByRecipient=0 AND MessageRead=0;", Session("ProfileID"))
                litNewMessageCount.Text = CInt(objCommand.ExecuteScalar())
        End If
            objConnection.Close()
        End If
        If blnIsReply Then
            mvReply.SetActiveView(vwIsReply)
        Else
            mvReply.SetActiveView(vwIsNotReply)
        End If
        If litNewMessageCount.Text = String.Empty Then litNewMessageCount.Text = 0

        If litErrorMessage.Text <> "" Then
            phErrorMessage.Visible = True
        Else
            phErrorMessage.Visible = False
        End If

        If litStatusMessage.Text <> "" Then
            phStatusMessage.Visible = True
        Else
            phStatusMessage.Visible = False
        End If
    End Sub

    Protected Sub ddlRecipientID_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlRecipientID.SelectedIndexChanged
        hdnRecipientID.Value = ddlRecipientID.SelectedValue
    End Sub
End Class
