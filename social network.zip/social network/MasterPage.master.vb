﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration

Partial Class MasterPage
    Inherits System.Web.UI.MasterPage

    Dim blnLoggedIn As Boolean = False

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        'If Not blnLoggedIn Then
        'mvLoginStatus.SetActiveView(vwLoggedOut)
        'Else
        'mvLoginStatus.SetActiveView(vwLoggedIn)
        'End If

        Dim strLoginFormAction As String = Request.ServerVariables("SCRIPT_NAME") & "?" & Request.QueryString.ToString()
        'Dim strAdminLink As String = ""
        'TODO: Switch to Role based Admin. This SHOULD NEVER be handled via strings
        'If Session("UserName") = "joseph" Then
        'strAdminLink = "&nbsp;&nbsp;&nbsp;<a href=/admin>Admin</a>"
        'End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class

