﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Partial Class Zodiac
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    End Sub

    Function WesternZodiac(ByVal birthMonth As Integer, ByVal birthDay As Integer) As String
        'Dim Start As Integer = 1901
        Select Case birthMonth
            Case 1
                Return If(BirthDay >= 20, "Aquarius", "Capricorn") '31
            Case 2
                Return If(BirthDay >= 19, "Pisces", "Aquarius") '29
            Case 3
                Return If(BirthDay >= 21, "Aries", "Pisces") '31
            Case 4
                Return If(BirthDay >= 20, "Taurus", "Aries") '30
            Case 5
                Return If(BirthDay >= 21, "Gemini", "Taurus") '31
            Case 6
                Return If(BirthDay >= 22, "Cancer", "Gemini") '30
            Case 7
                Return If(BirthDay >= 23, "Leo", "Cancer") '31
            Case 8
                Return If(BirthDay >= 23, "Virgo", "Leo") '31
            Case 9
                Return If(BirthDay >= 23, "Libra", "Virgo") '30
            Case 10
                Return If(BirthDay >= 23, "Scorpio", "Libra") '31
            Case 11
                Return If(BirthDay >= 22, "Sagittarius", "Scorpio") '30
            Case 12
                Return If(BirthDay >= 22, "Capricorn", "Sagittarius") '31
            Case Else
                Return "Error"
        End Select

        'If (BirthMonth = 1 And BirthDay >= 20) Or (BirthMonth = 2 And BirthDay <= 18) Then
        'Return "Aquarius"
        'ElseIf (BirthMonth = 2 And BirthDay >= 19) Or (BirthMonth = 3 And BirthDay <= 20) Then
        'Return "Pisces"
        'ElseIf (BirthMonth = 3 And BirthDay >= 21) Or (BirthMonth = 4 And BirthDay <= 19) Then
        'Return "Aries"
        'ElseIf (BirthMonth = 4 And BirthDay >= 20) Or (BirthMonth = 5 And BirthDay <= 20) Then
        'Return "Taurus"
        'ElseIf (BirthMonth = 5 And BirthDay >= 21) Or (BirthMonth = 6 And BirthDay <= 21) Then
        'Return "Gemini"
        'ElseIf (BirthMonth = 6 And BirthDay >= 22) Or (BirthMonth = 7 And BirthDay <= 22) Then
        'Return "Cancer"
        'ElseIf (BirthMonth = 7 And BirthDay >= 23) Or (BirthMonth = 8 And BirthDay <= 22) Then
        'Return "Leo"
        'ElseIf (BirthMonth = 8 And BirthDay >= 23) Or (BirthMonth = 9 And BirthDay <= 22) Then
        'Return "Virgo"
        'ElseIf (BirthMonth = 9 And BirthDay >= 23) Or (BirthMonth = 10 And BirthDay <= 22) Then
        'Return "Libra"
        'ElseIf (BirthMonth = 10 And BirthDay >= 23) Or (BirthMonth = 11 And BirthDay <= 21) Then
        'Return "Scorpio"
        'ElseIf (BirthMonth = 11 And BirthDay >= 22) Or (BirthMonth = 12 And BirthDay <= 21) Then
        'Return "Sagittarius"
        'ElseIf (BirthMonth = 12 And BirthDay >= 22) Or (BirthMonth = 1 And BirthDay <= 19) Then
        'Return "Capricorn"
        'Else
        'Return "Error"
        'End If



        '}
        '}
        'var zodiac=new makeArray(13);
        'var ax1="Aries -- The Ram. March 21 to April 20. " + nl + nl + "The spring equinox, March 21, is the beginning of the new zodiacal year and Aries, the first sign, is therefore that of new beginnings. The young ram is adventurous, ambitious, impulsive, enthusiastic and full of energy.";
        'var ax2="The Arien is a pioneer both in thought and action, very open to new ideas and a lover of freedom.";
        'var ax3="They welcome challenges and will not be diverted from their purpose except by their own impatience, which will surface if they don't get quick results." ;

        'var tx1="Taurus -- The Bull. April 21 to May 20. " + nl + nl + "The Taurean's characteristics are solidity, practicality, extreme determination and strength of will - no one will ever drive them, but they will willingly and loyally follow a leader they trust. " ;
        'var tx2="They are stable, balanced, conservative good, law-abiding citizens and lovers of peace, possessing all the best qualities of the bourgeoisie. " ;
        'var tx3="As they have a sense of material values and physical possessions, respect for property and a horror of falling into debt, they will do everything in their power to maintain the security of the status quo and be stupidly hostile to change." ;

        'var nx1="Gemini -- The Twins. May 21 to June 21. " + nl + nl + "Gemini, the sign of the Twins, is dual-natured, elusive, complex and contradictory. On the one hand it produces the virtue of versatility, and on the other the vices of two-facedness and flightiness. " ;
        'var nx2="The sign is linked with Mercury, the planet of childhood and youth, and its subjects tend to have the graces and faults of the young. " ;
        'var nx3="When they are good, they are very attractive; when they are bad they are more the worse for being the charmers they are. " ;

        'var cx1="Cancer -- The Crab. June 22 to July 22. " + nl + nl + "The Cancerian character is the least clear-cut of all those associated with the signs of the zodiac. " ;
        'var cx2="It can range from the timid, dull, shy and withdrawn to the most brilliant, and famous Cancerians are to be found through the whole range of human activity. " ;
        'var cx3="`Nest like' is an appropriate adjective for the Cancerian home." ;

        'var lx1="Leo -- The Lion. July 23 to August 22. " + nl + nl + "The Leo type is the most dominant, spontaneously creative and extrovert of all the zodiacal characters." + "In grandeur of manner, splendor of bearing and magnanimity of personality, they are the monarch's among humans as the lion is king of beasts. " ;
        'var lx2="They are ambitious, courageous, dominant, strong willed, positive, independent, self-confident there is no word as doubt in their vocabularies and self-controlled. " ;
        'var lx3="Born leaders, either in support of or in revolt against the status quo, they are at their most effective when in a position of command, their personal magnetism and courtesy of mind bringing out the best of loyalty from subordinates. " ;

        'var vx1="Virgo -- The Virgin. August 23 to September 22. " + nl + nl + "Virgo is the only zodiacal sign represented by a female. It is sometimes thought of as a potentially creative girl, delicately lovely; sometimes as a somewhat older woman, intelligent but rather pedantic and spinsterish. " ;
        'var vx2="The latter impression is sometimes confirmed by the Virgoan preciseness, refinement, fastidious love of cleanliness, hygiene and good order, conventionality and aristocratic attitude of reserve. " ;
        'var vx3="They are usually observant, shrewd, critically inclined, judicious, patient, practical supporters of the status quo, and tend toward conservatism in all departments of life. " ;

        'var ix1="Libra -- The Scales. September 23 to October 22. " + nl + nl + "Libra is the only inanimate sign of the zodiac, all the others representing either humans or animals. " ;
        'var ix2="Many modern astrologers regard it as the most desirable of zodiacal types because it represents the zenith of the year, the high point of the seasons, when the harvest of all the hard work of the spring is reaped. " ;
        'var ix3="There is a mellowness and sense of relaxation in the air as mankind enjoys the last of the summer sun and the fruits of his toil. Librans too are among the most civilized of the twelve zodiacal characters and are often good looking. " ;

        'var sx1="Scorpio -- The Scorpion. October 23 to November 22. " + nl + nl + "Scorpians are the most intense, profound, powerful characters in the zodiac. Even when they appear self-controlled and calm there is a seething intensity of emotional energy under the placid exterior. " ;
        'var sx2="They are like the volcano not far under the surface of a calm sea it may burst into eruption at any moment.";
        'var sx3="But those of us who are particularly perceptive will be aware of the harnessed aggression, the immense forcefulness, magnetic intensity and often strangely hypnotic personality under the tranquil but watchful composure of the Scorpian. " ;

        'var gx1="Sagittarius -- The Archer. November 23 to December 21. " + nl + nl + "Sagittarians have a positive outlook on life, are full of enterprise, energy, versatility, adventurousness and eagerness to extend experience beyond the physically familiar. " ;
        'var gx2="They enjoy travelling and exploration, the more so because their minds are constantly open to new dimensions of thought. They are basically ambitious and optimistic, and continue to be so even when their hopes are dashed. " ;
        'var gx3="Their strongly idealistic natures can also suffer many disappointments without being affected. They are honorable, honest, trustworthy, truthful, generous and sincere, with a passion for justice. " ;

        'var px1="Capricorn -- The Goat. December 23 to January 20. " + nl + nl + "The Capricornian is one of the most stable and serious of the zodiacal types. These independent, rocklike characters have many sterling qualities, although admittedly some of these are as dull as they are worthy. " ;
        'var px2="This type is normally cautiously confident, strong-willed and calm. Hardworking, unemotional, shrewd, practical, responsible, and persevering, they are capable of persisting for as long as is necessary. " ;
        'var px3="They are reliable workers in almost any profession they undertake. But they are neither original nor creative and can only develop what others invent or initiate. " ;

        'var qx1="Aquarius -- The Water Bearer. January 21 to February 19. " + nl + nl + "Aquarians basically possess strong and attractive personalities." ;
        'var qx2="They fall into two principle types: one shy, sensitive, gentle and patient; the other exuberant, lively and exhibitionist, sometimes hiding the considerable depths of their character under a cloak of frivolity." ;
        'var qx3="They have a breadth of vision that brings diverse factors into a whole, and can see both sides of an argument without shilly-shallying as to which side to take.";

        'var ex1="Pisces -- The Fish. February 20 to March 20. " + nl + nl + "Pisces is one of the less flamboyant signs and its natives are more ordinary than those of, for example, Leo, Scorpio and Aquarius. Pisceans possess a gentle, patient, malleable nature.";
        'var ex2="They have many generous qualities and are friendly, good natured, kind and compassionate, sensitive to the feelings of those around them, and respond with the utmost sympathy and tact to any suffering they encounter.";
        'var ex3="They are deservedly popular with all kinds of people, partly because their easygoing, affectionate, submissive natures offer no threat or challenge to stronger and more exuberant characters.";
    End Function

    Function EasternZodiac(ByVal birthYear As Integer) As String
        Dim Start As Integer = 1997
        Dim ZodiacOffset As Integer = (Start - CInt(BirthYear)) Mod 12
        Select Case ZodiacOffset
            Case 0
                Return "Ox"
            Case 1, -11
                Return "Rat/Mouse"
            Case 2, -10
                Return "Boar/Pig"
            Case 3, -9
                Return "Dog"
            Case 4, -8
                Return "Cock/Phoenix/Chicken"
            Case 5, -7
                Return "Monkey"
            Case 6, -6
                Return "Sheep"
            Case 7, -5
                Return "Horse"
            Case 8, -4
                Return "Snake"
            Case 9, -3
                Return "Dragon"
            Case 10, -2
                Return "Rabbit/Cat"
            Case 11, -1
                Return "Tiger"
            Case Else
                Return "Error"
        End Select
    End Function

    'The Ox in the Chinese Zodiac is akin to the Capricorn in the Western Zodiac.
    'The Tiger in the Chinese Zodiac is akin to the Aquarius in the Western Zodiac.
    'The Rabbit in the Chinese Zodiac is akin to the Pisces in the Western Zodiac.
    'The Dragon in the Chinese Zodiac is akin to the Aries in the Western Zodiac.
    'The Snake in the Chinese Zodiac is akin to the Taurus in the Western Zodiac.
    'The Horse in the Chinese Zodiac is akin to the Gemini in the Western Zodiac.
    'The Sheep in the Chinese Zodiac is akin to the Cancer in the Western Zodiac.
    'The Monkey in the Chinese Zodiac is akin to the Leo in the Western Zodiac.
    'The Rooster in the Chinese Zodiac is akin to the Virgo in the Western Zodiac.
    'The Dog in the Chinese Zodiac is akin to the Libra in the Western Zodiac.
    'Finally, the Pig in the Chinese Zodiac is akin to the Scorpio in the Western Zodiac.

    Protected Sub BtnEasternZodiac_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEasternZodiac.Click
        litEasternZodiac.Text = EasternZodiac(ddlYear.SelectedValue)
    End Sub

    Protected Sub BtnWesternZodiac_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnWesternZodiac.Click
        litWesternZodiac.Text = WesternZodiac(ddlMonth.SelectedValue, ddlDay.SelectedValue)
    End Sub
End Class