﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Imports Globals

Partial Class AdvancedSearch
    Inherits System.Web.UI.Page

    Public intRecords As String
    Public strRecordsFound As String = String.Empty
    Public strNextPage As String = String.Empty
    Public arraySortLinks(4) As String

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        'call ProcessLogin()

        'Dim intIndex As Byte
        'For intIndex = 1 To HoodArray.Length - 1
        'NeighborhoodID.Items.Add(New ListItem(HoodArray.GetValue(intIndex), intIndex))
        'Next
        'Populate the "Height" drop-down menu.
        'Dim intHeight As Byte
        For intHeight = 36 To 95
            ddlHeightMin.Items.Add(New ListItem(ConvertHeight(intHeight), intHeight))
            ddlHeightMax.Items.Add(New ListItem(ConvertHeight(intHeight), intHeight))
        Next intHeight

        'Body Type
        Dim BodyTypeData As DataSet = New DataSet()
        BodyTypeData.ReadXml(Server.MapPath("~/App_Data/BodyType.xml"))
        ddlBodyTypeID.DataValueField = "ID"
        ddlBodyTypeID.DataTextField = "Value"
        ddlBodyTypeID.DataSource = BodyTypeData
        ddlBodyTypeID.DataBind()

        'Gender
        Dim GenderData As DataSet = New DataSet()
        GenderData.ReadXml(Server.MapPath("~/App_Data/Gender.xml"))
        ddlGenderID.DataValueField = "ID"
        ddlGenderID.DataTextField = "Value"
        ddlGenderID.DataSource = GenderData
        ddlGenderID.DataBind()

        'Gender
        Dim EthnicityData As DataSet = New DataSet()
        EthnicityData.ReadXml(Server.MapPath("~/App_Data/Ethnicity.xml"))
        ddlEthnicID.DataValueField = "ID"
        ddlEthnicID.DataTextField = "Value"
        ddlEthnicID.DataSource = EthnicityData
        ddlEthnicID.DataBind()

        'Sexuality
        Dim SexualOrientationData As DataSet = New DataSet()
        SexualOrientationData.ReadXml(Server.MapPath("~/App_Data/SexualOrientation.xml"))
        ddlSexualOrientationID.DataValueField = "ID"
        ddlSexualOrientationID.DataTextField = "Value"
        ddlSexualOrientationID.DataSource = SexualOrientationData
        ddlSexualOrientationID.DataBind()

        'Western Zodiac
        'Dim WesternZodiacData As DataSet = New DataSet()
        'WesternZodiacData.ReadXml(Server.MapPath("~/App_Data/WesternZodiac.xml"))
        'ddlWesternZodiacID.DataValueField = "ID"
        'ddlWesternZodiacID.DataTextField = "Value"
        'ddlWesternZodiacID.DataSource = WesternZodiacData
        'ddlWesternZodiacID.DataBind()

        'Looking For
        Dim LookingForData As DataSet = New DataSet()
        LookingForData.ReadXml(Server.MapPath("~/App_Data/LookingFor.xml"))
        ddlLookingFor.DataValueField = "ID"
        ddlLookingFor.DataTextField = "Value"
        ddlLookingFor.DataSource = LookingForData
        ddlLookingFor.DataBind()

        'Looking For
        Dim NeighborhoodData As DataSet = New DataSet()
        NeighborhoodData.ReadXml(Server.MapPath("~/App_Data/Neighborhood.xml"))
        lbNeighborhoodID.DataValueField = "ID"
        lbNeighborhoodID.DataTextField = "Value"
        lbNeighborhoodID.DataSource = NeighborhoodData
        lbNeighborhoodID.DataBind()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim strKeywords As String = Trim(Request.Form("Keywords"))
        'Dim strNeighborhoodID As String
        'If Page.IsPostBack Then
        '   blnDoSearch = True
        'Else
        '   If Request.QueryString("GenderID") <> "" Then
        '       blnDoSearch = True
        '       strGenderID = Request.QueryString("GenderID")
        '       strEthnicID = Request.QueryString("EthnicID")
        '       strAgeMin = Request.QueryString("AgeMin")
        '       strAgeMax = Request.QueryString("AgeMax")
        '       strKeywords = Trim(Request.QueryString("Keywords"))
        '       strHeightMin = Request.QueryString("HeightMin")
        '       strHeightMax = Request.QueryString("HeightMax")
        '       strBodyTypeID = Request.QueryString("BodyTypeID")
        '       strLookingFor = Request.QueryString("LookingFor")
        '       strNeighborhoodID = Request.QueryString("NeighborhoodID")
        '   ElseIf Session("SearchCriteria") <> "" Then
        '       blnDoSearch = True
        '       Dim strSearchCriteria As String = Session("SearchCriteria")
        '       Dim arraySearchCriteria() As String = strSearchCriteria.Split(",")
        '       strGenderID = arraySearchCriteria(0)
        '       strSexualOrientationID = arraySearchCriteria(1)
        '       strAgeMin = arraySearchCriteria(2)
        '       strAgeMax = arraySearchCriteria(3)
        '       strKeywords = Server.HtmlDecode(arraySearchCriteria(4))
        '   End If
        'End If
    End Sub


    Sub RestoreDropdown(ByVal strValue, ByVal objFormField)
        If IsNumeric(strValue) Then
            Dim intCount As Integer
            For intCount = 0 To objFormField.Items.Count - 1
                If strValue = objFormField.Items(intCount).Value Then
                    objFormField.Items(intCount).Selected = True
                    Exit For
                End If
            Next
        End If
    End Sub

    'Used on create/edit/view profile pages.
    Function ConvertHeight(ByVal intHeight As Integer) As String
        Dim intFeet = Fix(intHeight / 12)
        Dim intInches = intHeight Mod 12
        Return CStr(intFeet) & "'" & CStr(intInches) & Chr(34)
    End Function

    'Used on Search results an Favorites page to color-code genders.
    Function ColorGender(ByVal intGenderIndex As Object) As String
        'If GenderArray(1) = "" Then
        '   Call UseGenderArray()
        'End If
        If IsDBNull(intGenderIndex) Then
            Return ""
        Else
            intGenderIndex = CByte(intGenderIndex)
            Select Case intGenderIndex
                Case 0
                    Return "<span class=""nogender"">female</span>"
                Case 1
                    Return "<span class=""female"">female</span>"
                Case 2
                    Return "<span class=""male"">male</span>"
                Case Else
                    Return "<span class=""transgender"">" & intGenderIndex & "</span>" 'TODO: Get Descriptive String
            End Select
        End If
    End Function

    'Used on Search results an Favorites page to color-code genders.
    Function GetHoodName(ByVal intHoodIndex As Object)
        'If IsDBNull(intHoodIndex) Then
        'Return ""
        'Else
        'intHoodIndex = CByte(intHoodIndex)
        'Return HoodArray(intHoodIndex)
        'End If
    End Function

    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        'Manually restore the form values since we're using the GET method.
        'RestoreDropdown(strGenderID, GenderID)
        'RestoreDropdown(strSexualOrientationID, SexualOrientationID)
        'RestoreDropdown(strEthnicID, EthnicID)
        'RestoreDropdown(strBodyTypeID, BodyTypeID)
        'If IsNumeric(strHeightMin) Then
        'RestoreDropdown(CInt(strHeightMin) - 35, HeightMin)
        'End If
        'If IsNumeric(strHeightMax) Then
        'RestoreDropdown(CInt(strHeightMax) - 35, HeightMax)
        'End If
        'AgeMin.Value = strAgeMin
        'AgeMax.Value = strAgeMax
        'Keywords.Value = strKeywords


        Session("SearchCriteria") = ddlGenderID.SelectedValue & "," & ddlSexualOrientationID.SelectedValue & "," & ddlEthnicID.SelectedValue & "," & txtAgeMin.Text & "," & txtAgeMax.Text & "," & Server.HtmlEncode(txtKeywords.Text)
        Dim strWhere As New StringBuilder()
        strWhere.Append("ProfileStatusID=2")
        If (ddlGenderID.SelectedValue <> "") Then
            strWhere.Append(" AND GenderID=" & ddlGenderID.SelectedValue)
        End If
        If (ddlSexualOrientationID.SelectedValue <> "") Then
            strWhere.Append(" AND SexualOrientationID=" & ddlSexualOrientationID.SelectedValue)
        End If
        If (ddlEthnicID.SelectedValue <> "") Then
            strWhere.Append(" AND EthnicID=" & ddlEthnicID.SelectedValue)
        End If
        If (txtAgeMin.Text <> "") Then
            strWhere.Append(" AND Age >= " & txtAgeMin.Text)
        End If
        If (txtAgeMax.Text <> "") Then
            strWhere.Append(" AND Age <= " & txtAgeMax.Text)
        End If
        If (txtKeywords.Text <> "") Then
            If txtKeywords.Text.IndexOf(" ") <> -1 Then
                Dim keywordsArray() As String = txtKeywords.Text.Split()
                Dim strKey As String
                For Each strKey In keywordsArray
                    strWhere.Append(" AND AboutMe LIKE '%" & strKey & "%'")
                Next
            Else
                strWhere.Append(" AND AboutMe LIKE '%" & txtKeywords.Text & "%'")
            End If
        End If
        If (ddlHeightMin.SelectedValue <> "") Then
            strWhere.Append(" AND Height >= " & ddlHeightMin.SelectedValue)
        End If
        If (ddlHeightMax.SelectedValue <> "") Then
            strWhere.Append(" AND Height <= " & ddlHeightMax.SelectedValue)
        End If
        If (ddlBodyTypeID.SelectedValue <> "") Then
            strWhere.Append(" AND BodyTypeID=" & ddlBodyTypeID.SelectedValue)
        End If
        If (ddlLookingFor.SelectedValue <> "") Then
            strWhere.Append(" AND " & ddlLookingFor.SelectedValue & "=1")
        End If
        If lbNeighborhoodID.SelectedValue <> "" Then
            If InStr(lbNeighborhoodID.SelectedValue, ",") = 0 Then
                strWhere.Append(" AND NeighborhoodID=" & lbNeighborhoodID.SelectedValue)
            Else
                Dim aryHoods() As String = lbNeighborhoodID.SelectedValue.Split(",")
                Dim strHood As String
                Dim strOr As String = String.Empty
                For Each strHood In aryHoods
                    If (strOr <> "") Then
                        strOr += " OR "
                    End If
                    strOr += strHood
                Next
                strWhere.Append(" AND NeighborhoodID=" & strOr)
            End If
        End If
        'Count the number of records.
        Dim strSQL As String = String.Format("SELECT COUNT(*) FROM Profiles WHERE {0}", strWhere.ToString()) 'TODO: Move to Parameterized Stored Procedure
        'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
        Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
        Dim objCommand As New SqlCommand(strSQL, objConnection)
        objConnection.Open()
        intRecords = CInt(objCommand.ExecuteScalar())

        Dim strLimit As String = String.Empty
        Dim intNext As Integer = PAGE_SIZE
        Dim intStart As Integer = 0
        Dim intLast As Integer = intRecords
        If intRecords > PAGE_SIZE Then
            If IsNumeric(Request.QueryString("start")) And Not (Page.IsPostBack) Then
                intStart = CInt(Request.QueryString("start"))
            End If
            strLimit = String.Format(" LIMIT {0},{1}", CStr(intStart), CStr(PAGE_SIZE))
            If ((intRecords - (intStart + PAGE_SIZE)) < PAGE_SIZE) Then
                intNext = intRecords - (intStart + PAGE_SIZE)
            End If
            If intNext > 0 Then
                strNextPage = String.Format("<a href='search.aspx?start={0}'>Next {1}</a>&nbsp;&nbsp;&nbsp;&nbsp;", CStr(intStart + PAGE_SIZE), CStr(intNext))
                intLast = intStart + PAGE_SIZE
            End If
        End If

        If (intStart - intLast) < -1 Then
            strRecordsFound = String.Format("({0}-{1} of {2})", CStr(intStart + 1), CStr(intLast), CStr(intRecords))
        Else
            strRecordsFound = String.Format("({0} of {1})", CStr(intLast), CStr(intRecords))
        End If
        Dim strOrderBy As String = Request.QueryString("sortby")
        If (InStr(strOrderBy, " ") = 0 And strOrderBy <> "") Then
            If strOrderBy = "ImageName" Then
                strOrderBy = String.Format("{0} DESC", strOrderBy)
            End If
            strOrderBy = String.Format("ORDER BY {0}", strOrderBy)
        End If
        If intRecords > 3 Then
            arraySortLinks(0) = "href='search.aspx?sortby=UserName'"
            arraySortLinks(1) = "href='search.aspx?sortby=GenderID'"
            arraySortLinks(2) = "href='search.aspx?sortby=Age'"
            arraySortLinks(3) = "href='search.aspx?sortby=ImageName'"
            arraySortLinks(4) = "href='search.aspx?sortby=NeighborhoodID'"
        End If
        'Retrieve the records.
        objCommand.CommandText = String.Format("SELECT ProfileID,UserName,GenderID,Age,NeighborhoodID, ImageName FROM Profiles WHERE {0} {1}{2};", strWhere.ToString(), strOrderBy, strLimit) 'TODO: Move to Parameterized Stored Procedure
        'Response.Write("SELECT ProfileID,UserName,GenderID,Age,NeighborhoodID,ImageName FROM Profiles WHERE " & strWhere.toString() & strOrderBy & strLimit)'TODO: Move to Parameterized Stored Procedure
        searchDataList.DataSource = objCommand.ExecuteReader(CommandBehavior.CloseConnection)
        searchDataList.DataBind()
    End Sub
End Class
