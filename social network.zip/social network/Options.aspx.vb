﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Partial Class Options
    Inherits System.Web.UI.Page

    Public blnPrintForm As Boolean = True
    Public blnChangeMade As Boolean = False

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("UserName") = "" Then
            'TODO: More of a WARNING not so much an ERROR see other notes.
            litErrorMessage.Text = "Please login to change your options." 'TODO: Move to StatusMessage/ErrorMessage object
            blnPrintForm = False
        Else
            Dim strUserName As String = Session("UserName")
            Dim strProfileID As String = Session("ProfileID")
            'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
            Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
            Dim objDataReader As SqlDataReader
            Dim objCommand As New SqlCommand
            objCommand.Connection = objConnection
            objConnection.Open()
            Dim strSQL As String = String.Empty
            If Page.IsPostBack Then

                Dim oldForward As String = Request.Form("old_ForwardMessages")
                Dim strNewForward As String = Request.Form("ForwardMessages")

                If oldForward <> strNewForward Then
                    strSQL = String.Format("UPDATE Profiles SET ForwardMessages='{0}' WHERE ProfileID='{1}';", strNewForward, Session("ProfileID")) 'UPDATE to turn Message Forwarding on or off.
                    objCommand.CommandText = strSQL
                    objCommand.ExecuteNonQuery()
                    blnChangeMade = True
                End If

                Dim strRemoveID As String = Request.Form("RemoveID")
                If strRemoveID <> "" Then
                    Dim strDelete As New StringBuilder()
                    'DELETE the message blocks.
                    strDelete.Append("DELETE FROM messageblocks WHERE ProfileID='" & Session("ProfileID") & "' AND BlockID=")
                    If strRemoveID.IndexOf(",") = -1 Then
                        strDelete.Append(strRemoveID)
                    Else
                        Dim arrayIDs() As String = strRemoveID.Split(",")
                        strDelete.Append(arrayIDs(0))
                        Dim intIndex As Integer
                        For intIndex = 1 To arrayIDs.Length - 1
                            strDelete.Append(" OR BlockID=" & arrayIDs(intIndex))
                        Next
                    End If
                    objCommand.CommandText = strDelete.ToString() & ";"
                    objCommand.ExecuteNonQuery()
                    blnChangeMade = True
                End If


                If blnChangeMade Then
                    'MessageCell.CssClass = "fMsgBox"
                    litStatusMessage.Text = "The changes you made were saved." 'TODO: Move to StatusMessage/ErrorMessage object
                    blnPrintForm = False
                Else
                    'TODO: This is more of a WARNING not really an ERROR so ADD a WARNING to the code
                    litErrorMessage.Text = "You didn't make any changes." 'TODO: Move to StatusMessage/ErrorMessage object
                End If

            Else 'Display the form.
                'TODO: Move to Parameterized Stored Procedure
                objCommand.CommandText = String.Format("SELECT ForwardMessages,Email FROM Profiles WHERE ProfileID={0} AND UserName='{1}' AND ProfileStatusID=2;", strProfileID, strUserName)
                objDataReader = objCommand.ExecuteReader()
                If Not (objDataReader.Read()) Then
                    litErrorMessage.Text = "There was an error getting your settings."
                    objDataReader.Close()
                Else
                    'Message forwarding.
                    Dim blnForwardMessages As Boolean = CBool(objDataReader("ForwardMessages"))
                    Email.Text = objDataReader("Email")
                    objDataReader.Close()
                    If blnForwardMessages Then
                        ForwardMessages.Items(1).Selected = True
                        old_ForwardMessages.Value = "1"
                    Else
                        ForwardMessages.Items(0).Selected = True
                        old_ForwardMessages.Value = "0"
                    End If
                    'Message blocks.
                    'TODO: Move to Parameterized Stored Procedure
                    objCommand.CommandText = String.Format("SELECT m.RecordID,m.BlockID,p.UserName FROM messageblocks m INNER JOIN profiles p ON m.BlockID = p.ProfileID WHERE m.ProfileID={0} ORDER BY p.UserName;", Session("ProfileID"))
                    objDataReader = objCommand.ExecuteReader()
                    While objDataReader.Read()
                        BlockID.Items.Add(New ListItem(objDataReader("UserName"), objDataReader("BlockID")))
                    End While
                    objDataReader.Close()
                End If
                objConnection.Close()
            End If
        End If

        If litErrorMessage.Text <> "" Then
            phErrorMessage.Visible = True
        Else
            phErrorMessage.Visible = False
        End If

        If litStatusMessage.Text <> "" Then
            phStatusMessage.Visible = True
        Else
            phStatusMessage.Visible = False
        End If
    End Sub

    Protected Sub btnRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRemove.Click

    End Sub

    Protected Sub btnSaveChanges_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSaveChanges.Click

    End Sub

    Protected Sub btnDeleteProfile_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDeleteProfile.Click
        Response.Redirect("deleteprofile.aspx")
    End Sub
End Class
