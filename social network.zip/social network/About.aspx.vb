﻿Imports System.Configuration
Imports System.Data
Imports System.Data.Odbc

Partial Class About
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Page.Header.Title = Resources.About.Title
        'Call ProcessLogin() '!!! Login button
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class
