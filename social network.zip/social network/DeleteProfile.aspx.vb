﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.Odbc
Imports System.IO

Imports Configuration.ErrorMessages

Partial Class deleteprofile
    Inherits System.Web.UI.Page
    ' name:		deleteprofile.aspx
    ' purpose:	allows user to delete their own profile, and deletes all associated
    '			records.
    Public blnPrintForm As Boolean = True
    Public blnChangeMade As Boolean = False

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Call ProcessLogin()

        'TODO: Check to make sure this works
        If MessageCell.Text <> String.Empty Then
            phMessageCell.Visible = True
        End If

        If blnPrintForm Then
            phPrintForm.Visible = True
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("UserName") = "" Then
            MessageCell.Text = "Please login to delete your profile."     'TODO: Move to StatusMessage/ErrorMessage object
            blnPrintForm = False
        Else
            Dim strUserName As String = Request.Form("UserName")
            Dim strProfileID As String = Request.Form("ProfileID")
            If Page.IsPostBack Then
                If (Session("UserName") = strUserName And Session("ProfileID") = strProfileID) Then
                    Dim objConnection As New OdbcConnection(ConfigurationManager.AppSettings("DB_CONNECTION_STRING"))
                    Dim objDataReader As OdbcDataReader
                    Dim objCommand As New OdbcCommand
                    objCommand.Connection = objConnection
                    objConnection.Open()
                    'TODO: Move to Parameterized Stored Procedure
                    objCommand.CommandText = String.Format("SELECT ImageName FROM Profiles WHERE ProfileID={0} AND UserName='" & strUserName & "';", strProfileID)
                    objDataReader = objCommand.ExecuteReader()
                    If Not (objDataReader.Read()) Then
                        MessageCell.Text = "The profile does not exist." 'TODO: Move to StatusMessage/ErrorMessage object
                        objDataReader.Close()
                    Else
                        Dim strImageName As String = ""
                        If Not (objDataReader.IsDBNull(0)) Then
                            strImageName = objDataReader("ImageName")
                        End If
                        objDataReader.Close()
                        'TODO: We shouldn't really delete anything if we can avoid it.  We should simply shut it off. Move to another table.
                        'UPDATE the messages table to turn on the delete flags for sent then received messages.
                        objCommand.CommandText = String.Format("UPDATE messages SET DeletedBySender=1 WHERE SenderID={0};", strProfileID)
                        objCommand.ExecuteNonQuery()
                        objCommand.CommandText = String.Format("UPDATE messages SET DeletedByRecipient=1 WHERE RecipientID={0};", strProfileID)
                        objCommand.ExecuteNonQuery()
                        'DELETE all message blocks associated with the user.
                        objCommand.CommandText = String.Format("DELETE FROM messageblocks WHERE BlockID={0} OR ProfileID={1};", strProfileID, strProfileID)
                        objCommand.ExecuteNonQuery()
                        'DELETE all favorites associated with the user.
                        objCommand.CommandText = String.Format("DELETE FROM favorites WHERE FavoriteID={0} OR ProfileID={1};", strProfileID, strProfileID)
                        objCommand.ExecuteNonQuery()
                        'DELETE all abuse reports associated with the user.
                        objCommand.CommandText = String.Format("DELETE FROM abusereports WHERE AbuserID={0} OR ReporterID={1};", strProfileID, strProfileID)
                        objCommand.ExecuteNonQuery()
                        'UPDATE the profiles table.
                        objCommand.CommandText = "UPDATE Profiles SET Password=MD5('x'),Email='x',GenderID=0,Age=0," & _
                         "SexualOrientationID=null,EthnicID=null,Height=null,BodyTypeID=null,NeighborhoodID=null,AboutMe=null,WantActivityPartner" & _
                         "=null,WantFriend=null,WantDate=null,WantLTR=null,ForwardMessages=null,ImageCaption=null,ProfileStatusID=4 " & _
                         "WHERE ProfileID=" & strProfileID & ";"
                        objCommand.ExecuteNonQuery()
                        'DELETE the user's photo.
                        If strImageName <> "" Then
                            Dim strSavePath As String = Server.MapPath(ConfigurationManager.AppSettings("IMAGE_FOLDER_PATH")) & "\"
                            If File.Exists(strSavePath & strImageName) Then
                                File.Delete(strSavePath & strImageName)
                            End If
                        End If
                        MessageCell.CssClass = "fMsgBox"
                        MessageCell.Text = "Your profile has been deleted." 'TODO: Move to StatusMessage/ErrorMessage object
                        blnPrintForm = False
                        Session("UserName") = String.Empty
                        Session("ProfileID") = String.Empty
                        Session.Abandon()
                    End If
                    objConnection.Close()
                End If
            Else
                UserName.Value = Session("UserName")
                ProfileID.Value = Session("ProfileID")
            End If
        End If
    End Sub


    Public LOGIN_strErrorMessage As String

    Public Sub ProcessLogin()
        If Request.Form("login") = "yes" Then
            Dim strUserName As String = Request.Form("username")
            Dim strPassword As String = Request.Form("password")
            Dim strRegex As String = "^[a-z0-9A-Z_]{4,16}$" 'TODO: Move to a regex manager object
            'Check if username or password is invalid.
            If Not (Regex.IsMatch(strUserName, strRegex)) Or Not (Regex.IsMatch(strPassword, strRegex)) Then
                LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_INVALID_1
            Else
                Dim intProfileID As Integer
                Dim intProfileStatusID As Byte
                Dim objConnection As New OdbcConnection(ConfigurationManager.AppSettings("DB_CONNECTION_STRING"))
                Dim objDataReader As OdbcDataReader
                'TODO: Move to Parameterized Stored Procedure
                Dim strSQL As String = String.Format("SELECT ProfileID,UserName,ProfileStatusID FROM Profiles WHERE UserName='{0}' AND Password=MD5('{1}');", strUserName, strPassword)
                Dim objCommand As New OdbcCommand(strSQL, objConnection)
                Try
                    objConnection.Open()
                    objDataReader = objCommand.ExecuteReader()
                    If objDataReader.Read() Then
                        intProfileID = objDataReader("ProfileID")
                        strUserName = objDataReader("UserName")
                        intProfileStatusID = CByte(objDataReader("ProfileStatusID"))
                    Else
                        LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_INVALID_2
                    End If
                    objDataReader.Close()
                    Select Case intProfileStatusID
                        Case 1
                            LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_INACTIVE
                        Case 2
                            Session("ProfileID") = intProfileID
                            Session("UserName") = strUserName
                            Session("MessageFolder") = String.Empty
                            objCommand.CommandText = "spUpdateLoginDatebyProfileID"
                            objCommand.Parameters.AddWithValue("@ProfileID", intProfileID)
                            objCommand.ExecuteNonQuery()
                        Case 3
                            LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_SUSPENDED
                    End Select
                    objConnection.Close()
                Catch excep As Exception
                    LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_DB
                End Try
            End If
        End If
    End Sub

    Protected Sub btnNo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNo.Click
        Response.Redirect("/options.aspx")
    End Sub
End Class
