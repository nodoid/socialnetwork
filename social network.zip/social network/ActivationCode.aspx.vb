﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Net.Mail

Imports Configuration.CompanyInfo
Imports Configuration.ErrorMessages
Imports Configuration.EmailTemplates

Partial Class activationcode
    Inherits System.Web.UI.Page

    Dim strUserName As String
    Dim strEmail As String
    Dim strActivationCode As String
    Dim blnEmailSent As Boolean = False



    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Page.Header.Title = Resources.ActivationCode.Title
        Call ProcessLogin()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'TODO: Make WARNING message dialogs... SUCCESS is incorrect
        litStatusMessage.Text = Resources.ActivateProfile.litStatusMessage3
        mvEmailSent.SetActiveView(vwEmailForm)
    End Sub

    Public LOGIN_strErrorMessage As String

    Public Sub ProcessLogin()
       If Request.Form("login") = "yes" Then
            Dim strUserName As String = Request.Form("username")
            Dim strPassword As String = Request.Form("password")
            Dim strRegex As String = "^[a-z0-9A-Z_]{4,16}$"   'TODO: Move to Regex object to standardize all RegEx strings
            'Check if username or password is invalid.
            If Not (Regex.IsMatch(strUserName, strRegex)) Or Not (Regex.IsMatch(strPassword, strRegex)) Then
                LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_INVALID_1
            Else
                Dim intProfileID As Integer
                Dim intProfileStatusID As Byte
                'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
                Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
                Dim objDataReader As SqlDataReader
                'TODO: Move to Parameterized Stored Procedure
                Dim strSQL As String = String.Format("SELECT ProfileID,UserName,ProfileStatusID FROM Profiles WHERE UserName='{0}' AND Password=MD5('{1}');", strUserName, strPassword) 'TODO: Move to Parameterized Stored Procedure
                Dim objCommand As New SqlCommand(strSQL, objConnection)
                '-----------------------------------------------------
                'objCommand.Parameters.AddWithValue("@UserName", UserName.Text.Trim().ToLower())
                'objCommand.Parameters.AddWithValue("@Password", Password.Text) 'TODO: Use 128-bitMD5 1-way hash encryption.
                'objCommand.Parameters.AddWithValue("@Email", Email.Text.ToLower().Trim())
                'objCommand.CommandText = "spCreateProfile"
                '-----------------------------------------------------
                Try
                    objConnection.Open()
                    objDataReader = objCommand.ExecuteReader()
                    If objDataReader.Read() Then
                        intProfileID = objDataReader("ProfileID")
                        strUserName = objDataReader("UserName")
                        intProfileStatusID = CByte(objDataReader("ProfileStatusID"))
                    Else
                        LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_INVALID_2
                    End If
                    objDataReader.Close()
                    Select Case intProfileStatusID
                        Case 1
                            LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_INACTIVE
                        Case 2
                            Session("ProfileID") = intProfileID
                            Session("UserName") = strUserName
                            Session("MessageFolder") = String.Empty
                            objCommand.CommandText = "spUpdateLoginDatebyProfileID"   'TODO: Is this something that could be handled better?  This could be furth abstracted.
                            objCommand.Parameters.AddWithValue("@ProfileID", intProfileID)
                            objCommand.ExecuteNonQuery()
                        Case 3
                            LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_LOGIN_SUSPENDED
                    End Select
                    objConnection.Close()
                Catch excep As Exception
                    LOGIN_strErrorMessage = ErrorMessages.ERROR_MESSAGE_DB
                End Try
                objConnection.Dispose()
                objCommand.Dispose()
            End If
        End If
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        strUserName = UserName.Text
        strEmail = Email.Text

        litStatusMessage.Text = ""
        'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
        Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
        Dim objDataReader As SqlDataReader
        Dim strTrueEmail As String
        Dim strTrueID As String
        Dim intProfileStatusID As Integer
        'TODO: Move to Parameterized Stored Procedures
        '1. Make sure the User Name exists.
        Dim strSQL = String.Format("SELECT ProfileID,Email,ProfileStatusID,ActivationCode FROM Profiles WHERE UserName = '{0}';", strUserName) 'TODO: Move to Parameterized Stored Procedure
        Dim objCommand As New SqlCommand(strSQL, objConnection)

        '-----------------------------------------------------
        'objCommand.Parameters.AddWithValue("@UserName", UserName.Text.Trim().ToLower())
        'objCommand.Parameters.AddWithValue("@Email", Email.Text.ToLower().Trim())
        'objCommand.CommandText = "spCreateProfile"
        '-----------------------------------------------------

        objConnection.Open()
        objDataReader = objCommand.ExecuteReader()
        If Not (objDataReader.Read()) Then
            litStatusMessage.Text = String.Empty
            litErrorMessage.Text = String.Format(Resources.ActivateProfile.litErrorMessage6, strUserName) 'TODO: Reference ErrorMessages Object - 
            objDataReader.Close()
        Else
            '2. Grab the correct information.
            strTrueEmail = objDataReader.Item("Email")
            strTrueID = objDataReader.Item("ProfileID")
            intProfileStatusID = objDataReader.Item("ProfileStatusID")
            strActivationCode = objDataReader.Item("ActivationCode")
            objDataReader.Close()
            '3. Make sure the profile is active.
            If LCase(strEmail) <> LCase(strTrueEmail) Then
                litErrorMessage.Text = Resources.ActivateProfile.litErrorMessage5 'TODO: Reference ErrorMessages Object - 
            ElseIf intProfileStatusID = 2 Then
                litErrorMessage.Text = String.Empty
                litStatusMessage.Text = Resources.ActivateProfile.litErrorMessage4 'TODO: Reference ErrorMessages Object - 
            ElseIf intProfileStatusID = 3 Then
                litErrorMessage.Text = Resources.ActivateProfile.litErrorMessage3 'TODO: Reference ErrorMessages Object - 
            Else

                'Send an e-mail to the user with the activation code.
                Dim mail As MailMessage = New MailMessage()
                mail.To.Add(Email.Text)
                mail.From = New MailAddress(ConfigurationManager.AppSettings("PROFILE_EMAIL"))
                mail.Subject = EmailTemplate.ACTIVATE_ACCOUNT_SUBJECT

                Dim strBody = String.Format(EmailTemplate.ACTIVATE_ACCOUNT_BODY, "[EMAIL TITLE]", "info@{14}", "[LOGO]", CompanyInfo.COMPANY_NAME, "[SUBSCRIBE]", "[UNSUBSCRIBE]", "[FORWARD]", "[SHOWEMAIL]", strUserName, strActivationCode, CompanyInfo.COMPANY_ADDRESS, CompanyInfo.COMPANY_CITY, CompanyInfo.COMPANY_STATE, CompanyInfo.COMPANY_ZIP, CompanyInfo.COMPANY_DOMAIN, "[UNSUBSCRIBE]", Now()) 'Activation Code Email Template 'TODO: Move variables to EmailTemplate object

                mail.Body = strBody
                mail.IsBodyHtml = True
                Dim smtp As SmtpClient = New SmtpClient()
                smtp.Host = ConfigurationManager.AppSettings("SMTP_SERVER")
                smtp.Credentials = New System.Net.NetworkCredential("test@gmail.com", "!gmail@test#")   'TODO: Setup TEST ACCOUNT
                smtp.EnableSsl = True

                Try
                    smtp.Send(mail) 'Send an e-mail to the user with the activation code.
                Catch ex As Exception
                    objCommand.CommandText = String.Format("INSERT INTO emailerrors (FromEmail,ToEmail,Subject,Body,ExceptionError) VALUES ('{0}','{1}','{2}','{3}','{4}');", ConfigurationManager.AppSettings("PROFILE_EMAIL"), mail.To.ToString(), Server.HtmlEncode(mail.Subject), Server.HtmlEncode(mail.Body), Server.HtmlEncode(ex.ToString))
                    objCommand.ExecuteNonQuery()
                Finally
                    litErrorMessage.Text = String.Empty
                    litStatusMessage.Text = String.Format(Resources.ActivateProfile.litStatusMessage4, Email.Text) 'TODO: Move Reference to ErrorMessage object check existing *.resx
                    'TODO: Set Email Sent Status Message litStatusMessage & phStatusMessage
                    smtp.Dispose()
                    mail.Dispose()
                End Try
                blnEmailSent = True

            End If
        End If
        objCommand.Dispose()
        objConnection.Close()
        objConnection.Dispose()

        If litErrorMessage.Text <> "" Then
            phErrorMessage.Visible = True
        Else
            phErrorMessage.Visible = False
        End If

        If litStatusMessage.Text <> "" Then
            phStatusMessage.Visible = True
        Else
            phStatusMessage.Visible = False
        End If

        If blnEmailSent Then
            mvEmailSent.SetActiveView(vwEmailFormResponse)
        Else
            mvEmailSent.SetActiveView(vwEmailForm)
        End If
    End Sub
End Class
