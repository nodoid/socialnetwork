-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	3.23.53-max-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Remove the CREATE line below if you already have a database setup.
-- 
--

--CREATE DATABASE SocialNetwork;


--
-- Change this to your database name.
--
USE SocialNetwork;

--
-- Table structure for table `dating_db`.`abusereports`
--

DROP TABLE IF EXISTS abusereports;
CREATE TABLE abusereports (
  RecordID int(10) unsigned NOT NULL auto_increment,
  RecordDate timestamp(14) NOT NULL,
  AbuserID int(10) unsigned NOT NULL default '0',
  ReporterID int(10) unsigned NOT NULL default '0',
  ReporterComments varchar(128) default '',
  AbuseTypeID tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`RecordID`)
) TYPE=MyISAM;

--
-- Dumping data for table `dating_db`.`abusereports`
--

/*!40000 ALTER TABLE `abusereports` DISABLE KEYS */;
/*!40000 ALTER TABLE `abusereports` ENABLE KEYS */;


--
-- Table structure for table `dating_db`.`abusers`
--

DROP TABLE IF EXISTS `abusers`;
CREATE TABLE `abusers` (
  `RecordID` int(10) unsigned NOT NULL auto_increment,
  `SuspensionDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `DeletionDate` timestamp(14) NOT NULL,
  `FlagTypeID` tinyint(4) NOT NULL default '0',
  `AbuserUserName` varchar(16) NOT NULL default '',
  `AbuserEmail` text NOT NULL,
  PRIMARY KEY  (`RecordID`)
) TYPE=MyISAM;

--
-- Dumping data for table `dating_db`.`abusers`
--

/*!40000 ALTER TABLE `abusers` DISABLE KEYS */;
/*!40000 ALTER TABLE `abusers` ENABLE KEYS */;


--
-- Table structure for table `dating_db`.`abusetypes`
--

DROP TABLE IF EXISTS `abusetypes`;
CREATE TABLE `abusetypes` (
  `AbuseTypeID` tinyint(3) unsigned NOT NULL auto_increment,
  `AbuseTypeName` tinytext NOT NULL,
  PRIMARY KEY  (`AbuseTypeID`)
) TYPE=MyISAM COMMENT='static';

--
-- Dumping data for table `dating_db`.`abusetypes`
--

/*!40000 ALTER TABLE `abusetypes` DISABLE KEYS */;
INSERT INTO abusetype (AbuseTypeName)  
 SELECT 'Profile contains nudity'
 UNION ALL
 SELECT 'Profile includes a picture of a minor'
 UNION ALL
 SELECT 'Profile contains copyrighted material'
 UNION ALL
 SELECT 'Profile contains spam'
 UNION ALL
 SELECT 'Profile contains racist or hateful words'
 UNION ALL
 SELECT 'Other (please comment)';
GO
/*!40000 ALTER TABLE `abusetypes` ENABLE KEYS */;


--
-- Table structure for table `dating_db`.`bodytypes`
--

DROP TABLE IF EXISTS `bodytypes`;
CREATE TABLE `bodytypes` (
  `BodyTypeID` tinyint(3) unsigned NOT NULL auto_increment,
  `BodyTypeName` tinytext NOT NULL,
  PRIMARY KEY  (`BodyTypeID`)
) TYPE=MyISAM COMMENT='static';

INSERT INTO bodytype (BodyTypeName)  
 SELECT 'average'
 UNION ALL
 SELECT 'slim/slender'
 UNION ALL
 SELECT 'athletic'
 UNION ALL
 SELECT 'thick'
 UNION ALL
 SELECT 'a little extra padding'
 UNION ALL
 SELECT 'large';

DROP TABLE IF EXISTS `databaseerrors`;
CREATE TABLE `databaseerrors` (
  `ErrorID` smallint(5) unsigned NOT NULL auto_increment,
  `ErrorDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `SqlStatement` text NOT NULL,
  `Exception` text NOT NULL,
  `PageName` tinytext NOT NULL,
  PRIMARY KEY  (`ErrorID`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `emailerrors`;
CREATE TABLE `emailerrors` (
  `EmailErrorID` int(11) NOT NULL auto_increment,
  `FromEmail` text NOT NULL,
  `ToEmail` text NOT NULL,
  `Subject` varchar(128) NOT NULL default '',
  `Body` text NOT NULL,
  `ErrorDate` timestamp(14) NOT NULL,
  `ExceptionError` text,
  PRIMARY KEY  (`EmailErrorID`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `ethnicities`;
CREATE TABLE `ethnicities` (
  `EthnicID` tinyint(4) NOT NULL auto_increment,
  `EthnicName` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`EthnicID`)
) TYPE=MyISAM COMMENT='static';

INSERT INTO `ethnicities` (`EthnicID`,`EthnicName`) VALUES 
 (1,'asian'),
 (2,'black / african'),
 (3,'hispanic / latino'),
 (4,'indian / south asian'),
 (5,'middle eastern / arab'),
 (6,'native american'),
 (7,'pacific islander'),
 (8,'white / caucasian'),
 (9,'mixed'),
 (10,'other');

DROP TABLE IF EXISTS `favorites`;
CREATE TABLE `favorites` (
  `RecordID` int(10) unsigned NOT NULL auto_increment,
  `ProfileID` int(10) unsigned NOT NULL default '0',
  `FavoriteID` int(10) unsigned NOT NULL default '0',
  `MutualFavorite` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`RecordID`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `genders`;
CREATE TABLE `genders` (
  `GenderID` tinyint(3) unsigned NOT NULL auto_increment,
  `GenderName` tinytext NOT NULL,
  PRIMARY KEY  (`GenderID`)
) TYPE=MyISAM COMMENT='static';

INSERT INTO `genders` (`GenderID`,`GenderName`) VALUES 
 (1,'female'),
 (2,'male'),
 (3,'transgender(ftm)'),
 (4,'transgender(mtf)');

DROP TABLE IF EXISTS `messageblocks`;
CREATE TABLE `messageblocks` (
  `RecordID` int(10) unsigned NOT NULL auto_increment,
  `ProfileID` int(10) unsigned NOT NULL default '0',
  `BlockID` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`RecordID`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `MessageID` int(10) unsigned NOT NULL auto_increment,
  `MessageDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `SenderID` int(10) unsigned NOT NULL default '0',
  `RecipientID` int(10) unsigned NOT NULL default '0',
  `Subject` varchar(128) default '',
  `Body` text NOT NULL,
  `MessageRead` tinyint(1) default '0',
  `DeletedByRecipient` tinyint(1) default '0',
  `DeletedBySender` tinyint(1) default '0',
  PRIMARY KEY  (`MessageID`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS `neighborhoods`;
CREATE TABLE `neighborhoods` (
  `NeighborhoodID` tinyint(3) unsigned NOT NULL auto_increment,
  `NeighborhoodName` tinytext NOT NULL,
  PRIMARY KEY  (`NeighborhoodID`)
) TYPE=MyISAM COMMENT='static';

INSERT INTO `neighborhoods` (`NeighborhoodID`,`NeighborhoodName`) VALUES 
 (1,'bayview / hunters point'),
 (2,'bernal heights'),
 (3,'castro / eureka valley'),
 (4,'chinatown'),
 (5,'cole valley'),
 (6,'excelsior / outer mission'),
 (7,'financial district'),
 (8,'glen park'),
 (9,'haight ashbury'),
 (10,'hayes valley'),
 (11,'ingleside / merced / ocean view (SFSU,CCSF)'),
 (12,'inner richmond'),
 (13,'inner sunset / parnassus heights (UCSF)'),
 (14,'laurel heights / presidio'),
 (15,'lower haight / fillmore'),
 (16,'marina / cow hollow'),
 (17,'mission district'),
 (18,'nob hill'),
 (19,'noe valley'),
 (20,'north beach / telegraph hill'),
 (21,'pacific heights'),
 (22,'panhandle (USF)'),
 (23,'potrero hill / dogpatch'),
 (24,'richmond / seacliff'),
 (25,'russian hill'),
 (26,'soma / south beach / mission bay'),
 (27,'sunset / parkside'),
 (28,'tenderloin / civic center'),
 (29,'tendernob'),
 (30,'twin peaks / diamond heights'),
 (31,'visitacion valley / sunnydale / portola'),
 (32,'west portal / st. francis wood / forest hill'),
 (33,'western addition / japantown');
INSERT INTO `neighborhoods` (`NeighborhoodID`,`NeighborhoodName`) VALUES 
 (34,'East Bay'),
 (35,'North Bay'),
 (36,'Peninsula'),
 (37,'South Bay');

DROP TABLE IF EXISTS `photos`;
CREATE TABLE `photos` (
  `PhotoID` int(10) unsigned NOT NULL auto_increment,
  `ProfileID` int(10) unsigned NOT NULL default '0',
  `PhotoFilename` varchar(40) NOT NULL default '',
  `Caption` varchar(255) default NULL,
  PRIMARY KEY  (`PhotoID`)
) TYPE=MyISAM;

--
-- Dumping data for table `dating_db`.`photos`
--

/*!40000 ALTER TABLE `photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `photos` ENABLE KEYS */;


--
-- Table structure for table `dating_db`.`profiles`
--

DROP TABLE IF EXISTS `profiles`;
CREATE TABLE `profiles` (
  `ProfileID` int(10) unsigned NOT NULL auto_increment,
  `UserName` varchar(16) NOT NULL default '',
  `Password` varchar(32) NOT NULL default '',
  `Email` text NOT NULL,
  `GenderID` tinyint(3) NOT NULL default '0',
  `Age` tinyint(3) NOT NULL default '0',
  `SexualOrientationID` tinyint(3) default '0',
  `SignID` tinyint(3) default '0',
  `Height` tinyint(3) default '0',
  `BodyTypeID` tinyint(3) default '0',
  `EthnicID` tinyint(4) default '0',
  `NeighborhoodID` tinyint(3) default '0',
  `AboutMe` text,
  `WantActivityPartner` tinyint(1) default '0',
  `WantFriend` tinyint(1) default '0',
  `WantDate` tinyint(1) default '0',
  `WantLTR` tinyint(1) default '0',
  `ForwardMessages` tinyint(1) default '0',
  `ImageName` varchar(40) default NULL,
  `ImageCaption` varchar(255) default NULL,
  `CreationDate` datetime default '0000-00-00 00:00:00',
  `ModificationDate` datetime default '0000-00-00 00:00:00',
  `LoginDate` datetime default '0000-00-00 00:00:00',
  `ActivationCode` varchar(16) default '0',
  `ProfileStatusID` tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (`ProfileID`)
) TYPE=MyISAM;

--
-- Dumping data for table `dating_db`.`profiles`
--

/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;


--
-- Table structure for table `dating_db`.`profilestatuses`
--

DROP TABLE IF EXISTS `profilestatuses`;
CREATE TABLE `profilestatuses` (
  `ProfileStatusID` tinyint(3) unsigned NOT NULL auto_increment,
  `ProfileStatusName` tinytext NOT NULL,
  PRIMARY KEY  (`ProfileStatusID`)
) TYPE=MyISAM COMMENT='static';

--
-- Dumping data for table `dating_db`.`profilestatuses`
--

/*!40000 ALTER TABLE `profilestatuses` DISABLE KEYS */;
INSERT INTO `profilestatuses` (`ProfileStatusID`,`ProfileStatusName`) VALUES 
 (1,'pending activation'),
 (2,'active'),
 (3,'suspended'),
 (4,'deleted');
/*!40000 ALTER TABLE `profilestatuses` ENABLE KEYS */;


--
-- Table structure for table `dating_db`.`sexualorientations`
--

DROP TABLE IF EXISTS `sexualorientations`;
CREATE TABLE `sexualorientations` (
  `SexualOrientationID` tinyint(3) unsigned NOT NULL auto_increment,
  `SexualOrientationName` tinytext NOT NULL,
  PRIMARY KEY  (`SexualOrientationID`)
) TYPE=MyISAM COMMENT='static';

--
-- Dumping data for table `dating_db`.`sexualorientations`
--

/*!40000 ALTER TABLE `sexualorientations` DISABLE KEYS */;
INSERT INTO `sexualorientations` (`SexualOrientationID`,`SexualOrientationName`) VALUES 
 (1,'straight'),
 (2,'gay/lesbian'),
 (3,'bisexual');
/*!40000 ALTER TABLE `sexualorientations` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
