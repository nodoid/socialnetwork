﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging

Imports Globals

Partial Class EditPhotos
    Inherits System.Web.UI.Page

    Public arrayPhotos((MAX_EXTRA_PHOTOS - 1), 2) As String
    Public blnPrintForm As Boolean = True
    Public blnHasImage As Boolean = False
    'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
    Public objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
    Public strImageName As String
    Public strMainImageCaption As String
    Public strSQL As String

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("UserName") = String.Empty Then
            litErrorMessage.Text = "Please login to update your photos." 'TODO: Move to StatusMessage/ErrorMessage object
            blnPrintForm = False
        Else
            Dim strUserName As String = Session("UserName")
            Dim objDataReader As SqlDataReader
            Dim objFirstCommand As New SqlCommand()
            objFirstCommand.Connection = objConnection
            objConnection.Open()
            'TODO: Move to Parameterized Stored Procedure
            objFirstCommand.CommandText = String.Format("SELECT ImageName, ImageCaption FROM Profiles WHERE ProfileID={0} AND ProfileStatusID=2;", Session("ProfileID"))

            objDataReader = objFirstCommand.ExecuteReader()
            If objDataReader.Read() Then
                If Not (objDataReader.IsDBNull(0)) Then
                    strImageName = objDataReader("ImageName")
                    If Not (objDataReader.IsDBNull(1)) Then
                        strMainImageCaption = objDataReader("ImageCaption")
                    End If
                    blnHasImage = True
                    objDataReader.Close()
                    Dim strFileToDelete As String = String.Empty
                    Dim strMainImageToRemove As String = Request.Form("removemain")
                    If strMainImageToRemove <> "" Then
                        'Make sure user is not trying to delete the same main photo twice.
                        If strMainImageToRemove <> strImageName Then
                            'TODO: This is actually a WARNING 
                            litErrorMessage.Text = "NO CHANGES WERE MADE.<br /><br />Please don't refresh your browser when deleting photos." 'TODO: Move to StatusMessage/ErrorMessage object
                        Else
                            strFileToDelete = strMainImageToRemove
                            'TODO: Move to Parameterized Stored Procedure
                            objFirstCommand.CommandText = String.Format("SELECT PhotoID,PhotoFilename,Caption FROM photos WHERE ProfileID={0} ORDER BY PhotoID LIMIT 1;", Session("ProfileID"))
                            objDataReader = objFirstCommand.ExecuteReader()
                            If objDataReader.Read() Then
                                'Transfer the user's first photo in the photos table to the profiles table
                                'if the user has any extra photos.
                                strSQL = String.Format("UPDATE Profiles SET ImageName=""{0}"", ImageCaption=""{1}"" WHERE ProfileID={2};", objDataReader("PhotoFilename"), objDataReader("Caption"), Session("ProfileID"))
                                Dim strDelete As String = String.Format("DELETE FROM photos WHERE PhotoID={0};", objDataReader("PhotoID"))
                                strImageName = objDataReader("PhotoFilename")
                                strMainImageCaption = objDataReader("Caption")
                                objDataReader.Close()
                                objFirstCommand.CommandText = strSQL
                                objFirstCommand.ExecuteNonQuery()
                                objFirstCommand.CommandText = strDelete
                                objFirstCommand.ExecuteNonQuery()
                                litStatusMessage.Text = "Your main photo has been changed." 'TODO: Move to StatusMessage/ErrorMessage object
                            Else
                                objDataReader.Close()
                                'Otherwise, remove the image from the profiles table.
                                objFirstCommand.CommandText = String.Format("UPDATE Profiles SET ImageName=NULL WHERE ProfileID={0};", Session("ProfileID"))
                                objFirstCommand.ExecuteNonQuery()
                                litStatusMessage.Text = "Your photo has been removed." 'TODO: Move to StatusMessage/ErrorMessage object
                                blnHasImage = False
                            End If
                        End If
                    ElseIf Request.Form("action") = "deletePhoto" Then
                        'TODO: Move to Parameterized Stored Procedure
                        objFirstCommand.CommandText = String.Format("SELECT PhotoFilename FROM photos WHERE ProfileID={0} AND PhotoID={1};", Session("ProfileID"), Request.Form("PhotoID"))
                        objDataReader = objFirstCommand.ExecuteReader()
                        If objDataReader.Read() Then
                            If Not (objDataReader.IsDBNull(0)) Then
                                strFileToDelete = objDataReader("PhotoFilename")
                                objDataReader.Close()
                                objFirstCommand.CommandText = String.Format("DELETE FROM photos WHERE PhotoID={0};", Request.Form("PhotoID"))
                                objFirstCommand.ExecuteNonQuery()
                                litStatusMessage.Text = "You've deleted one of your photos." 'TODO: Move to StatusMessage/ErrorMessage object
                            Else
                                objDataReader.Close()
                            End If
                        Else
                            objDataReader.Close()
                            'TODO: This is actually more of a WARNING not an ERROR
                            litErrorMessage.Text = "NO CHANGES WERE MADE.<br /><br />The photo you tried to delete does not exist." 'TODO: Move to StatusMessage/ErrorMessage object

                        End If
                    End If
                    'Physically delete the image file.
                    If strFileToDelete <> "" Then
                        Dim strDeletePath As String = Server.MapPath(ConfigurationManager.AppSettings("IMAGE_FOLDER_PATH")) & "\"
                        If File.Exists(strDeletePath & strFileToDelete) Then
                            File.Delete(strDeletePath & strFileToDelete)
                        End If
                    End If
                Else
                    objDataReader.Close()
                End If
                'Update a photo caption.
                If Request.Form("action") = "updateCaption" Then
                    Update_Caption(objConnection)
                    'Swap the main photo with one of the extra photos.
                ElseIf Request.Form("action") = "changeMainImage" Then
                    Change_MainPhoto(objConnection)
                End If
                objConnection.Close()
            Else
                litErrorMessage.Text = String.Format("The profile <strong>{0}</strong> is not active or no longer exists.", strUserName) 'TODO: Move to StatusMessage/ErrorMessage object
                'TODO: String.Format the above prior to extracting to object
                objDataReader.Close()
            End If
        End If

        If blnPrintForm Then
            phShowForm.Visible = True
        Else
            phShowForm.Visible = True 'TODO: Set to False
        End If


        If litErrorMessage.Text <> "" Then
            phErrorMessage.Visible = True
        Else
            phErrorMessage.Visible = False
        End If

        If litStatusMessage.Text <> String.Empty Then
            phStatusMessage.Visible = True
        Else
            phStatusMessage.Visible = False
        End If
    End Sub


    Sub RefreshPhotosArray(ByVal aryPhotos As Object, ByVal objConnection As Object)
        Dim RPA_objCommand As New SqlCommand()
        Dim RPA_objDataReader As SqlDataReader
        RPA_objCommand.Connection = objConnection
        If objConnection.State = 0 Then
            objConnection.Open()
        End If
        'TODO: Move to Parameterized Stored Procedure
        RPA_objCommand.CommandText = String.Format("SELECT PhotoID, PhotoFilename, Caption FROM photos WHERE ProfileID={0} ORDER BY PhotoID;", Session("ProfileID"))
        RPA_objDataReader = RPA_objCommand.ExecuteReader()
        Dim intIndex As Byte = 0
        While RPA_objDataReader.Read()
            aryPhotos(intIndex, 0) = RPA_objDataReader("PhotoID")
            aryPhotos(intIndex, 1) = RPA_objDataReader("PhotoFilename")
            If Not (RPA_objDataReader.IsDBNull(2)) Then
                aryPhotos(intIndex, 2) = RPA_objDataReader("Caption")
            Else
                aryPhotos(intIndex, 2) = String.Empty
            End If
            intIndex = intIndex + 1
        End While
        RPA_objDataReader.Close()
    End Sub

    Sub Upload_Click(ByVal source As Object, ByVal e As EventArgs)
        If Not (uploadedFile.PostedFile Is Nothing) And Session("UserName") <> "" Then
            Try
                'I. FILE SYSTEM SECTION.
                Dim objPostedFile = uploadedFile.PostedFile
                Dim strImageSuffix As String = CStr(Year(Now) - 2000) & CStr(Month(Now)) & CStr(Day(Now)) & _
                        CStr(Hour(Now)) & CStr(Minute(Now)) & CStr(Second(Now))
                Dim strNewCaption As String = Request.Form("NewCaption")
                strNewCaption = strNewCaption.Replace("""", "&" & "quot;")
                Dim strContentType As String = objPostedFile.ContentType
                Dim intFileSize As Integer = objPostedFile.ContentLength
                Dim strSavePath As String = Server.MapPath(ConfigurationManager.AppSettings("IMAGE_FOLDER_PATH")) & "\"
                Dim strTempPath As String = Server.MapPath(ConfigurationManager.AppSettings("IMAGE_FOLDER_PATH") & "/temp") & "\"
                If intFileSize > 500000 Then
                    litErrorMessage.Text = "Your photo must be less than 500 KiloBytes." 'TODO: Move to StatusMessage/ErrorMessage object 
                    'TODO: k byte reference should come from config objects
                Else
                    If Not (strContentType = "image/jpeg" Or strContentType = "image/pjpeg" Or strContentType = "image/gif") Then
                        litErrorMessage.Text = "Your photo must be a JPEG or GIF." 'TODO: Move to StatusMessage/ErrorMessage object
                    Else
                        'The photo's filename is a made of the username and a datetime stamp.
                        Dim strNewFileName As String
                        If strContentType = "image/gif" Then
                            strNewFileName = Session("UserName") & "_" & strImageSuffix & ".gif"
                        Else
                            strNewFileName = Session("UserName") & "_" & strImageSuffix & ".jpg"
                        End If
                        'Save a copy in the temp directory to work with
                        objPostedFile.SaveAs(strTempPath & strNewFileName)
                        Dim image As System.Drawing.Image = Nothing
                        Dim bitmap As Bitmap = Nothing
                        Try
                            'Get the source bitmap.
                            image = System.Drawing.Image.FromFile(strTempPath & strNewFileName)
                            'Resize the photo if necessary and save it.
                            Dim intOldWidth As Integer = image.Width
                            Dim intOldHeight As Integer = image.Height
                            If (intOldWidth > 400 Or intOldHeight > 400) Then
                                Dim intNewWidth As Integer = intOldWidth
                                Dim intNewHeight As Integer = intOldHeight
                                If intOldWidth > intOldHeight Then
                                    intNewWidth = 400
                                    intNewHeight = Int((400 / intOldWidth) * intOldHeight)
                                Else
                                    intNewWidth = Int((400 / intOldHeight) * intOldWidth)
                                    intNewHeight = 400
                                End If
                                bitmap = New Bitmap(image, intNewWidth, intNewHeight)
                                bitmap.Save(strSavePath & strNewFileName, image.RawFormat)
                            Else
                                objPostedFile.SaveAs(strSavePath & strNewFileName)
                            End If
                            'II. DATABASE SECTION.
                            Dim objUpdateCommand As New SqlCommand()
                            Dim objDataReader As SqlDataReader
                            objUpdateCommand.Connection = objConnection
                            objConnection.Open()
                            'TODO: Move to Parameterized Stored Procedure
                            objUpdateCommand.CommandText = String.Format("SELECT ImageName FROM Profiles WHERE ProfileID={0};", Session("ProfileID"))
                            objDataReader = objUpdateCommand.ExecuteReader()
                            If objDataReader.Read() Then
                                'Set the uploaded image as the user's main photo.
                                If objDataReader.IsDBNull(0) Then
                                    objDataReader.Close()
                                    objUpdateCommand.CommandText = "UPDATE Profiles SET ImageName=""" & _
                                      strNewFileName & """, ImageCaption=""" & _
                                       Server.HtmlEncode(strNewCaption) & """ WHERE ProfileID=" & _
                                       Session("ProfileID") & " AND ProfileStatusID=2;"
                                    strImageName = strNewFileName
                                    blnHasImage = True
                                    Try
                                        objUpdateCommand.ExecuteNonQuery()
                                        litStatusMessage.Text = "You've added a new photo." 'TODO: Move to StatusMessage/ErrorMessage object
                                    Catch excep As Exception
                                        litErrorMessage.Text = "There was an error in adding your photo.<br /><pre>" & _
                                             excep.ToString & "</pre>" 'TODO: Move to StatusMessage/ErrorMessage object
                                        'TODO: String Format above before extracting
                                    End Try
                                Else
                                    'OR Add the uploaded image to the user's extra photos.
                                    objDataReader.Close()
                                    'TODO: Move to Parameterized Stored Procedure
                                    objUpdateCommand.CommandText = String.Format("SELECT COUNT(*) FROM photos WHERE ProfileID={0};", Session("ProfileID"))
                                    Dim intPhotoCount As Integer = objUpdateCommand.ExecuteScalar()
                                    If intPhotoCount < MAX_EXTRA_PHOTOS Then
                                        objUpdateCommand.CommandText = String.Format("INSERT INTO photos (ProfileID,PhotoFilename,Caption) VALUES ({0},""{1}"",""{2}"");", Session("ProfileID"), strNewFileName, Server.HtmlEncode(strNewCaption))

                                        blnHasImage = True
                                        Try
                                            objUpdateCommand.ExecuteNonQuery()
                                            litStatusMessage.Text = "You've added a new photo." 'TODO: Move to StatusMessage/ErrorMessage object
                                        Catch excep As Exception
                                            litErrorMessage.Text = String.Format("There was an error in adding your photo.<br /><pre>{0}</pre>", excep.ToString) 'TODO: Move to StatusMessage/ErrorMessage object
                                            'TODO: String format above before extraction
                                        End Try
                                    Else
                                        litErrorMessage.Text = String.Format("You can only have up to {0} photos.", CStr(MAX_EXTRA_PHOTOS + 1))
                                        'TODO: Move to StatusMessage/ErrorMessage object
                                        'TODO: String format above prior to extraction to object
                                        'TODO: CStr(MAX_EXTRA_PHOTOS + 1) reference shoudl come from config object
                                        If File.Exists(strSavePath & strNewFileName) Then
                                            File.Delete(strSavePath & strNewFileName)
                                        End If
                                    End If
                                End If
                            End If
                            objConnection.Close()
                            NewCaption.Value = String.Empty
                        Catch excep As Exception
                            litErrorMessage.Text = "There was an error in adding your photo.<br /><pre>" & excep.ToString & "</pre>"
                            'TODO: Move to StatusMessage/ErrorMessage object
                            'TODO: string format above prior to extracting 
                        Finally
                            If Not (image Is Nothing) Then
                                image.Dispose()
                            End If
                            If Not (bitmap Is Nothing) Then
                                bitmap.Dispose()
                            End If
                        End Try
                        'Delete the photo in the temp directory.
                        If File.Exists(strTempPath & strNewFileName) Then
                            File.Delete(strTempPath & strNewFileName)
                        End If
                    End If
                End If
            Catch excep As Exception
                litErrorMessage.Text = "There was an error uploading the file.<br /><pre>" & excep.ToString & "</pre>"
                'TODO: Move to StatusMessage/ErrorMessage object
            End Try
        End If
    End Sub

    'Updates a photo caption.
    Sub Update_Caption(ByVal objConnection As Object)
        Dim strOriginalCaption As String = Request.Form("originalCaption")
        Dim strNewCaption As String = Request.Form("Caption")
        Dim strPhotoID As String = Request.Form("PhotoID")
        If Session("UserName") = "" Then
            litErrorMessage.Text = "Please login to update your photos." 'TODO: Move to StatusMessage/ErrorMessage object
        ElseIf strOriginalCaption = strNewCaption Then
            litErrorMessage.Text = "You didn't make any changes."          'TODO: Move to StatusMessage/ErrorMessage object
        Else
            Dim UC_objCommand As New SqlCommand()
            UC_objCommand.Connection = objConnection
            If objConnection.State = 0 Then
                objConnection.Open()
            End If
            'HtmlEncode double quotes.
            strNewCaption = strNewCaption.Replace("""", "&" & "quot;")
            If strPhotoID = "main" Then
                UC_objCommand.CommandText = "UPDATE Profiles SET ImageCaption=""" & _
                       Server.HtmlEncode(strNewCaption) & _
                       """ WHERE ProfileID=" & Session("ProfileID") & ";"
                strMainImageCaption = strNewCaption
            Else
                UC_objCommand.CommandText = "UPDATE photos SET Caption=""" & _
                       Server.HtmlEncode(strNewCaption) & _
                       """ WHERE ProfileID=" & Session("ProfileID") & _
                       " AND PhotoID=" & strPhotoID & ";"
            End If
            UC_objCommand.ExecuteNonQuery()
            UC_objCommand = Nothing
            litStatusMessage.Text = "Your photo caption has been updated." 'TODO: Move to StatusMessage/ErrorMessage object
        End If
    End Sub

    'Changes one of the user's extra photos to the user's main photo and vice versa.
    Sub Change_MainPhoto(ByVal objConnection As Object)
        Dim strPhotoID As String = Request.Form("PhotoID")
        Dim strNewPhotoFilename As String = Request.Form("PhotoFilename")
        If Session("UserName") = "" Then
            litErrorMessage.Text = "Please login to update your photos." 'TODO: Move to StatusMessage/ErrorMessage object
        Else
            Dim UC_objCommand As New SqlCommand()
            Dim UC_objDataReader As SqlDataReader
            UC_objCommand.Connection = objConnection
            If objConnection.State = 0 Then
                objConnection.Open()
            End If
            'TODO: Move to Parameterized Stored Procedure
            UC_objCommand.CommandText = String.Format("SELECT ImageName, ImageCaption FROM Profiles WHERE ProfileID={0};", Session("ProfileID"))
            UC_objDataReader = UC_objCommand.ExecuteReader()

            If UC_objDataReader.Read() Then
                Dim strOrinigalMainImageName As String = UC_objDataReader("ImageName")
                Dim strOrinigalMainImageCaption As String = UC_objDataReader("ImageCaption")
                UC_objDataReader.Close()
                If strNewPhotoFilename = strOrinigalMainImageName Then
                    litErrorMessage.Text = "NO CHANGES WERE MADE.<br /><br />" & _
                         "Please don't refresh your browser when updating photos." 'TODO: Move to StatusMessage/ErrorMessage object

                Else
                    'Get the new main image info from the photos table.
                    'TODO: Move to Parameterized Stored Procedure
                    UC_objCommand.CommandText = String.Format("SELECT PhotoFilename, Caption FROM photos WHERE ProfileID={0} AND PhotoID={1};", Session("ProfileID"), strPhotoID)
                    UC_objDataReader = UC_objCommand.ExecuteReader()
                    If UC_objDataReader.Read() Then
                        Dim strNewMainImageName As String = UC_objDataReader("PhotoFilename")
                        Dim strNewMainImageCaption As String = UC_objDataReader("Caption")
                        UC_objDataReader.Close()
                        'Update the profiles table first.
                        UC_objCommand.CommandText = "UPDATE Profiles " & _
                              "SET ImageName=""" & strNewMainImageName & _
                              """, ImageCaption=""" & strNewMainImageCaption & _
                              """ WHERE ProfileID=" & Session("ProfileID") & ";"
                        UC_objCommand.ExecuteNonQuery()
                        'Update the photos table.
                        UC_objCommand.CommandText = "UPDATE photos " & _
                              "SET PhotoFilename=""" & strOrinigalMainImageName & _
                              """, Caption=""" & strOrinigalMainImageCaption & _
                              """ WHERE ProfileID=" & Session("ProfileID") & _
                              " AND PhotoID=" & strPhotoID & ";"
                        UC_objCommand.ExecuteNonQuery()
                        'Update the <IMG> tag source and caption of the main image.
                        strImageName = strNewMainImageName
                        strMainImageCaption = strNewMainImageCaption
                        litStatusMessage.Text = "Your main photo has been changed." 'TODO: Move to StatusMessage/ErrorMessage object
                    End If
                End If
                UC_objDataReader = Nothing
            End If
        End If
    End Sub
End Class
