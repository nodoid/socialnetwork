﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Imports Globals

Imports Configuration.ErrorMessages

Partial Class Report
    Inherits System.Web.UI.Page

    Dim strAbuserID As String
    Dim strProfileName As String

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        strAbuserID = Request.QueryString("id")
        If (IsNumeric(strAbuserID) = False) Then
            litErrorMessage.Text = "Please don't mess with the URL." 'TODO: Move to StatusMessage/ErrorMessage object
        ElseIf Session("UserName") = "" Then
            Response.Redirect(String.Format("seeprofile.aspx?reportneedlogin=1&id={0}", strAbuserID))
        ElseIf (strAbuserID = Session("ProfileID")) Then
            litErrorMessage.Text = "You can't report yourself!" 'TODO: Move to StatusMessage/ErrorMessage object
        Else
            Dim intReports As Byte = 0
            Dim intRecords As Byte = 0
            'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
            Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
            Dim objDataReader As SqlDataReader
            Dim objCommand As New SqlCommand
            objCommand.Connection = objConnection
            objConnection.Open()
            If Page.IsPostBack Then
                'See if the profile exists and get the user name and status if it does.
                'TODO: Move to Parameterized Stored Procedure
                objCommand.CommandText = String.Format("SELECT UserName,ProfileStatusID FROM Profiles WHERE ProfileID={0};", strAbuserID)
                objDataReader = objCommand.ExecuteReader()
                If Not (objDataReader.Read()) Then
                    'TODO: More of a WARNING than an ERROR add a WARNING
                    litErrorMessage.Text = ErrorMessages.ERROR_MESSAGE_ACCOUNT_DELETED
                    objDataReader.Close()
                Else
                    strProfileName = objDataReader("UserName")
                    Dim intProfileStatusID As Byte = CByte(objDataReader("ProfileStatusID"))
                    objDataReader.Close()
                    If (intProfileStatusID = 3) Then
                        litErrorMessage.Text = String.Format(ErrorMessages.ERROR_MESSAGE_ACCOUNT_SUSPENDED, strProfileName)
                    ElseIf (intProfileStatusID = 2) Then
                        'Count the number of reports.
                        'TODO: Move to Parameterized Stored Procedure
                        objCommand.CommandText = String.Format("SELECT Count(*) FROM abusereports WHERE AbuserID={0};", strAbuserID)
                        intReports = CByte(objCommand.ExecuteScalar())
                        If intReports >= MAX_REPORTS Then
                            litErrorMessage.Text = String.Format(ErrorMessages.ERROR_MESSAGE_ACCOUNT_SUSPENDED, strProfileName)
                        Else
                            'Check if the reporter has already reported this profile.
                            'TODO: Move to Parameterized Stored Procedure
                            objCommand.CommandText = String.Format("SELECT Count(*) FROM abusereports WHERE AbuserID={0} AND ReporterID={1};", strAbuserID, Session("ProfileID"))
                            intRecords = CByte(objCommand.ExecuteScalar())
                            If intRecords > 0 Then
                                litErrorMessage.Text = String.Format("You already reported <strong>{0}</strong>.", strProfileName) 'TODO: Move to StatusMessage/ErrorMessage object
                            Else
                                Dim strAbuseTypeID As String = Request.Form("AbuseTypeID")
                                Dim strReporterComments As String = Request.Form("ReporterComments")
                                'INSERT the new report into the abusereports table.
                                objCommand.CommandText = "INSERT INTO abusereports (AbuserID,ReporterID,ReporterComments,AbuseTypeID) VALUES(" & strAbuserID & "," & Session("ProfileID") & ",""" & Server.HtmlEncode(strReporterComments) & """," & strAbuseTypeID & ");"
                                objCommand.ExecuteNonQuery()
                                'Suspend the profile.
                                If (intReports + 1) >= MAX_REPORTS Then
                                    objCommand.CommandText = "UPDATE Profiles SET ProfileStatusID=3) WHERE ProfileID=" & strAbuserID & ";"
                                    objCommand.ExecuteNonQuery()
                                End If
                                'MessageCell.CssClass = "fMsgBox"
                                litStatusMessage.Text = "Thanks for taking the time to report abuse of the site." 'TODO: Move to StatusMessage/ErrorMessage object
                            End If
                        End If
                    End If
                End If
            Else
                'Check the status of the profile.
                'TODO: Move to Parameterized Stored Procedure
                objCommand.CommandText = String.Format("SELECT UserName,ProfileStatusID FROM Profiles WHERE ProfileID={0};", strAbuserID)
                objDataReader = objCommand.ExecuteReader()
                If Not (objDataReader.Read()) Then
                    'TODO: This is more of a WARNING see other notes about this.
                    litErrorMessage.Text = "The profile you're trying to report was deleted or doesn't exist." 'TODO: Move to StatusMessage/ErrorMessage object
                    objDataReader.Close()
                Else
                    strProfileName = objDataReader("UserName")
                    Dim intProfileStatusID As Byte = CByte(objDataReader("ProfileStatusID"))
                    objDataReader.Close()
                    If (intProfileStatusID = 1) Then
                        litErrorMessage.Text = "Please don't mess with the URL." 'TODO: Move to StatusMessage/ErrorMessage object
                    ElseIf (intProfileStatusID = 3) Then
                        litErrorMessage.Text = String.Format("<strong>{0}</strong> is suspended already.", strProfileName) 'TODO: Move to StatusMessage/ErrorMessage object
                    ElseIf (intProfileStatusID = 2) Then
                        'Count the number of reports.
                        'TODO: Move to Parameterized Stored Procedure
                        objCommand.CommandText = String.Format("SELECT Count(*) FROM abusereports WHERE AbuserID={0};", strAbuserID)
                        intRecords = CByte(objCommand.ExecuteScalar())
                        If intRecords >= MAX_REPORTS Then
                            litErrorMessage.Text = String.Format("<strong>{0}</strong> is suspended already.", strProfileName) 'TODO: Move to StatusMessage/ErrorMessage object
                        Else
                            objCommand.CommandText = String.Format("SELECT Count(*) FROM abusereports WHERE AbuserID={0} AND ReporterID={1};", strAbuserID, Session("ProfileID"))
                            intRecords = CByte(objCommand.ExecuteScalar())
                            If intRecords > 0 Then
                                'TODO: This is more of a WARNING see other notes.
                                litErrorMessage.Text = String.Format("You already reported <strong>{0}</strong>.", strProfileName) 'TODO: Move to StatusMessage/ErrorMessage object
                            Else
                                AbuserName.Text = strProfileName
                            End If
                        End If
                    End If
                End If
            End If
            objConnection.Close()
        End If

        If litErrorMessage.Text <> "" Then
            phErrorMessage.Visible = True
        Else
            phErrorMessage.Visible = False
        End If

        If litStatusMessage.Text <> "" Then
            phStatusMessage.Visible = True
        Else
            phStatusMessage.Visible = False
        End If
    End Sub
End Class
