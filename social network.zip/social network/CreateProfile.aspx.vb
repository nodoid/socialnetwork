﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
'TODO: Most of these arrays aren't applicable and should come from a WebService 
'- I have the data to do this correctly and will place it into the database ASAP
Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Net.Mail
'Imports System.Configuration
'Imports System.Web.UI
'Imports System.Web.UI.WebControls
'Imports System.Linq 'TODO: Not sure if I want to use LINQ but its worth testing
'Imports System.Text
'Imports System.Web
'Imports System.Web.Security
'Imports System.Web.UI.WebControls.WebParts
'Imports System.Xml.Linq
'Imports Microsoft.VisualBasic
'Imports Microsoft.VisualBasic.Constants
'Imports System.Collections
'Imports System.Web.UI.HtmlControls

Imports Configuration.CompanyInfo
Imports Configuration.ErrorMessages
Imports Configuration.EmailTemplates

'TODO: Remove unused Imports
' purpose: Verifies eligibility of username and e-mail address,
'			adds user to the database, and sends the user
'			an e-mail with a link to activate his/her profile.
'			Also logs any errors in creating profile or sending e-mail.
'
Partial Class CreateProfile
    Inherits System.Web.UI.Page

    Public blnUserNameIsUnique As Boolean = True
    Public blnUserIsNotAbuser As Boolean = True
    Public blnEmailNotUsed As Boolean = True
    Public blnPrintForm As Boolean = True
    Public blnProfileCreated As Boolean = False
    Public strErrorMessage As String

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        'TODO: Use the XML driven Custom Controls from the other project

        'Populate the "Height" drop-down menu.
        Dim intHeight As Byte
        For intHeight = 48 To 95
            Height.Items.Add(New ListItem(ConvertHeight(intHeight), intHeight))
        Next intHeight

        'Populate the "Neighborhoods" drop-down menu.
        Call UseHoodArray()
        Dim intIndex As Byte
        For intIndex = 0 To HoodArray.Length - 1
            NeighborhoodID.Items.Add(New ListItem(HoodArray.GetValue(intIndex), intIndex))
        Next

        'Populate the "Body Type" drop-down menu.
        Call UseBodyArray()
        intIndex = 0
        For intIndex = 1 To BodyArray.Length - 1
            BodyTypeID.Items.Add(New ListItem(BodyArray.GetValue(intIndex), intIndex))
        Next

        'Populate the "Sign" drop-down menu. Added Feb. 14,2005.
        Call UseSignArray()
        intIndex = 0
        For intIndex = 1 To SignArray.Length - 1
            SignID.Items.Add(New ListItem(SignArray.GetValue(intIndex), intIndex))
        Next

        'Populate the "Ethnicity" drop-down menu.
        Call UseEthnicArray()
        intIndex = 0
        For intIndex = 1 To EthnicArray.Length - 1
            EthnicID.Items.Add(New ListItem(EthnicArray.GetValue(intIndex), intIndex))
        Next
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ShowContent()
        ShowMessageBubbles()
    End Sub

    Sub ShowContent()
        If blnPrintForm Then
            mvShowForm.SetActiveView(vwShowForm)
        ElseIf blnProfileCreated Then
            mvShowForm.SetActiveView(vwShowResponse)
        End If
    End Sub
    Sub ShowMessageBubbles()
        If blnUserNameIsUnique = False Or blnEmailNotUsed = False Or blnUserIsNotAbuser = False Then
            mbError.Visible = True
        End If
    End Sub
    Sub CreateProfile()
        mbError.Visible = False
        mbInfo.Visible = False
        mbSuccess.Visible = False
        mbWarning.Visible = False

        'Dim intRecords As Integer
        'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
        Dim strConnection As String = ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString
        Dim objConnection As New SqlConnection(strConnection)

        Dim strQuery As String = String.Empty

        Dim objDataReader As SqlDataReader
        Dim objCommand As New SqlCommand()
        objCommand.CommandType = CommandType.StoredProcedure
        objCommand.Connection = objConnection

        Try
            objConnection.Open()
            objCommand.Parameters.AddWithValue("@UserName", UserName.Text.Trim().ToLower())
            objCommand.CommandText = "spGetProfileIDbyUserName"
            objDataReader = objCommand.ExecuteReader()
            If objDataReader.Read() Then
                blnUserNameIsUnique = False
                mbError.ShowError(String.Format(ErrorMessages.ERROR_MESSAGE_ACCOUNT_EXISTS_NAME, UserName.Text))
            End If
            objDataReader.Close()
            objCommand.Parameters.Clear()

            If blnUserNameIsUnique Then
                objCommand.Parameters.AddWithValue("@Email", Email.Text.ToLower().Trim())
                objCommand.CommandText = "spGetProfileIDbyEmail"
                objDataReader = objCommand.ExecuteReader()
                If objDataReader.Read() Then
                    blnEmailNotUsed = False
                    mbError.ShowError(String.Format(ErrorMessages.ERROR_MESSAGE_ACCOUNT_EXISTS_EMAIL, Email.Text))
                End If
                objDataReader.Close()
                objCommand.Parameters.Clear()

                If blnEmailNotUsed Then
                    objCommand.Parameters.AddWithValue("@Email", Email.Text.Trim().ToLower())
                    objCommand.CommandText = "spGetAbuserbyEmail"
                    objDataReader = objCommand.ExecuteReader()
                    If objDataReader.Read() Then
                        blnUserIsNotAbuser = False
                        mbError.ShowError(String.Format(ErrorMessages.ERROR_MESSAGE_ACCOUNT_EXISTS_ABUSER, Email.Text))
                        'TODO: Revise the abuser list copy above and move to an external file.
                    End If
                    objDataReader.Close()
                    objCommand.Parameters.Clear()
                End If
            End If

            'Continue If the User Name has not been used and the e-mail address is neither used nor in the Abuser table.
            If (blnUserNameIsUnique = True) And (blnUserIsNotAbuser = True) And (blnEmailNotUsed = True) Then
                blnPrintForm = False
                ShowContent()
                'mvShowForm.SetActiveView(vwShowResponse)
                'Dim intField As Integer

                'Create the Activation Code by combining a part of the Session ID and 2 random numbers.
                Dim objRandom As New Random()
                Dim intStart As Integer = objRandom.Next(1, 9)
                Dim intLastTwo As Integer = objRandom.Next(10, 99)
                Dim strCode As String
                strCode = Mid(Session.SessionID, intStart, 14) & CStr(intLastTwo) 'TODO: Make this a GUID instead
                'Dim strCode As String = Guid.NewGuid().ToString() ' Replaces 5 lines above

                'Create the complete INSERT statement and insert the record.
                objCommand.Parameters.AddWithValue("@UserName", UserName.Text.Trim().ToLower())
                objCommand.Parameters.AddWithValue("@Password", Password.Text) 'TODO: Use 128-bitMD5 hash encryption.
                objCommand.Parameters.AddWithValue("@Email", Email.Text.ToLower().Trim())
                objCommand.Parameters.AddWithValue("@GenderID", GenderID.SelectedValue)
                objCommand.Parameters.AddWithValue("@Age", Age.Text)
                objCommand.Parameters.AddWithValue("@SexualOrientationID", SexualOrientationID.SelectedValue)
                objCommand.Parameters.AddWithValue("@SignID", SignID.SelectedValue)
                objCommand.Parameters.AddWithValue("@Height", Height.SelectedValue)
                objCommand.Parameters.AddWithValue("@BodyTypeID", BodyTypeID.SelectedValue)
                objCommand.Parameters.AddWithValue("@EthnicID", EthnicID.SelectedValue)
                objCommand.Parameters.AddWithValue("@NeighborhoodID", NeighborhoodID.SelectedValue)
                objCommand.Parameters.AddWithValue("@AboutMe", AboutMe.Text)
                objCommand.Parameters.AddWithValue("@WantActivityPartner", WantActivityPartner.Checked)
                objCommand.Parameters.AddWithValue("@WantFriend", WantFriend.Checked)
                objCommand.Parameters.AddWithValue("@WantDate", WantDate.Checked)
                objCommand.Parameters.AddWithValue("@WantLTR", WantLTR.Checked)
                objCommand.Parameters.AddWithValue("@ForwardMessages", ForwardMessages.Checked)
                objCommand.Parameters.AddWithValue("@ActivationCode", strCode)

                objCommand.CommandText = "spCreateProfile"
                Try
                    objCommand.ExecuteNonQuery()

                    'Send an e-mail to the user with the activation code.
                    Dim strSubject As String = EmailTemplate.ACTIVATE_ACCOUNT_SUBJECT
                    Dim strBody As String = String.Format(EmailTemplate.ACTIVATE_ACCOUNT_BODY, ConfigurationManager.AppSettings("DOMAIN"), UserName.Text, strCode, Now(), CompanyInfo.COMPANY_NAME, CompanyInfo.COMPANY_ADDRESS, CompanyInfo.COMPANY_CITY, CompanyInfo.COMPANY_STATE, CompanyInfo.COMPANY_ZIP)

                    Dim mail As MailMessage = New MailMessage(ConfigurationManager.AppSettings("PROFILE_EMAIL"), Email.Text.ToLower().Trim().ToString(), strSubject, strBody)
                    mail.Body = strBody
                    mail.IsBodyHtml = True

                    Dim smtp As SmtpClient = New SmtpClient()
                    smtp.Host = ConfigurationManager.AppSettings("SMTP_SERVER")
                    smtp.Credentials = New System.Net.NetworkCredential("test@gmail.com", "!gmail@test#")   'TODO: Setup TEST ACCOUNT
                    smtp.EnableSsl = True

                    Try 'Send an e-mail to the user with the activation code.
                        smtp.Send(mail)
                    Catch excep As Exception 'Log any e-mail error in emailerrors table.
                        objCommand.Parameters.AddWithValue("@FromEmail", ConfigurationManager.AppSettings("PROFILE_EMAIL"))
                        objCommand.Parameters.AddWithValue("@ToEmail", Email.Text.ToLower().Trim().ToString())
                        objCommand.Parameters.AddWithValue("@Subject", Server.HtmlEncode(mail.Subject.ToString()))
                        objCommand.Parameters.AddWithValue("@Body", Server.HtmlEncode(mail.Body.Trim().ToString()))
                        objCommand.Parameters.AddWithValue("@ExceptionError", Server.HtmlEncode(excep.ToString))
                        objCommand.CommandText = "spLogEmailError"
                        objCommand.ExecuteNonQuery()

                        mbError.ShowError(ErrorMessages.ERROR_MESSAGE_ACCOUNT_EMAIL_SEND_ERROR)
                    Finally
                        blnProfileCreated = True
                        'TODO: Move to object StatusMessage.vb 
                        mbSuccess.ShowSuccess(String.Format("Your account has been created. Your activation information has been sent to <strong>{0}</strong>.<br /><br />Please check your e-mail in a few minutes.", Email.Text))
                    End Try

                Catch excep As Exception
                    mbError.ShowError(ErrorMessages.ERROR_MESSAGE_ACCOUNT_CREATE_ERROR)

                    'Log any database error in the databaseerrors table.					
                    objCommand.CommandText = String.Format("INSERT INTO databaseerrors (SqlStatement,Exception,PageName) VALUES(""{0}"",""{1}"",'createprofile.aspx');", Server.HtmlEncode("spCreateProfile"), Server.HtmlEncode(excep.ToString()))
                    objCommand.ExecuteNonQuery()
                End Try
            End If
            objConnection.Close()
        Catch excep As Exception
            mbError.ShowError(String.Format(ErrorMessages.ERROR_MESSAGE_ACCOUNT_CREATE_ERROR2, excep.Message, strQuery))
        End Try
        ShowMessageBubbles()
        ShowContent()
        Session.Abandon() 'Kill Session
    End Sub

    'Used on create/edit/view profile pages.
    Function ConvertHeight(ByVal intHeight As Integer) As String
        Dim intFeet = Fix(intHeight / 12)
        Dim intInches = intHeight Mod 12
        Return CStr(intFeet) & "'" & CStr(intInches) & Chr(34)
    End Function

    'Used on Search results an Favorites page to color-code genders.
    Function ColorGender(ByVal intGenderIndex As Object) As String
        If GenderArray(1) Then
            Call UseGenderArray()
        End If
        If IsDBNull(intGenderIndex) Then
            Return ""
        Else
            intGenderIndex = CByte(intGenderIndex)
            Select Case intGenderIndex
                Case 1
                    Return "<span class=female>female</span>"
                Case 2
                    Return "<span class=male>male</span>"
                Case Else
                    Return String.Format("<span class=transgender>{0}</span>", GenderArray(intGenderIndex))
            End Select
        End If
    End Function

    'Used on Search results an Favorites page to color-code genders.
    Function GetHoodName(ByVal intHoodIndex As Object)
        If IsDBNull(intHoodIndex) Then
            Return ""
        Else
            intHoodIndex = CByte(intHoodIndex)
            Return HoodArray(intHoodIndex)
        End If
    End Function

    Public GenderArray(4) As String
    Public Sub UseGenderArray()
        GenderArray(0) = String.Empty
        GenderArray(1) = "female"
        GenderArray(2) = "male"
        GenderArray(3) = "transgender(f2m)"
        GenderArray(4) = "transgender(m2f)"
    End Sub

    Public OrientationArray(4) As String
    Public Sub UseOrientationArray()
        OrientationArray(0) = String.Empty
        OrientationArray(1) = "straight"
        OrientationArray(2) = "gay/lesbian"
        OrientationArray(3) = "bisexual"
    End Sub

    Public BodyArray(6) As String
    Public Sub UseBodyArray()
        BodyArray(0) = String.Empty
        BodyArray(1) = "average"
        BodyArray(2) = "slim/slender"
        BodyArray(3) = "athletic"
        BodyArray(4) = "thick"
        BodyArray(5) = "a little extra padding"
        BodyArray(6) = "more to love"
    End Sub

    Public HoodArray(37) As String
    Public Sub UseHoodArray()
        HoodArray(0) = "San Francisco"
        HoodArray(1) = "bayview / hunter's point"
        HoodArray(2) = "bernal heights"
        HoodArray(3) = "castro / eureka valley"
        HoodArray(4) = "chinatown"
        HoodArray(5) = "cole valley"
        HoodArray(6) = "excelsior / outer mission"
        HoodArray(7) = "financial district / embarcadero"
        HoodArray(8) = "glen park"
        HoodArray(9) = "haight ashbury"
        HoodArray(10) = "hayes valley"
        HoodArray(11) = "ingleside / merced / ocean view (SFSU,CCSF)"
        HoodArray(12) = "inner richmond"
        HoodArray(13) = "inner sunset / parnassus heights (UCSF)"
        HoodArray(14) = "laurel heights / presidio"
        HoodArray(15) = "lower haight / fillmore"
        HoodArray(16) = "marina / cow hollow"
        HoodArray(17) = "mission district"
        HoodArray(18) = "nob hill"
        HoodArray(19) = "noe valley"
        HoodArray(20) = "north beach / telegraph hill"
        HoodArray(21) = "pacific heights"
        HoodArray(22) = "panhandle (USF)"
        HoodArray(23) = "potrero hill / dogpatch"
        HoodArray(24) = "richmond / seacliff"
        HoodArray(25) = "russian hill"
        HoodArray(26) = "soma / south beach / mission bay"
        HoodArray(27) = "sunset / parkside"
        HoodArray(28) = "tenderloin / civic center"
        HoodArray(29) = "tendernob"
        HoodArray(30) = "twin peaks / diamond heights"
        HoodArray(31) = "visitacion valley / sunnydale / portola"
        HoodArray(32) = "west portal / st. francis wood / forest hill"
        HoodArray(33) = "western addition / japantown"
        HoodArray(34) = "East Bay"
        HoodArray(35) = "North Bay"
        HoodArray(36) = "Peninsula"
        HoodArray(37) = "South Bay"
    End Sub

    Public EthnicArray(10) As String
    Public Sub UseEthnicArray()
        EthnicArray(0) = String.Empty
        EthnicArray(1) = "asian"
        EthnicArray(2) = "black / african"
        EthnicArray(3) = "hispanic / latino"
        EthnicArray(4) = "indian / south asian"
        EthnicArray(5) = "middle eastern / arab"
        EthnicArray(6) = "native american"
        EthnicArray(7) = "pacific islander"
        EthnicArray(8) = "white / caucasian"
        EthnicArray(9) = "mixed"
        EthnicArray(10) = "other"
    End Sub

    Public SignArray(12) As String
    Public Sub UseSignArray()
        SignArray(0) = String.Empty
        SignArray(1) = "aquarius"
        SignArray(2) = "aries"
        SignArray(3) = "cancer"
        SignArray(4) = "capricorn"
        SignArray(5) = "gemini "
        SignArray(6) = "leo"
        SignArray(7) = "libra"
        SignArray(8) = "pisces"
        SignArray(9) = "sagittarius"
        SignArray(10) = "scorpio"
        SignArray(11) = "taurus"
        SignArray(12) = "virgo"
    End Sub

    Protected Sub btnCreateMyProfile_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCreateMyProfile.Click
        CreateProfile()
    End Sub

    Protected Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click

    End Sub
End Class
