﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Partial Class admin_emails
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Session("UserName") <> ConfigurationManager.AppSettings("ADMIN_USERNAME") Then
            'Response.Redirect("/default.aspx") '!!! remove comment
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        Dim objConnection As New SqlConnection(ConfigurationManager.AppSettings("DB_CONNECTION_STRING"))
        Dim objCommand As New SqlCommand()
        Dim objDataReader As SqlDataReader
        objCommand.Connection = objConnection
        objConnection.Open()

        Dim strOutput As New StringBuilder()
        objCommand.CommandText = "SELECT Email FROM Profiles WHERE ProfileStatusID=2" 'TODO: Move to Parameterized Stored Procedure
        objDataReader = objCommand.ExecuteReader()

        If objDataReader.Read() Then
            While objDataReader.Read()
                strOutput.Append(objDataReader("Email") & ", ")
            End While
        Else
            strOutput.Append("No Emails Available.")
        End If
        objDataReader.Close()
        outputLabel.Text = strOutput.ToString()
    End Sub
End Class
