﻿Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Web.Mail

Imports Globals

Partial Class admin_unactivated
    Inherits System.Web.UI.Page

    Dim blnHasRecords As Boolean = False
    Dim MutualFavorite(1) As String
    Dim intRecords As Integer = 0

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Session("UserName") <> ConfigurationManager.AppSettings("ADMIN_USERNAME") Then
            'Response.Redirect("/default.aspx")
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim objConnection As New SqlConnection(ConfigurationManager.AppSettings("DB_CONNECTION_STRING"))
        Dim objCommand As New SqlCommand()
        objCommand.Connection = objConnection
        objConnection.Open()

        'Count the number of unactivated profiles.
        objCommand.CommandText = "SELECT Count(*) FROM Profiles WHERE ProfileStatusID=1;" 'TODO: Move to Parameterized Stored Procedure
        '"TO_DAYS(NOW()) - TO_DAYS(CreationDate) > 7;" 'TODO: Filter displayed records by date range
        intRecords = CInt(objCommand.ExecuteScalar())

        litUnactivatedRecords.Text = intRecords

        If intRecords > 0 Then
            'Handle the sorting.
            Dim strSortColumn As String = Request.QueryString("sortby")
            If strSortColumn <> "" Then
                strSortColumn = " ORDER BY " & strSortColumn
            Else
                strSortColumn = " ORDER BY ProfileID"
            End If

            objCommand.CommandText = String.Format("SELECT ProfileID,UserName,Email,Age,CreationDate FROM Profiles WHERE ProfileStatusID=1 {0};", strSortColumn) 'TODO: Move to Parameterized Stored Procedure
            searchDataList.DataSource = objCommand.ExecuteReader(CommandBehavior.CloseConnection)
            searchDataList.DataBind()
            blnHasRecords = True
            phUnactivatedProfiles.Visible = True
        End If
        objConnection.Close()
    End Sub

    Function LongDate(ByVal dt As DateTime) As String
        dt = dt.AddHours(OFFSET_HOURS)
        Return WeekdayName(Weekday(dt)) & ", " & MonthName(Month(dt)) & " " & Day(dt) & _
         ", " & Year(dt) & " &nbsp;" & TimeValue(dt)
    End Function

    'Used on create/edit/view profile pages.
    'Function ConvertHeight(intHeight As Integer) As String
    'Dim intFeet = Fix(intHeight / 12)
    'Dim intInches = intHeight Mod 12
    '	return CStr(intFeet) & "'" & CStr(intInches) & Chr(34)
    'End Function

    'Used on Search results an Favorites page to color-code genders.
    'Function ColorGender(ByVal intGenderIndex As Object)
    '    If GenderArray(1) = "" Then
    '        Call UseGenderArray()
    '    End If
    '    If IsDBNull(intGenderIndex) Then
    '        Return ""
    '    Else
    '        intGenderIndex = CByte(intGenderIndex)
    '        Select Case intGenderIndex
    '            Case 1
    '                Return "<span class=female>female</span>"
    '            Case 2
    '                Return "<span class=male>male</span>"
    '            Case Else
    '                Return "<span class=transgender>" & GenderArray(intGenderIndex) & "</span>"
    '        End Select
    '    End If
    'End Function

    'Used on Search results an Favorites page to color-code genders.
    'Function GetHoodName(ByVal intHoodIndex As Object)
    '    If IsDBNull(intHoodIndex) Then
    '        Return ""
    '    Else
    '        intHoodIndex = CByte(intHoodIndex)
    '        Return HoodArray(intHoodIndex)
    '    End If
    'End Function

    'Public GenderArray(4) As String
    'Public Sub UseGenderArray()
    '    GenderArray(0) = ""
    '    GenderArray(1) = "female"
    '    GenderArray(2) = "male"
    '    GenderArray(3) = "transgender(f2m)"
    '    GenderArray(4) = "transgender(m2f)"
    'End Sub

    'Public OrientationArray(4) As String
    'Public Sub UseOrientationArray()
    '    OrientationArray(0) = ""
    '    OrientationArray(1) = "straight"
    '    OrientationArray(2) = "gay/lesbian"
    '    OrientationArray(3) = "bisexual"
    'End Sub

    'Public BodyArray(6) As String
    'Public Sub UseBodyArray()
    '    BodyArray(0) = ""
    '    BodyArray(1) = "average"
    '    BodyArray(2) = "slim/slender"
    '    BodyArray(3) = "athletic"
    '    BodyArray(4) = "thick"
    '    BodyArray(5) = "a little extra padding"
    '    BodyArray(6) = "more to love"
    'End Sub

    'Public HoodArray(37) As String
    'Public Sub UseHoodArray()
    '    HoodArray(0) = "San Francisco"
    '    HoodArray(1) = "bayview / hunter's point"
    '    HoodArray(2) = "bernal heights"
    '    HoodArray(3) = "castro / eureka valley"
    '    HoodArray(4) = "chinatown"
    '    HoodArray(5) = "cole valley"
    '    HoodArray(6) = "excelsior / outer mission"
    '    HoodArray(7) = "financial district / embarcadero"
    '    HoodArray(8) = "glen park"
    '    HoodArray(9) = "haight ashbury"
    '    HoodArray(10) = "hayes valley"
    '    HoodArray(11) = "ingleside / merced / ocean view (SFSU,CCSF)"
    '    HoodArray(12) = "inner richmond"
    '    HoodArray(13) = "inner sunset / parnassus heights (UCSF)"
    '    HoodArray(14) = "laurel heights / presidio"
    '    HoodArray(15) = "lower haight / fillmore"
    '    HoodArray(16) = "marina / cow hollow"
    '    HoodArray(17) = "mission district"
    '    HoodArray(18) = "nob hill"
    '    HoodArray(19) = "noe valley"
    '    HoodArray(20) = "north beach / telegraph hill"
    '    HoodArray(21) = "pacific heights"
    '    HoodArray(22) = "panhandle (USF)"
    '    HoodArray(23) = "potrero hill / dogpatch"
    '    HoodArray(24) = "richmond / seacliff"
    '    HoodArray(25) = "russian hill"
    '    HoodArray(26) = "soma / south beach / mission bay"
    '    HoodArray(27) = "sunset / parkside"
    '    HoodArray(28) = "tenderloin / civic center"
    '    HoodArray(29) = "tendernob"
    '    HoodArray(30) = "twin peaks / diamond heights"
    '    HoodArray(31) = "visitacion valley / sunnydale / portola"
    '    HoodArray(32) = "west portal / st. francis wood / forest hill"
    '    HoodArray(33) = "western addition / japantown"
    '    HoodArray(34) = "East Bay"
    '    HoodArray(35) = "North Bay"
    '    HoodArray(36) = "Peninsula"
    '    HoodArray(37) = "South Bay"
    'End Sub

    'Public EthnicArray(10) As String
    'Public Sub UseEthnicArray()
    '    EthnicArray(0) = ""
    '    EthnicArray(1) = "asian"
    '    EthnicArray(2) = "black / african"
    '    EthnicArray(3) = "hispanic / latino"
    '    EthnicArray(4) = "indian / south asian"
    '    EthnicArray(5) = "middle eastern / arab"
    '    EthnicArray(6) = "native american"
    '    EthnicArray(7) = "pacific islander"
    '    EthnicArray(8) = "white / caucasian"
    '    EthnicArray(9) = "mixed"
    '    EthnicArray(10) = "other"
    'End Sub

    'Public SignArray(12) As String
    'Public Sub UseSignArray()
    '    SignArray(0) = ""
    '    SignArray(1) = "aquarius"
    '    SignArray(2) = "aries"
    '    SignArray(3) = "cancer"
    '    SignArray(4) = "capricorn"
    '    SignArray(5) = "gemini "
    '    SignArray(6) = "leo"
    '    SignArray(7) = "libra"
    '    SignArray(8) = "pisces"
    '    SignArray(9) = "sagittarius"
    '    SignArray(10) = "scorpio"
    '    SignArray(11) = "taurus"
    '    SignArray(12) = "virgo"
    'End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        Dim objConnection As New SqlConnection(ConfigurationManager.AppSettings("DB_CONNECTION_STRING"))
        Dim objCommand As New SqlCommand()
        objCommand.Connection = objConnection
        objConnection.Open()

        Dim strFormID As String = Request.Form("ID")
        Dim strAction As String = ActionToPerform.SelectedValue 'Request.Form("ActionToPerform")

        If strFormID <> "" Then
            If strAction = "delete" Then
                Dim strDelete As New StringBuilder()
                'DELETE the actual profiles.
                strDelete.Append("DELETE FROM Profiles WHERE ProfileID=")
                If strFormID.IndexOf(",") = -1 Then
                    strDelete.Append(strFormID)
                Else
                    Dim arrayIDs() As String = strFormID.Split(",")
                    strDelete.Append(arrayIDs(0))
                    Dim intIndex As Integer
                    For intIndex = 1 To arrayIDs.Length - 1
                        strDelete.Append(" OR ProfileID=" & arrayIDs(intIndex))
                    Next
                End If
                'DELETE the records from the profiles table.
                objCommand.CommandText = strDelete.ToString() & ";"
                objCommand.ExecuteNonQuery()
            ElseIf strAction = "resend" Then
                Dim arrayIDs() As String = strFormID.Split(",")
                Dim objDataReader As SqlDataReader
                Dim strUserName, strEmail As String
                Dim strActivationCode As String
                Dim intIndex As Integer
                Dim strLogFilePath As String = Server.MapPath("./")
                Dim objStreamWriter As StreamWriter
                Dim objectFileInfo As FileInfo = New FileInfo(strLogFilePath & "/sent_email.txt")
                If objectFileInfo.Exists = False Then
                    'Create the log file to write to.
                    objStreamWriter = objectFileInfo.CreateText()
                    objStreamWriter.WriteLine("LOG OF RESENT ACTIVATION E-MAILS")
                    objStreamWriter.Flush()
                    objStreamWriter.Close()
                End If

                ' Append to the log file.
                objStreamWriter = objectFileInfo.AppendText()
                For intIndex = 0 To arrayIDs.Length - 1
                    'TODO: Move to Parameterized Stored Procedure
                    objCommand.CommandText = String.Format("SELECT UserName,Email,ActivationCode FROM Profiles WHERE ProfileID={0};", arrayIDs(intIndex))
                    objDataReader = objCommand.ExecuteReader()
                    If objDataReader.Read() Then
                        strUserName = objDataReader.Item("UserName")
                        strEmail = objDataReader.Item("Email")
                        strActivationCode = objDataReader.Item("ActivationCode")

                        'Send an e-mail to the user with the activation code.
                        Dim objMail As New MailMessage
                        objMail.From = ConfigurationManager.AppSettings("PROFILE_EMAIL")
                        objMail.To = strEmail
                        objMail.Subject = "Social Conveyors: Your new profile needs to be activated"
                        Dim strBody = String.Format("Dear {0},<br>Thanks for creating a profile at Social Conveyors.  Please click on the link below to activate your profile.<br>http://www.SocialConveyors.com/activateprofile.aspx?username={1}&activationcode={2}<br>user name: {3}<br>activation code: {4}<br>- Social Conveyors", strUserName, strUserName, strActivationCode, strUserName, strActivationCode)
                        objMail.Body = strBody
                        SmtpMail.SmtpServer = ConfigurationManager.AppSettings("SMTP_SERVER")
                        Try
                            SmtpMail.Send(objMail)
                            'Make the log file neater with uniform spacing.
                            Dim strTab As String = String.Empty
                            If strUserName.Length < 12 Then
                                strTab = vbTab
                            End If
                            objStreamWriter.WriteLine(Now() & vbTab & arrayIDs(intIndex) & " " & strUserName & vbTab & strTab & strEmail)
                        Catch excep As Exception
                            If Not (objDataReader.IsClosed()) Then
                                objDataReader.Close()
                            End If
                            'Log any mail errors in the database.
                            objCommand.CommandText = String.Format("INSERT INTO emailerrors (FromEmail,ToEmail,Subject,Body,ExceptionError) VALUES ('{0}','{1}','{2}','{3}','{4}');", objMail.From, objMail.To, objMail.Subject, objMail.Body, Server.HtmlEncode(excep.ToString))
                            objCommand.ExecuteNonQuery()
                            MessageCell.Text = String.Format("There was an error with SmtpMail:<br /><br /><pre>{0}</pre>", excep.ToString()) 'TODO: Move to StatusMessage/ErrorMessage object
                            phMessageCell.Visible = True
                        End Try
                    End If
                    If Not (objDataReader.IsClosed()) Then
                        objDataReader.Close()
                    End If
                Next
                objStreamWriter.Flush()
                objStreamWriter.Close()
            End If
        End If
        objConnection.Close()
    End Sub
End Class
