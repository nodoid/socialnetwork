﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Partial Class admin_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Session("UserName") <> ConfigurationManager.AppSettings("ADMIN_USERNAME") Then
            'Response.Redirect("/default.aspx") 'TODO: Make sure to uncomment !!!
        End If
        serverTime.Text = Now()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
        Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
        Dim objCommand As New sqlCommand()
        objCommand.Connection = objConnection
        objConnection.Open()
        objCommand.CommandText = "SELECT COUNT(*) FROM databaseerrors" 'TODO: Move to Parameterized Stored Procedure
        cellDatabaseerrors.Text = objCommand.ExecuteScalar()
        objCommand.CommandText = "SELECT COUNT(*) FROM emailerrors" 'TODO: Move to Parameterized Stored Procedure
        cellEmailerrors.Text = objCommand.ExecuteScalar()
        objCommand.CommandText = "SELECT COUNT(*) FROM Profiles where ProfileStatusID=1" 'TODO: Move to Parameterized Stored Procedure
        cellUnactivated.Text = objCommand.ExecuteScalar()
    End Sub
End Class
