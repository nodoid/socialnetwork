﻿Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Partial Class admin_tables
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Session("UserName") <> ConfigurationManager.AppSettings("ADMIN_USERNAME") Then
            'Response.Redirect("/default.aspx")
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
           
        End If
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        Dim objConnection As New SqlConnection(ConfigurationManager.AppSettings("DB_CONNECTION_STRING"))
        Dim objCommand As New SqlCommand()
        Dim objDataReader As SqlDataReader
        objCommand.Connection = objConnection
        objConnection.Open()

        Dim aryTables(6, 2) As String
        aryTables(0, 0) = "abusetypes"
        aryTables(0, 1) = "AbuseTypeID"
        aryTables(0, 2) = "AbuseTypeName"
        aryTables(1, 0) = "bodytypes"
        aryTables(1, 1) = "BodyTypeID"
        aryTables(1, 2) = "BodyTypeName"
        aryTables(2, 0) = "genders"
        aryTables(2, 1) = "GenderID"
        aryTables(2, 2) = "GenderName"
        aryTables(3, 0) = "neighborhoods"
        aryTables(3, 1) = "NeighborhoodID"
        aryTables(3, 2) = "NeighborhoodName"
        aryTables(4, 0) = "profilestatuses"
        aryTables(4, 1) = "ProfileStatusID"
        aryTables(4, 2) = "ProfileStatusName"
        aryTables(5, 0) = "sexualorientations"
        aryTables(5, 1) = "SexualOrientationID"
        aryTables(5, 2) = "SexualOrientationName"
        aryTables(6, 0) = "ethnicities"
        aryTables(6, 1) = "EthnicID"
        aryTables(6, 2) = "EthnicName"

        Dim i As Byte = 0
        Dim strOutput As New StringBuilder()
        For i = 0 To 6
            objCommand.CommandText = String.Format("SELECT {0} FROM {1} ORDER BY {2};", aryTables(i, 2), aryTables(i, 0), aryTables(i, 1)) 'TODO: Move to Parameterized Stored Procedure
            objDataReader = objCommand.ExecuteReader()
            While objDataReader.Read()
                If aryTables(i, 2).IndexOf(",") = -1 Then
                    strOutput.Append("INSERT INTO " & aryTables(i, 0) & " (" & aryTables(i, 2) & ") VALUES(""" & objDataReader(0) & """);" & vbCrLf)
                Else
                    strOutput.Append("INSERT INTO " & aryTables(i, 0) & " (" & aryTables(i, 2) & ") VALUES(")
                    Dim aryFields() As String = aryTables(i, 2).Split(",")
                    Dim strField As String
                    Dim blnNotFirst As Boolean = False
                    For Each strField In aryFields
                        If blnNotFirst Then
                            strOutput.Append(",")
                        End If
                        If strField.IndexOf("ID") = -1 Then
                            strOutput.Append("""" & objDataReader(strField) & """")
                        Else
                            strOutput.Append(objDataReader(strField))
                        End If
                        blnNotFirst = True
                    Next strField
                    strOutput.Append(");" & vbCrLf)
                End If
            End While
            objDataReader.Close()
            strOutput.Append(vbCrLf)
        Next
        outputLabel.Text = strOutput.ToString()
    End Sub
End Class
