﻿Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Partial Class admin_server
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Session("UserName") <> ConfigurationManager.AppSettings("ADMIN_USERNAME") Then
            'Response.Redirect("/default.aspx") '!!!
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim RequestArray As String 'TODO: Check to see if this is actually used someplace
        Dim oProp As String
        Dim sTable As String = "<table cellspacing=0>"

        For Each oProp In Request.ServerVariables
            sTable = sTable & "<tr><td class=""fData"">" & oProp & _
             "</td><td class=""fData"">" & Request.ServerVariables(oProp) & "</td></tr>"
        Next
        requestTable.Text = sTable & "</table>"
    End Sub
End Class
