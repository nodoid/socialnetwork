﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object

Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Mail

Imports Configuration.ErrorMessages

Partial Class controls_Login
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Not IsPostBack Then
            SetState()
        End If
    End Sub

    Sub SetState()
        'If Session("UserName") <> "" Then
        If Session("UserName") = String.Empty Then
            mvLoginStatus.SetActiveView(vwLoggedOut)
        Else
            hlMyProfile.NavigateUrl = "~/seeprofile.aspx?username=" & Session("UserName") & "&id=" & Session("ProfileID")
            litUserName.Text = Session("UserName")
            mvLoginStatus.SetActiveView(vwLoggedIn)
        End If

        'TODO: Make Admin Role Based instead of String Based
        If Session("UserName") = ConfigurationManager.AppSettings("ADMIN_USERNAME") Then
            litAdminLink.Text = "&nbsp;&nbsp;&nbsp;<a href=/admin>Admin</a>"
        End If
    End Sub

    Protected Sub btnLogOut_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogOut.Click
        Session("UserName") = String.Empty
        Session.Abandon()
        Response.Redirect("~/default.aspx")
    End Sub

    Protected Sub btnLogIn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogIn.Click
        Dim strUserName As String = txtUserName.Text 'Request.Form("username")
        Dim strPassword As String = txtPassword.Text 'Request.Form("password")
        Dim strRegex As String = "^[a-z0-9A-Z_]{4,16}$"        'TODO: Add to a RegEx manager Object should be stored in ResX
        'Check if username or password is invalid.
        If Not (Regex.IsMatch(strUserName, strRegex)) Or Not (Regex.IsMatch(strPassword, strRegex)) Then
            litErrorMessage.Text = ErrorMessages.ERROR_MESSAGE_LOGIN_INVALID_1
        Else
            Dim intProfileID As Integer
            Dim intProfileStatusID As Byte
            'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
            Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
            Dim objDataReader As SqlDataReader
            'TODO: MD5 hash the password
            'TODO: Move Query to Stored Parameterized Procedure
            Dim strSQL As String = String.Format("SELECT ProfileID,UserName, ProfileStatusID FROM Profiles WHERE UserName='{0}' AND Password='{1}';", strUserName, strPassword) 'TODO: Move to Parameterized Stored Procedure
            Dim objCommand As New SqlCommand(strSQL, objConnection)
            Try
                objConnection.Open()
                objDataReader = objCommand.ExecuteReader()
                If objDataReader.Read() Then
                    intProfileID = objDataReader("ProfileID")
                    strUserName = objDataReader("UserName")
                    intProfileStatusID = CByte(objDataReader("ProfileStatusID"))
                Else
                    litErrorMessage.Text = ErrorMessages.ERROR_MESSAGE_LOGIN_INVALID_2
                End If
                objDataReader.Close()
                Select Case intProfileStatusID
                    Case 1
                        'TODO: Should be a Warning Dialog isnt really an Error
                        litErrorMessage.Text = ErrorMessages.ERROR_MESSAGE_LOGIN_INACTIVE
                    Case 2
                        Session("ProfileID") = intProfileID
                        Session("UserName") = strUserName
                        Session("MessageFolder") = String.Empty
                        objCommand.CommandText = "spUpdateLoginDatebyProfileID"
                        objCommand.Parameters.AddWithValue("@ProfileID", intProfileID)
                        objCommand.ExecuteNonQuery()
                        SetState()
                    Case 3
                        litErrorMessage.Text = ErrorMessages.ERROR_MESSAGE_LOGIN_SUSPENDED
                End Select
                objConnection.Close()
            Catch excep As Exception
                'TODO: Should be a Warning Dialog isnt really a user Error
                litErrorMessage.Text = String.Format(ErrorMessages.ERROR_MESSAGE_DB, excep.Message)
            End Try
        End If

        If litErrorMessage.Text <> "" Then
            phErrorMessage.Visible = True
        Else
            phErrorMessage.Visible = False
        End If

        If litStatusMessage.Text <> "" Then
            phStatusMessage.Visible = True
        Else
            phStatusMessage.Visible = False
        End If
    End Sub
End Class
