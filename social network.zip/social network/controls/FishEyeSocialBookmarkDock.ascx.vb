﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object

Partial Class controls_FishEyeSocialBookmarkDock
    Inherits UserControl

    Public IconScript As String = String.Empty

    Sub AddBookmark(ByVal urlProviderFormat As String, ByVal providerName As String, ByVal openNewWindow As Boolean)
        Dim SmallImageSize As String = "32" 'Accepted Values: 16, 24, 32, 48, 60 (ignored if DisplayType is blank)
        Dim LargeImageSize As String = "48"

        Dim Markup As Literal = New Literal
        Markup.Text += String.Format("<a id=""{0}"" title=""{1}""><img alt=""/images/{2}_{3}.png"" src=""/images/{4}_{5}.png"" /></a>" & vbCrLf, providerName.ToLower(), providerName, providerName.ToLower(), LargeImageSize, providerName.ToLower(), SmallImageSize)

        Dim ScriptLink = Server.HtmlEncode(String.Format(urlProviderFormat, PageUrl, PageTitle))
        IconScript += String.Format(vbTab & "$('#{0}').attr('href','{1}');" & vbCrLf, providerName.ToLower(), ScriptLink)
        If openNewWindow Then IconScript += String.Format(vbTab & "$('#{0}').attr('target','_blank');" & vbCrLf, providerName.ToLower())

        IconPlaceHolder.Controls.Add(Markup)
    End Sub

    Sub AddJavaScript()
        Dim ScriptTag As New HtmlControls.HtmlGenericControl("script")
        ScriptTag.Attributes.Add("type", "text/javascript")

        Dim JavaScript As Literal = New Literal()
        JavaScript.Text += vbCrLf & "$(function(){"
        JavaScript.Text += vbTab & "$('#fisheye').jqDock({ align: 'middle', size: 32, duration: 300 });"
        JavaScript.Text += "});" & vbCrLf
        JavaScript.Text += vbTab & "$('#fisheye a img').attr('class','icon');" & vbCrLf

        JavaScript.Text += IconScript

        ScriptTag.Controls.Add(JavaScript)
        ScriptPlaceHolder.Controls.Add(ScriptTag)
    End Sub

    Sub AddBookmarks()
        AddBookmark("http://digg.com/submit?phase=2&url={0}&title={1}", "Digg", True)
        AddBookmark("http://del.icio.us/post?v=4&noui&jump=close&url={0}&title={1}", "del.icio.us", True)
        AddBookmark("http://www.furl.net/storeIt.jsp?u={0}&t={1}", "FURL", True)
        AddBookmark("http://reddit.com/submit?url={0}&title={1}", "Reddit", True)
        'AddBookmark("http://myweb.yahoo.com/myresults/bookmarklet?t={1}&u={0}&ei=UTF", "Yahoo", True)
        AddBookmark("http://www.blinklist.com/index.php?Action=Blink/addblink.php&Quick=true&Url={0}&Title={1}&Pop=yes", "Blinklist", True)
        AddBookmark("http://www.google.com/bookmarks/mark?op=edit&output=popup&bkmk={0}&title={1}", "Google", True)
        AddBookmark("http://www.stumbleupon.com/refer.php?url={0}&title={1}", "Stumbleupon", True)
        AddBookmark("http://technorati.com/faves?add={0}", "Technorati", True)
        AddBookmark("http://www.facebook.com/sharer.php?u={0}&title={1}", "Facebook", True)
        AddBookmark("http://www.newsvine.com/_tools/seed&save?u={0}&h={1}", "Newsvine", True)
        '----------
        AddBookmark("http://dzone.com/links/add.html?url={0}&title={1}", "Dzone", True)
        AddBookmark("http://diigo.com/post?url={0}&amp;title={1}", "Diigo", True)
        AddBookmark("http://www.myspace.com/Modules/PostTo/Pages/?u={0}&t={1}", "MySpace", True)
        AddBookmark("http://sphinn.com/submit.php?url={0}&title={1}", "Sphinn", True)
        AddBookmark("http://www.mixx.com/submit?page_url={0}&title={1}", "Mixx", True)
        AddBookmark("http://twitthis.com/twit?url={0}&title={1}", "Twitter", True)

        'AddBookmark("http://www.dotnetkicks.com/submit?url={0}&title={1}", "DotNetKicks")
        'AddBookmark("http://ma.gnolia.com/bookmarklet/add? url={0}&title={1}", "ma.gnolia", True)
        'AddBookmark("http://myweb2.search.yahoo.com/myresults/bookmarklet?u={0}&t={1}", "Yahoo", True)
        'AddBookmark("http://www.shadows.com/features/tcr.htm?url={0}&title={1}", "Shadows", True)
        'AddBookmark("http://blogmarks.net/my/new.php?title={1}&url={0}", "", True)
        AddBookmark("http://www.mister-wong.de/index.php?action=addurl&bm_url={0}&bm_description={1}", "MisterWong", True)
        'AddBookmark("http://www.spurl.net/spurl.php?url={0}&title={1}", "Spurl", True)
        'AddBookmark("http://www.squidoo.com/lensmaster/bookmark?{0}", "Squidoo", True)
        'AddBookmark("http://scuttle.org/bookmarks.php/pass?action=add&address={0}&title={1}", "Scuttle", True)
        'AddBookmark("http://feedmelinks.com/categorize?from=toolbar&op=submit&name={1}&url={0}", "Feedme", True)
        'AddBookmark("http://yigg.de/newpost.php?exturl={0}", "Yigg", True)
        'AddBookmark("http://co.mments.com/track?url={0}", "", True)
        'AddBookmark("http://www.netvouz.com/action/submitBookmark?url={0}&title={1}&popup=no", "", True)
        'AddBookmark("http://blinkbits.com/bookmarklets/save.php?v=1&source_url={0}&title={1}&Pop=no", "", True)
        'AddBookmark("http://ekstreme.com/socializer/?url={0}&title={1}", "", True)
        'AddBookmark("http://www.rojo.com/submit/?title={1}&url={0}", "rojo", True)
    End Sub


    Public Property PageUrl() As String
        Get
            If String.IsNullOrEmpty(ViewState("PageUrl")) Then ViewState("PageUrl") = Request.Url.ToString()
            Return ViewState("PageUrl")
        End Get
        Set(ByVal value As String)
            ViewState("PageUrl") = value
        End Set
    End Property

    Public Property PageTitle() As String
        Get
            'Return If(ViewState("PageTitle"), Page.Title)

            If String.IsNullOrEmpty(ViewState("PageTitle")) Then ViewState("PageTitle") = Page.Title
            Return ViewState("PageTitle")
        End Get
        Set(ByVal value As String)
            ViewState("PageTitle") = value
        End Set
    End Property

    Public Property OpenNewWindow() As Boolean
        Get
            'Return If(ViewState("OpenNewWindow"), False)

            If String.IsNullOrEmpty(ViewState("OpenNewWindow")) Then ViewState("OpenNewWindow") = False
            Return ViewState("OpenNewWindow")
        End Get
        Set(ByVal value As Boolean)
            ViewState("OpenNewWindow") = value
        End Set
    End Property

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Not Page.IsPostBack Then
            AddBookmarks()
            AddJavaScript()
        End If
    End Sub

    'Public Property LinkTitlePrefix() As String
    '   Get
    'Return If(ViewState("LinkTitlePrefix"), "Add to")
    '
    '        If String.IsNullOrEmpty(ViewState("LinkTitlePrefix")) Then ViewState("LinkTitlePrefix") = "Add to"
    '        Return ViewState("LinkTitlePrefix")
    '    End Get
    '    Set(ByVal value As String)
    '        ViewState("LinkTitlePrefix") = value
    '    End Set
    'End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

    End Sub
End Class
