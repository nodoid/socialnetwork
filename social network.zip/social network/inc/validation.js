/* GENERIC FORM FUNCTIONS 
*/
// Array of all errors from validation.
var aErrors = new Array();
// Gets the value of the selected radio button.
function getRadioValue(oRadio){
	for(var i = 0; i < oRadio.length; i++){
		if(oRadio[i].checked){
			return oRadio[i].value;
			break;
		}
	}
	return "";
}
/*  purpose: Toggles the colour of a DHTML object between red and black.
	input: id = string value of the "id" attribute of the HTML element.
		   bError = boolean for switching between red and black.
*/
function showError(id, bError){
	if(isIE || isMozilla){
		if((isIE && document.all[id]) || (isMozilla && document.getElementById(id))){
			var objectDHTML;
			if(isIE){
				objectDHTML = document.all[id];
			}else if(isMozilla){
				objectDHTML = document.getElementById(id);
			}
			if(bError){
				objectDHTML.style.color = "#dd0000";
				aErrors[aErrors.length] = id;
			}else{
				objectDHTML.style.color = "#000000"
			}
		}
	}
}

// Resets the form fields and removes the errors.
function resetForm(form){
	if(confirm("Are you sure you want to reset the values of this form?")){
		form.reset();
		for(var i = 0; i < aErrors.length; i++){
			showError(aErrors[i],false);
		}
		aErrors.length = 0;
	}
}

//takes spaces out.
function trim(s){
	return String(s).replace(/^\s+|\s+$/g,"");
}