/* BROWSER DETECTION SCRIPT
   name: browsers_and_layers.js
   contents: browser detection variables as well as 
   generic functions for layers.
*/
var isIE = false;
var isMozilla = false;
var layerRef = new String();
var styleRef = new String();
var sVisible = new String();
var sInvisible = new String();

// Only newer versions of Internet Exlorer are supported.
if((navigator.appName == "Microsoft Internet Explorer") && (parseInt(navigator.appVersion) >= 4)){
	isIE = true;
	layerRef = ".all";
	styleRef = ".style";
	sVisible = "visible";
	sInvisible = "hidden";
// Only newer versions of Mozilla browsers are supported.
}else if((navigator.appName == "Netscape") && (parseInt(navigator.appVersion) >= 5)){
	isMozilla = true;
	layerRef = ".layers";
	styleRef = "";
	sVisible = "show";
	sInvisible = "hide";
}
// Makes a DHTML object visible.
function show(sID){
	eval("document" + layerRef + "['" + sID + "']" + styleRef + ".visibility = '" +
		sVisible + "'");
}
// Hides a DHTML object.
function hide(sID){
	if (eval("document" + layerRef + "['" + sID + "']")){
		eval("document" + layerRef + "['" + sID + "']" + styleRef + ".visibility = '" +
		sInvisible + "'");
	}
}