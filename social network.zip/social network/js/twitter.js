﻿//TWITTER SCRIPT FUNCTIONS BELOW
setInterval("getSearch()", 15000);
getSearch();

TwitterCache = {};

function getSearch() {
    var url = "http://search.twitter.com/search.json?q=celebrity&callback=?";
    $.getJSON
            (
                url,
                function(data) {
                    if (data.results) {
                        var i = -1, result, HTML = '', HTML2 = '';
                        while ((result = data.results[++i]) && !TwitterCache[result.id]) {
                            TwitterCache[result.id] = result.from_user;
                            HTML += '<li id="TwitterId' + result.id + '"><a href="http://www.twitter.com/' + result.from_user + '" target="_blank" title="Go to profile"><img src="' + result['profile_image_url'] + '" alt="Profile Image" /></a> <a href="http://www.twitter.com/' + result.from_user + '" title="Go to profile"><strong class="User">' + result.from_user + '</strong></a>' + FormatIt(result.text) + ' <br /><span class="created_at">' + relative_time(result.created_at) + ' via ' + linkup(result.source) + '</span></li>';
                        }
                        if (HTML !== '') {
                            $("#tweets ul").prepend(HTML).find('li:hidden').slideToggle('slow');
                            
                        }
                        $("#twitter UL li:gt(14)").remove();

                        $("#twitter UL li:even").css({ "background": "#fff" });
                        $("#twitter UL li:odd").css({ "background": "#f3f3f3" });
                        $("#twitter UL li").hover(
                          function() {
                              $(this).addClass("hover");
                              $(this).animate({ opacity: 1.0 }, 1);
                          },
                          function() {
                              $(this).removeClass("hover");
                              $(this).animate({ opacity: 1.0 }, 1);
                          }
                        ); // STYLING ENDS
                    }
                }
            )
            }

function FormatIt(text_results) 
{
    text_results = text_results.replace(/(gissisim)/ig, '<strong class="twitter">$1</strong>');
    return text_results.linkify();
}

function linkup(link) 
{
    link = link.replace('&lt;a href=&quot;', '<a href="');
    link = link.replace('&quot;&gt;', '">');
    link = link.replace('&lt;/a&gt;', '</a>');
    return link;
}

String.prototype.linkify = function() {  
    return this.replace(/[A-Za-z]+:\/\/[A-Za-z0-9-_]+\.[A-Za-z0-9-_:%&\?\/~.=]+/, function(m) {
        return m.link(m);
    });
};

function relative_time(time_value) { 
    var values = time_value.split(" ");
    time_value = values[2] + " " + values[1] + ", " + values[3] + " " + values[4];
    var parsed_date = Date.parse(time_value);
    var relative_to = (arguments.length > 1) ? arguments[1] : new Date();
    var delta = parseInt((relative_to.getTime() - parsed_date) / 1000);
    delta = delta + (relative_to.getTimezoneOffset() * 60);

    var r = '';
    if (delta < 60) {
        r = 'a minute ago';
    } else if (delta < 120) {
        r = 'couple of minutes ago';
    } else if (delta < (45 * 60)) {
        r = (parseInt(delta / 60)).toString() + ' minutes ago';
    } else if (delta < (90 * 60)) {
        r = 'an hour ago';
    } else if (delta < (24 * 60 * 60)) {
        r = '' + (parseInt(delta / 3600)).toString() + ' hours ago';
    } else if (delta < (48 * 60 * 60)) {
        r = '1 day ago';
    } else {
        r = (parseInt(delta / 86400)).toString() + ' days ago';
    }

    return r;
}
function twitter_callback() {
    return true;
}
