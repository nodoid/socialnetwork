﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Mail
'Imports EmailMessage 'TODO: Make Emailer Object
Imports Favorite

Imports Globals

Imports Configuration.ErrorMessages

Partial Class SeeProfile : Inherits System.Web.UI.Page

    Public blnHasImage As Boolean = False
    Dim blnPrintNavigator As Boolean = True
    Public blnSameAsUser As Boolean = False
    Public blnSentFolderFull As Boolean = False
    Dim blnUsedMessageLogin As Boolean = False
    Dim intFavoriteRecordIndex As Integer = 0
    Dim intRecordIndex As Integer = 0
    Public strAddFavoriteLink As String
    Public strLoginAction As String
    Dim strProfileError As String
    Public strProfileID As String
    Public strProfileNavigator As New StringBuilder()
    Public strProfileName As String
    Public strProfileUpdated As String
    Public strReportLink As String
    Public strViewPhotosHref As String = ""
    Public strViewPhotosLink As String = ""

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        strProfileID = Request.QueryString("id")
        strProfileUpdated = Request.QueryString("updated")
        strLoginAction = "seeprofile.aspx?" & Replace(Request.QueryString.ToString, "&", "&amp;") & "#message"
        If IsNumeric(Request.QueryString("index")) Then
            intRecordIndex = CInt(Request.QueryString("index"))
        ElseIf IsNumeric(Request.QueryString("findex")) Then
            intFavoriteRecordIndex = CInt(Request.QueryString("findex"))
        End If
        'If (Request.Form("messageLogin") = "yes" And LOGIN_strErrorMessage <> "") Then
        'blnUsedMessageLogin = True
        'litErrorMessage.Text = LOGIN_strErrorMessage
        'messageLoginError.CssClass = "errorBox"
        'End If
        If (strProfileID = Session("ProfileID")) Then
            blnSameAsUser = True
        End If
        If (IsNumeric(strProfileID) = False) Then
            strProfileError = "This page requires a Profile ID number."
        Else
            If Page.IsPostBack Then
                'PostBack is only used for sending messages.
                'TODO: This code is broken GET IT WORKING AGAIN
                Dim strSenderID As String = Request.Form("SenderID")
                If strSenderID = Session("ProfileID") Then
                    Dim strSubject As String = Request.Form("Subject")
                    Dim strBody As String = Request.Form("Body")
                    If (Trim(strSubject) <> "" And Trim(strBody) <> "") Then
                        Dim objMessage As New EmailMessage 'TODO: Reference EmailMessage & EmailTemplate || Move code 
                        objMessage.SenderID = Session("ProfileID")
                        objMessage.SenderName = Session("UserName")
                        objMessage.RecipientID = Request.Form("RecipientID")
                        objMessage.Subject = Request.Form("Subject")
                        objMessage.Body = Request.Form("Body")
                        objMessage.Send()
                        If objMessage.ErrorMessage = "" Then
                            'MessageCell.CssClass = "msgSent"
                            litStatusMessage.Text = "Your message has been sent." 'TODO: Move to StatusMessage/ErrorMessage object
                        Else
                            'MessageCell.CssClass = "errorBox"
                            litErrorMessage.Text = objMessage.ErrorMessage
                        End If
                        'Clear the Message fields that ASP.NET automatically refills.
                        Subject.Text = "" 'TODO: This seems incorrect
                        Body.Text = ""    'TODO: This seems incorrect
                    Else
                        litErrorMessage.Text = "The subject or message was blank." 'TODO: Move to StatusMessage/ErrorMessage object
                    End If
                End If
            End If
            'END of PostBack.
            Dim intProfileStatusID As Byte
            'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
            Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
            Dim objDataReader As SqlDataReader
            Dim objCommand As New SqlCommand
            objCommand.Connection = objConnection
            objConnection.Open()
            'Pull the information to display the profile.
            'TODO: Move to Parameterized Stored Procedure
            objCommand.CommandText = String.Format("SELECT UserName,GenderID,Age,SexualOrientationID,SignID,EthnicID,Height,BodyTypeID,NeighborhoodID,AboutMe,WantActivityPartner,WantFriend,WantDate,WantLTR,ImageName,ProfileStatusID FROM Profiles WHERE ProfileID={0};", strProfileID)
            objDataReader = objCommand.ExecuteReader()
            If Not (objDataReader.Read()) Then
                strProfileError = ErrorMessages.ERROR_MESSAGE_VIEW_PROFILE_DELETED
                objDataReader.Close()
            Else
                strProfileName = objDataReader("UserName")
                intProfileStatusID = objDataReader("ProfileStatusID")
                If (intProfileStatusID = 1) Then
                    strProfileError = ErrorMessages.ERROR_MESSAGE_VIEW_PROFILE_INACTIVE
                ElseIf (intProfileStatusID = 4) Then
                    strProfileError = ErrorMessages.ERROR_MESSAGE_VIEW_PROFILE_DELETED
                ElseIf (intProfileStatusID = 3) Then
                    strProfileError = ErrorMessages.ERROR_MESSAGE_VIEW_PROFILE_SUSPENDED
                ElseIf (intProfileStatusID = 2) Then
                    UserName.Text = objDataReader("UserName")
                    GenderID.Text = ColorGender(objDataReader("GenderID"))
                    Age.Text = objDataReader("Age")
                    Call UseOrientationArray()
                    SexualOrientationID.Text = OrientationArray(objDataReader("SexualOrientationID"))
                    Call UseSignArray()
                    SignID.Text = SignArray(objDataReader("SignID"))
                    Call UseEthnicArray()
                    EthnicID.Text = EthnicArray(objDataReader("EthnicID"))
                    If (objDataReader("Height") > 0) Then
                        Height.Text = ConvertHeight(objDataReader("Height"))
                    End If
                    Call UseBodyArray()
                    BodyTypeID.Text = BodyArray(objDataReader("BodyTypeID"))
                    Call UseHoodArray()
                    NeighborhoodID.Text = HoodArray(objDataReader("NeighborhoodID"))
                    If Not (objDataReader.IsDBNull(7)) Then
                        Dim strAbout As String = Server.HtmlDecode(objDataReader("AboutMe"))
                        AboutMe.Text = strAbout.Replace(vbCrLf, "<br />")
                    End If
                    'Print one or all of the following: 
                    'activity partners, friends, date, long-term relationship
                    Dim arrayWants(1, 3) As String
                    arrayWants(0, 0) = "WantActivityPartner"
                    arrayWants(1, 0) = "activity partners"
                    arrayWants(0, 1) = "WantFriend"
                    arrayWants(1, 1) = "friends"
                    arrayWants(0, 2) = "WantDate"
                    arrayWants(1, 2) = "date"
                    arrayWants(0, 3) = "WantLTR"
                    arrayWants(1, 3) = "long-term relationship"
                    Dim intWant As Byte
                    Dim strLookingFor As New StringBuilder()
                    For intWant = 0 To 3
                        If objDataReader(arrayWants(0, intWant)) = 1 Then
                            If (strLookingFor.Length > 0) Then
                                strLookingFor.Append(",&nbsp;")
                            End If
                            strLookingFor.Append(arrayWants(1, intWant))
                        End If
                    Next intWant
                    LookingFor.Text = strLookingFor.ToString()
                    'Print the person's photo.
                    If Not (objDataReader.IsDBNull(14)) Then
                        blnHasImage = True
                        ImageName.ImageUrl = "/pix/" & objDataReader("ImageName")
                        ImageName.AlternateText = strProfileName
                    End If
                    objDataReader.Close()
                    'Check if the user has additional photos.
                    Dim intExtraPhotosCount As Integer = 0
                    'TODO: Move to Parameterized Stored Procedure
                    objCommand.CommandText = String.Format("SELECT COUNT(*) FROM photos WHERE ProfileID={0};", strProfileID)
                    intExtraPhotosCount = objCommand.ExecuteScalar()
                    If intExtraPhotosCount > 0 Then
                        strViewPhotosHref = "href=""seephotos.aspx?" & Request.QueryString.ToString() & """"
                        strViewPhotosLink = "</a><br /><br /><a class='stayBlue' " & strViewPhotosHref & _
                             ">View All Photos</a>"
                        'TODO: Move href to PageURL object then Reference object
                        'TODO: String.Format above URL
                        'TODO: Querystring variables are BAD SECURITY practice... 
                        'look into this will have to see if it can be handles properly another way
                        'then make apropriate changes !!! Left to flag as security issue
                        '!!!
                        ImageName.AlternateText = "Click to View All Photos"
                    End If

                    'Steps for making the "Search Navigator" and "Favorite Navigator".
                    If (Session("SearchSettings") <> "" And intRecordIndex > 0) Or (intFavoriteRecordIndex > 0) Then
                        Dim strIndexType As String = "index"
                        Dim strNavigatorClass As String = "navSearch"
                        Dim strBackLinkClass As String = "sTabLink"
                        Dim strBackLinkURL As String = "search.aspx"
                        Dim strBackLinkText As String = "Search Results"
                        Dim strDisabledClass As String = "disabled"
                        Dim strSortbyQuery As String = ""
                        If intFavoriteRecordIndex > 0 Then
                            intRecordIndex = intFavoriteRecordIndex
                            Dim strSortby As String = Request.QueryString("sortby")
                            strIndexType = "findex"
                            strNavigatorClass = "navFavorites"
                            strBackLinkClass = "fTabLink"
                            strBackLinkURL = "favorites.aspx?sortby=" & strSortby
                            strBackLinkText = "Favorites"
                            strDisabledClass = "disabledFav"
                            strSortbyQuery = "&amp;sortby=" & strSortby
                            'Make sure the "sortby" querystring has not been tampered with.
                            If (InStr(strSortby, ";") = 0 And strSortby <> "") Then
                                strSortby = " ORDER BY " & strSortby
                            Else
                                strSortby = ""
                            End If
                            Dim intSeedIndex As Integer = intRecordIndex
                            If intSeedIndex < 2 Then
                                intSeedIndex = 2
                            End If
                            '1A. Set the SELECT statement.
                            'TODO: Move to Parameterized Stored Procedure
                            objCommand.CommandText = String.Format("SELECT f.FavoriteID FROM favorites f INNER JOIN profiles p ON f.FavoriteID = p.ProfileID WHERE p.ProfileStatusID <> 4 AND f.ProfileID={0}{1} LIMIT {2}, 3;", Session("ProfileID"), strSortby, CStr(intSeedIndex - 2))
                        Else '1B. Grab the search parameters stored in the Session and pass them to the
                            '    MakeSelectStatement function below.
                            Dim strSearchSettings As String = Session("SearchSettings")
                            Dim arraySearchSettings() As String = strSearchSettings.Split(",")
                            objCommand.CommandText = MakeSelectStatement(arraySearchSettings, intRecordIndex)
                        End If
                        If objCommand.CommandText <> "ERROR" Then
                            objDataReader = objCommand.ExecuteReader()
                            '2. Store the ProfileID's in an array of length 3.
                            Dim arrayProfileIDs(2) As String
                            Dim intArrayIndex As Byte = 0
                            While objDataReader.Read()
                                arrayProfileIDs(intArrayIndex) = CStr(objDataReader(0))
                                intArrayIndex = intArrayIndex + 1
                            End While
                            objDataReader.Close()
                            '3. Determine the correct assignment of Previous and Next depending on
                            '   the current profile's position in the recordset.
                            Dim strNextRecord As String = String.Empty
                            Dim strPreviousRecord As String = String.Empty
                            If strProfileID = arrayProfileIDs(0) Then
                                strNextRecord = arrayProfileIDs(1)
                            ElseIf IsNumeric(arrayProfileIDs(2)) Then
                                strPreviousRecord = arrayProfileIDs(0)
                                strNextRecord = arrayProfileIDs(2)
                            Else
                                strPreviousRecord = arrayProfileIDs(0)
                            End If
                            '4. Create the "Previous" and "Next" links.
                            If IsNumeric(strPreviousRecord) Then
                                strPreviousRecord = String.Format("<a class='stayBlue' href='seeprofile.aspx?id={0}&amp;{1}={2}{3}'>Previous Profile</a>", strPreviousRecord, strIndexType, CStr(intRecordIndex - 1), strSortbyQuery)
                            Else
                                strPreviousRecord = String.Format("<a class='{0}'>Previous Profile</a>", strDisabledClass)
                            End If
                            If IsNumeric(strNextRecord) Then
                                strNextRecord = String.Format("<a class='stayBlue' href='seeprofile.aspx?id={0}&amp;{1}={2}{3}'>Next Profile</a>", strNextRecord, strIndexType, CStr(intRecordIndex + 1), strSortbyQuery)
                            Else
                                strNextRecord = String.Format("<a class='{0}'>Next Profile</a>", strDisabledClass)
                            End If
                            '5. Build the HTML of the navigator.
                            With strProfileNavigator
                                .Append("<table class='" & strNavigatorClass & "' width='100%'>")
                                .Append("<tr><td nowrap=""nowrap""><a class='" & strBackLinkClass & "'")
                                .Append(" href='" & strBackLinkURL & "'>Back to " & strBackLinkText & "</a>")
                                .Append("&nbsp;&nbsp;&nbsp;</td><td nowrap=""nowrap"">&nbsp;&nbsp;" & strPreviousRecord)
                                .Append("&nbsp;&nbsp;&nbsp;</td><td nowrap=""nowrap"">" & strNextRecord)
                                .Append("</td><td width='95%'>&nbsp;</td></tr></table><br />")
                            End With
                            blnPrintNavigator = True
                        End If
                    End If

                    'Add the current profile to the logged in user's Favorites.
                    Dim strAddFavorite As String = Request.QueryString("addfavorite")
                    Dim strUserID As String = Session("ProfileID")
                    If (strAddFavorite = "yes" And IsNumeric(strUserID) And IsNumeric(strProfileID)) Then
                        Dim objFav As New Favorite
                        objFav.ProfileID = Session("ProfileID")
                        objFav.FavoriteID = strProfileID
                        objFav.FavoriteName = strProfileName
                        objFav.Add()
                        If objFav.ErrorMessage = "" Then
                            'MessageCell.CssClass = "fMsgBox"
                            litStatusMessage.Text = objFav.GoodNews
                        Else
                            'MessageCell.CssClass = "errorBox"
                            litErrorMessage.Text = objFav.ErrorMessage
                        End If
                    ElseIf (strAddFavorite = "yes" And IsNumeric(strProfileID)) Then
                        litErrorMessage.Text = "Please login before adding favorites." 'TODO: Move to StatusMessage/ErrorMessage object
                        'TODO: Let's think in terms of multi-use string templates "Please login before {0} {1}." could be used in multiple scenarios and mapped to multiple string.formats/CONSTANTS
                    ElseIf Request.QueryString("reportneedlogin") = "1" Then
                        litErrorMessage.Text = "Please login to report abuse of the site." 'TODO: Move to StatusMessage/ErrorMessage object
                        'TODO: See above regarding efficiencies Do NOT Impliment but make notes within the error/status objects as we go
                    End If
                End If
                'Create the link for adding favorites.
                strAddFavoriteLink = String.Format("<a class='buttonLink' href='seeprofile.aspx?username={0}&amp;id={1}&amp;addfavorite=yes&amp;index={2}'>Add to Favorites</a>", strProfileName, strProfileID, intRecordIndex)
                strReportLink = String.Format("<a class=""stayBlue"" href=""report.aspx?username={0}&amp;id={1}"">Report for Abuse</a>", strProfileName, strProfileID) 'TODO: Move to href to PageURL object then Reference object
                'TODO: Move URL strings to appropriate object
                'TODO: Replace link with server object reference
                objDataReader.Close()
            End If
            'Check if the current user's sent folder is full.
            If Session("UserName") <> "" Then
                'TODO: Move to Parameterized Stored Procedure
                objCommand.CommandText = String.Format("SELECT Count(*) FROM messages WHERE SenderID={0} AND DeletedBySender=0;", Session("ProfileID"))
                Dim intSent As Integer
                intSent = CInt(objCommand.ExecuteScalar())
                If intSent >= MAX_MESSAGES Then
                    blnSentFolderFull = True
                End If
            End If
            objConnection.Close()
        End If

        If litErrorMessage.Text <> "" Then
            phErrorMessage.Visible = True
        Else
            phErrorMessage.Visible = False
        End If

        If litStatusMessage.Text <> "" Then
            phStatusMessage.Visible = True
        Else
            phStatusMessage.Visible = False
        End If

        phHasImage.Visible = blnHasImage
        If Not (blnSameAsUser) Then
            phSameAsUser.Visible = True

            If (Session("UserName") = "") Then
                mvPresentation.SetActiveView(vwLoggedOut)
            ElseIf blnSentFolderFull Then
                mvPresentation.SetActiveView(vwSentMailFull)
            Else
                mvPresentation.SetActiveView(vwSendEmail)
            End If
        End If

        Page.Title = "Social Conveyors - " & strProfileName
    End Sub


    '1. GenderID
    '2. SexualOrientationID
    '3. EthnicID
    '4. AgeMin
    '5. AgeMax
    '6. Keywords
    '7. WithPhotos
    '8. SortBy
    Function MakeSelectStatement(ByVal arraySearchParameters As String(), ByVal intSeedIndex As Integer) As String
        If arraySearchParameters.Length <> 9 Then
            Return "ERROR"
        Else
            'Build the WHERE clause.
            Dim strWhere As New StringBuilder()
            strWhere.Append("ProfileStatusID=2")
            If (arraySearchParameters(1) <> "") Then
                strWhere.Append(" AND GenderID=" & arraySearchParameters(1))
            End If
            If (arraySearchParameters(2) <> "") Then
                strWhere.Append(" AND SexualOrientationID=" & arraySearchParameters(2))
            End If
            If (arraySearchParameters(3) <> "") Then
                strWhere.Append(" AND EthnicID=" & arraySearchParameters(3))
            End If
            If (arraySearchParameters(4) <> "") Then
                strWhere.Append(" AND Age >= " & arraySearchParameters(4))
            End If
            If (arraySearchParameters(5) <> "") Then
                strWhere.Append(" AND Age <= " & arraySearchParameters(5))
            End If
            Dim strKeywords As String = arraySearchParameters(6)
            If (strKeywords <> "") Then
                'Handle keywords separated by commas.
                If strKeywords.IndexOf(",") <> -1 Then
                    Dim keywordsArray() As String = strKeywords.Split(",")
                    Dim strKey As String
                    For Each strKey In keywordsArray
                        strWhere.Append(" AND AboutMe LIKE ""%" & Server.HtmlEncode(Trim(strKey)) & "%""")
                    Next
                    'Handle keywords separated by spaces.
                ElseIf strKeywords.IndexOf(" ") <> -1 Then
                    Dim keywordsArray() As String = strKeywords.Split()
                    Dim strKey As String
                    For Each strKey In keywordsArray
                        strWhere.Append(" AND AboutMe LIKE ""%" & Server.HtmlEncode(strKey) & "%""")
                    Next
                    'For a single keyword, search AboutMe and UserName fields.
                Else
                    strWhere.Append(" AND (AboutMe LIKE ""%" & Server.HtmlEncode(strKeywords) & "%""")
                    strWhere.Append(" OR UserName LIKE ""%" & Server.HtmlEncode(strKeywords) & "%"")")
                End If
            End If
            If (arraySearchParameters(7) = "on") Then
                strWhere.Append(" AND ImageName IS NOT NULL")
            End If
            'Handle sorting.
            Dim strSortBy As String = arraySearchParameters(8)
            Dim strOrderBy As String = ""
            If (InStr(strSortBy, " ") = 0 And strSortBy <> "") Then
                If strSortBy = "ImageName" Then
                    strOrderBy = " ORDER BY ImageName DESC"
                Else
                    strOrderBy = " ORDER BY " & strSortBy
                End If
            Else
                strOrderBy = " ORDER BY ProfileID DESC"
            End If
            If intSeedIndex < 2 Then
                intSeedIndex = 2
            End If
            Return String.Format("SELECT ProfileID FROM Profiles WHERE {0}{1} LIMIT {2}, 3;", strWhere.ToString(), strOrderBy, CStr(intSeedIndex - 2)) 'TODO: Move to Parameterized Stored Procedure
        End If
    End Function

    'Used on create/edit/view profile pages.
    Function ConvertHeight(ByVal intHeight As Integer) As String
        Dim intFeet = Fix(intHeight / 12)
        Dim intInches = intHeight Mod 12
        Return CStr(intFeet) & "'" & CStr(intInches) & Chr(34)
    End Function

    'Used on Search results and Favorites page to color-code genders.
    Function ColorGender(ByVal intGenderIndex As Object)
        If GenderArray(1) = "" Then
            Call UseGenderArray()
        End If
        If IsDBNull(intGenderIndex) Then
            Return ""
        Else
            intGenderIndex = CByte(intGenderIndex)
            Select Case intGenderIndex
                Case 1
                    Return "<span class=female>female</span>"
                Case 2
                    Return "<span class=male>male</span>"
                Case Else
                    Return "<span class=transgender>" & GenderArray(intGenderIndex) & "</span>"
            End Select
        End If
    End Function

    'Used on Search results an Favorites page to color-code genders.
    Function GetHoodName(ByVal intHoodIndex As Object)
        If IsDBNull(intHoodIndex) Then
            Return ""
        Else
            intHoodIndex = CByte(intHoodIndex)
            Return HoodArray(intHoodIndex)
        End If
    End Function

    Public GenderArray(4) As String
    Public Sub UseGenderArray()
        GenderArray(0) = ""
        GenderArray(1) = "female"
        GenderArray(2) = "male"
        GenderArray(3) = "transgender(f2m)"
        GenderArray(4) = "transgender(m2f)"
    End Sub

    Public OrientationArray(4) As String
    Public Sub UseOrientationArray()
        OrientationArray(0) = ""
        OrientationArray(1) = "straight"
        OrientationArray(2) = "gay/lesbian"
        OrientationArray(3) = "bisexual"
    End Sub

    Public BodyArray(6) As String
    Public Sub UseBodyArray()
        BodyArray(0) = ""
        BodyArray(1) = "average"
        BodyArray(2) = "slim/slender"
        BodyArray(3) = "athletic"
        BodyArray(4) = "thick"
        BodyArray(5) = "a little extra padding"
        BodyArray(6) = "more to love"
    End Sub

    Public HoodArray(37) As String
    Public Sub UseHoodArray()
        HoodArray(0) = "San Francisco"
        HoodArray(1) = "bayview / hunter's point"
        HoodArray(2) = "bernal heights"
        HoodArray(3) = "castro / eureka valley"
        HoodArray(4) = "chinatown"
        HoodArray(5) = "cole valley"
        HoodArray(6) = "excelsior / outer mission"
        HoodArray(7) = "financial district / embarcadero"
        HoodArray(8) = "glen park"
        HoodArray(9) = "haight ashbury"
        HoodArray(10) = "hayes valley"
        HoodArray(11) = "ingleside / merced / ocean view (SFSU,CCSF)"
        HoodArray(12) = "inner richmond"
        HoodArray(13) = "inner sunset / parnassus heights (UCSF)"
        HoodArray(14) = "laurel heights / presidio"
        HoodArray(15) = "lower haight / fillmore"
        HoodArray(16) = "marina / cow hollow"
        HoodArray(17) = "mission district"
        HoodArray(18) = "nob hill"
        HoodArray(19) = "noe valley"
        HoodArray(20) = "north beach / telegraph hill"
        HoodArray(21) = "pacific heights"
        HoodArray(22) = "panhandle (USF)"
        HoodArray(23) = "potrero hill / dogpatch"
        HoodArray(24) = "richmond / seacliff"
        HoodArray(25) = "russian hill"
        HoodArray(26) = "soma / south beach / mission bay"
        HoodArray(27) = "sunset / parkside"
        HoodArray(28) = "tenderloin / civic center"
        HoodArray(29) = "tendernob"
        HoodArray(30) = "twin peaks / diamond heights"
        HoodArray(31) = "visitacion valley / sunnydale / portola"
        HoodArray(32) = "west portal / st. francis wood / forest hill"
        HoodArray(33) = "western addition / japantown"
        HoodArray(34) = "East Bay"
        HoodArray(35) = "North Bay"
        HoodArray(36) = "Peninsula"
        HoodArray(37) = "South Bay"
    End Sub

    Public EthnicArray(10) As String
    Public Sub UseEthnicArray()
        EthnicArray(0) = ""
        EthnicArray(1) = "asian"
        EthnicArray(2) = "black / african"
        EthnicArray(3) = "hispanic / latino"
        EthnicArray(4) = "indian / south asian"
        EthnicArray(5) = "middle eastern / arab"
        EthnicArray(6) = "native american"
        EthnicArray(7) = "pacific islander"
        EthnicArray(8) = "white / caucasian"
        EthnicArray(9) = "mixed"
        EthnicArray(10) = "other"
    End Sub

    Public SignArray(12) As String
    Public Sub UseSignArray()
        SignArray(0) = ""
        SignArray(1) = "aquarius"
        SignArray(2) = "aries"
        SignArray(3) = "cancer"
        SignArray(4) = "capricorn"
        SignArray(5) = "gemini "
        SignArray(6) = "leo"
        SignArray(7) = "libra"
        SignArray(8) = "pisces"
        SignArray(9) = "sagittarius"
        SignArray(10) = "scorpio"
        SignArray(11) = "taurus"
        SignArray(12) = "virgo"
    End Sub

End Class
