﻿'***********************************************************************
' Assembly         : \Visual Studio 2008\Projects\
' Author           : Scott D. Sullivan-Reinhart
' Created          : 12-18-2010
'
' Last Modified By : Scott D. Sullivan-Reinhart
' Last Modified On : 12-25-2010
' Description      : 
'
' Copyright        : (c) Social Conveyors, LLC.. All rights reserved.
'***********************************************************************
'TODO: Setup Regions
'TODO: Fill out comment header correctly & describe object
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient

Imports Globals

Partial Class SeeMsg
    Inherits System.Web.UI.Page

    Public strFolder As String
    Dim strMessageID As String
    Public blnMessageExists As Boolean = False
    Public intNewMessages As Integer = 0
    Public strAddFavoriteLink As String = ""
    Public strBlockLink As String = ""
    Public strViewProfileLink As String = ""
    'Public strReplyButton As String = ""

    Public strSender As String
    Dim strSenderID As String
    Public strRecipient As String
    Public strMessageDate As String
    Public strSubject As String
    Public strBody As String

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        strFolder = Request.QueryString("folder")
        strMessageID = Request.QueryString("id")
        Dim strSortBy As String = Request.QueryString("sortby")
        If Session("UserName") = "" Then
            MessageCell.CssClass = "msgSent"
            MessageCell.Text = "Please login to view your messages." 'TODO: Move to StatusMessage/ErrorMessage object
        ElseIf (strFolder = "" Or IsNumeric(strMessageID) = False) Then
            MessageCell.Text = "Please don't mess with the URL." 'TODO: Move to StatusMessage/ErrorMessage object
        Else
            If Not (strFolder = "inbox" Or strFolder = "sent") Then
                MessageCell.Text = "Please don't mess with the URL." 'TODO: Move to StatusMessage/ErrorMessage object
            Else
                'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
                Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
                Dim objDataReader As SqlDataReader
                Dim objCommand As New SqlCommand()
                objCommand.Connection = objConnection
                objConnection.Open()
                'PostBack only occurs for message deletion.
                If Page.IsPostBack Then
                    
                Else
                    Dim intSenderProfileStatusID As Integer
                    'Grab the information for the incoming message to be displayed.
                    If strFolder = "inbox" Then
                        'TODO: Move to Parameterized Stored Procedure
                        objCommand.CommandText = String.Format("SELECT m.MessageDate,m.SenderID,m.Subject,m.Body,p.UserName,p.ProfileStatusID FROM messages m INNER JOIN profiles p ON m.SenderID = p.ProfileID WHERE m.MessageID={0} AND m.RecipientID={1} AND m.DeletedByRecipient=0;", strMessageID, Session("ProfileID"))
                    Else
                        'For sent messages.
                        'TODO: Move to Parameterized Stored Procedure
                        objCommand.CommandText = String.Format("SELECT m.MessageDate,m.Subject,m.Body,p.UserName FROM messages m INNER JOIN profiles p ON m.RecipientID = p.ProfileID WHERE m.MessageID={0} AND m.SenderID={1} AND m.DeletedBySender=0;", strMessageID, Session("ProfileID"))
                    End If
                    objDataReader = objCommand.ExecuteReader()
                    If Not (objDataReader.Read()) Then
                        objDataReader.Close()
                        MessageCell.Text = "The message you are trying to read was deleted." 'TODO: Move to StatusMessage/ErrorMessage object
                    Else
                        If strFolder = "inbox" Then
                            strSender = objDataReader("UserName")
                            strRecipient = Session("UserName")
                            strSenderID = objDataReader("SenderID")
                            intSenderProfileStatusID = objDataReader("ProfileStatusID")
                        Else
                            strSender = Session("UserName")
                            strRecipient = objDataReader("UserName")
                        End If
                        strMessageDate = objDataReader("MessageDate")
                        strSubject = Server.HtmlDecode(objDataReader("Subject"))
                        strBody = Server.HtmlDecode(objDataReader("Body"))
                        strBody = strBody.Replace(vbCrLf, "<br />")
                        blnMessageExists = True
                        objDataReader.Close()
                        'Set the MessageRead flag to true for the recipient.
                        If strFolder = "inbox" Then

                            objCommand.CommandText = String.Format("UPDATE messages SET MessageRead=1 WHERE MessageID='{0}';", strMessageID) 'TODO: Move to Parameterized Stored Procedure
                            objCommand.ExecuteNonQuery()
                            If intSenderProfileStatusID = 2 Then
                                strViewProfileLink = String.Format("<a class=""stayBlue"" href=""seeprofile.aspx?username={0}&id={1}"">View Profile</a>", strSender, strSenderID) 'Create the "View Profile" link. '!!!
                                strBlockLink = String.Format("<a class=""stayBlue"" href=""seemsg.aspx?folder={0}&sortby={1}&id={2}&blockid={3}"">Block Sender</a>", strFolder, strSortBy, strMessageID, strSenderID) 'Create the "Block Sender" link.	'!!!
                                strAddFavoriteLink = String.Format("<a class=""stayBlue"" href=""seemsg.aspx?folder={0}&sortby={1}&id={2}&favoriteid={3}"">Add to Favorites</a>", strFolder, strSortBy, strMessageID, strSenderID) 'Create the link for adding favorites. '!!!
                                btnReply.Enabled = True
                            Else
                                btnReply.Enabled = False
                                If intSenderProfileStatusID = 3 Then
                                    MessageCell.Text = "The person who sent you this message has a suspended profile<br />and may not receive your reply if his/her profile is deleted." 'TODO: Move to StatusMessage/ErrorMessage object
                                ElseIf intSenderProfileStatusID = 4 Then
                                    MessageCell.Text = "The person who sent you this message has deleted their profile." 'TODO: Move to StatusMessage/ErrorMessage object
                                End If
                            End If
                            'If the user clicked "Add to Favorites" link, add the record to the favorites table.
                            Dim strFavoriteID As String = Request.QueryString("favoriteid")
                            Dim strBlockID As String = Request.QueryString("blockid")
                            If IsNumeric(strFavoriteID) Then
                                Dim objFav As New Favorite
                                objFav.ProfileID = Session("ProfileID")
                                objFav.FavoriteID = strFavoriteID
                                objFav.FavoriteName = strSender
                                objFav.Add()
                                If objFav.ErrorMessage = "" Then
                                    MessageCell.CssClass = "fMsgBox"
                                    MessageCell.Text = objFav.GoodNews
                                Else
                                    MessageCell.Text = objFav.ErrorMessage
                                End If
                                'If the user clicked "Block Sender", add the record to the messageblocks table.
                            ElseIf IsNumeric(strBlockID) Then
                                Dim strBlockName As String
                                'TODO: Move to Parameterized Stored Procedure
                                objCommand.CommandText = String.Format("SELECT UserName,ProfileStatusID FROM Profiles WHERE ProfileID={0}", strBlockID)
                                objDataReader = objCommand.ExecuteReader()
                                If Not (objDataReader.Read()) Then
                                    MessageCell.Text = "The profile you tried to block was deleted or does not exist." 'TODO: Move to StatusMessage/ErrorMessage object
                                    objDataReader.Close()
                                Else
                                    strBlockName = objDataReader("UserName")
                                    Dim intProfileStatusID As Byte = objDataReader("ProfileStatusID")
                                    objDataReader.Close()
                                    If intProfileStatusID = 3 Then
                                        MessageCell.Text = "The profile you tried to block is suspended." 'TODO: Move to StatusMessage/ErrorMessage object
                                    ElseIf intProfileStatusID = 4 Then
                                        MessageCell.Text = "The profile you tried to block was deleted or does not exist." 'TODO: Move to StatusMessage/ErrorMessage object
                                    ElseIf intProfileStatusID = 2 Then
                                        'TODO: Move to Parameterized Stored Procedure
                                        objCommand.CommandText = String.Format("SELECT Count(*) FROM messageblocks WHERE ProfileID={0} AND BlockID={1};", Session("ProfileID"), strBlockID)
                                        Dim intRecords As Byte
                                        intRecords = CByte(objCommand.ExecuteScalar())
                                        If intRecords > 0 Then
                                            MessageCell.Text = String.Format("<strong>{0}</strong> is already on your blocked list.", strBlockName) 'TODO: Move to StatusMessage/ErrorMessage object then Reference object
                                        Else
                                            objCommand.CommandText = "INSERT INTO messageblocks (ProfileID,BlockID) VALUES (" & Session("ProfileID") & "," & strBlockID & ");"
                                            objCommand.ExecuteNonQuery()
                                            MessageCell.CssClass = "msgSent"
                                            MessageCell.Text = String.Format("<strong>{0}</strong> was added to your blocked list.", strBlockName) 'TODO: Move to StatusMessage/ErrorMessage object then Reference object
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If

                    'Get the number of new messages in the Inbox.
                    'TODO: Move to Parameterized Stored Procedure
                    objCommand.CommandText = String.Format("SELECT Count(*) FROM messages WHERE RecipientID={0} AND DeletedByRecipient=0 AND MessageRead=0", Session("ProfileID"))
                    intNewMessages = CInt(objCommand.ExecuteScalar())
                End If
                objConnection.Close()
            End If
        End If
    End Sub

    Function BoldSelected(ByVal strSelected As String) As String
        If strFolder = "" And strSelected = "Inbox" Then
            Return "<strong>Inbox</strong>"
        Else
            If LCase(strFolder) = LCase(strSelected) Then
                Return "<strong>" & strSelected & "</strong>"
            Else
                Return strSelected
            End If
        End If
    End Function

    Function LongDate(ByVal dt As DateTime) As String
        dt = dt.AddHours(OFFSET_HOURS)
        Return WeekdayName(Weekday(dt)) & ", " & MonthName(Month(dt)) & " " & Day(dt) & ", " & Year(dt) & " &nbsp;" & TimeValue(dt)
    End Function

    Protected Sub btnReply_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnReply.Click
        'strReplyButton = "<input type=""button"" onclick=""window.location='sendmsg.aspx?replyid=" & strMessageID & "';"""" value=""Reply"">"
        Response.Redirect("sendmsg.aspx?replyid=" & strMessageID)
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        'TODO: Move ConnectionStrings reference to Configuration Namespace and make an object to wrapper.
        Dim objConnection As New SqlConnection(ConfigurationManager.ConnectionStrings("MainConnStr").ConnectionString)
        Dim objCommand As New SqlCommand()
        objCommand.Connection = objConnection
        objConnection.Open()
        Response.Write(strMessageID)
        'Build the UPDATE statement for deleting the message.
        If strFolder = "inbox" Then
            objCommand.CommandText = "UPDATE messages SET DeletedByRecipient=1 WHERE RecipientID='" & Session("ProfileID") & "' AND MessageID='" & strMessageID & "';"
        ElseIf strFolder = "sent" Then
            objCommand.CommandText = "UPDATE messages SET DeletedBySender=1 WHERE SenderID='" & Session("ProfileID") & "' AND MessageID='" & strMessageID & "';"
        End If
        objCommand.ExecuteNonQuery()
        'DELETE the message permanently if both sender and recipient deleted the message.
        objCommand.CommandText = "DELETE FROM messages WHERE DeletedBySender=1 AND DeletedByRecipient=1;"
        objCommand.ExecuteNonQuery()
        objConnection.Close()
        Response.Redirect("/messages.aspx")
    End Sub
End Class
